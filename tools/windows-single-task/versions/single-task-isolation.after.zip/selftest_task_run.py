"""Offline checks for the single-task entry: no virtual machine, no real ledger.

The point is to prove the parts that decide correctness before anything touches Hyper-V:
freezing is idempotent, a changed task is refused, stages only move forward, missing and
unreadable outputs stay distinguishable, and the ledger still refuses to close without a
submission plus the four receipts.
"""

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

import run_dsh_task
import task_request as tr
from inspect_task_native import inspect_snapshot
from attempt_completion import CompletionNotVerified, close_completed_attempt, initialize_completion_table
from attempt_ledger import initialize_attempt_ledger, register_attempt
from submission_permit import (
    initialize_submission_tables,
    begin_submission,
    issue_submission_permit,
)

RESULTS = []


def check(name, condition, detail=""):
    RESULTS.append((name, bool(condition), detail))
    print(f"{'PASS' if condition else 'FAIL'} {name}" + (f" — {detail}" if detail and not condition else ""))


def make_task(root: Path, prompt: str = "读取 input/sample.txt，把这一行原样写入 output/result.txt，然后回复“已完成”。") -> Path:
    package = root / "tasks" / "copy-line-v1"
    (package / "input").mkdir(parents=True, exist_ok=True)
    (package / "input" / "sample.txt").write_text("第一行样本\n", encoding="utf-8")
    manifest = {
        "task_id": "copy-line",
        "version": "1",
        "prompt": prompt,
        "inputs": ["input/sample.txt"],
        "outputs": ["output/result.txt"],
        "expect": {"output/result.txt": "第一行样本\n"},
    }
    path = package / "task.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
    return path


def test_freeze(root: Path):
    task = make_task(root)
    store = root / "requests" / "demo-001"
    record, reused = tr.freeze_request(store, "demo-001", task)
    check("freeze writes a record", (store / "request.json").is_file() and not reused)
    check("freeze pins the prompt hash", record["prompt_sha256"] == tr.sha256_bytes(record["prompt"].encode("utf-8")))
    check("freeze pins the input hash", record["inputs"][0]["sha256"] == tr.sha256_file(task.parent / "input" / "sample.txt"))

    same, reused_again = tr.freeze_request(store, "demo-001", task)
    check("a repeat freeze reuses the record", reused_again and same["prompt_sha256"] == record["prompt_sha256"])

    changed = make_task(root, prompt="换成另一道题")
    try:
        tr.freeze_request(store, "demo-001", changed)
        check("a changed prompt is refused", False, "no exception")
    except tr.RequestConflict:
        check("a changed prompt is refused", True)


def test_stage_order(root: Path):
    state = tr.new_state({"request_id": "demo-001", "task_id": "copy-line", "task_version": "1"}, None, "formal")
    tr.advance(state, "restored")
    tr.advance(state, "dispatched")
    check("stages advance forward", state["stage"] == "dispatched")
    try:
        tr.advance(state, "prepared")
        check("stages refuse to move backwards", False, "no exception")
    except tr.TaskLayoutError:
        check("stages refuse to move backwards", True)
    check("stage_reached is monotonic", tr.stage_reached(state, "prepared") and not tr.stage_reached(state, "closed"))


def test_outputs(root: Path):
    record = {"outputs": ["output/result.txt"], "expect": {"output/result.txt": "第一行样本\n"}}
    results = root / "results"
    (results / "output").mkdir(parents=True, exist_ok=True)

    check("missing output is named as missing",
          tr.verify_outputs(results, record)["verdict"] == "task_missing_output")

    (results / "output" / "result.txt").write_text("第一行样本\n", encoding="utf-8")
    passing = tr.verify_outputs(results, record)
    check("correct content passes", passing["verdict"] == "pass" and passing["files"][0]["matches_expect"])

    (results / "output" / "result.txt").write_text("第一行样本\n多出来一行\n", encoding="utf-8")
    wrong = tr.verify_outputs(results, record)
    check("wrong content is its own verdict", wrong["verdict"] == "task_wrong_content")

    (results / "output" / "result.txt").write_bytes(b"\xff\xfe\x00broken")
    unreadable = tr.verify_outputs(results, record)
    check("unreadable content is not called a wrong answer",
          unreadable["verdict"] == "collection_incomplete")

    (results / "output" / "result.txt").write_text("第一行样本\n\n", encoding="utf-8")
    tolerant = tr.verify_outputs(results, record)
    check("one trailing newline is tolerated", tolerant["verdict"] == "pass")


def test_ledger(root: Path):
    ledger = root / "attempts.sqlite3"
    initialize_attempt_ledger(ledger)
    initialize_submission_tables(ledger)
    initialize_completion_table(ledger)
    attempt_id = "TASK-demo-001-abc12345"
    register_attempt(ledger, attempt_id, "formal")
    expires = datetime.now(timezone.utc) + timedelta(minutes=15)
    permit = issue_submission_permit(ledger, attempt_id, "fp-1", expires)

    receipts = root / "receipts" / attempt_id
    report = {
        "Dispatch": {"InvokeStartedAt": "2026-11-19T00:00:01Z", "ReadbackSha256": "p"},
        "Completion": {
            "Acceptance": {"SessionId": "session-1234", "AcceptanceVerified": True},
            "Basis": "native_turn_end", "Turn": 1, "UserMessageSequence": 2,
            "NativeTurnEnd": {"type": "turn/end", "seq": 4}, "TurnStatus": "completed", "TraceSha256": "t",
        },
        "FinalRestore": {"Verdict": "pass", "BootEvent": {"RecordId": 1061}, "Residue": []},
        "Cleanup": {"TaskRemains": 0},
    }
    results = {"verdict": "pass", "files": [], "host_root": str(root / "results")}

    try:
        close_completed_attempt(ledger, attempt_id, receipts)
        check("closing without a submission is refused", False, "no exception")
    except CompletionNotVerified:
        check("closing without a submission is refused", True)

    begin_submission(ledger, attempt_id, permit, "fp-1")
    try:
        close_completed_attempt(ledger, attempt_id, receipts)
        check("closing without receipts is refused", False, "no exception")
    except CompletionNotVerified:
        check("closing without receipts is refused", True)

    run_dsh_task.write_receipts(receipts, attempt_id, report, results)
    close_completed_attempt(ledger, attempt_id, receipts)
    import sqlite3
    with sqlite3.connect(ledger) as connection:
        closed_at = connection.execute(
            "SELECT closed_at FROM attempts WHERE attempt_id = ?", (attempt_id,)).fetchone()[0]
        evidence = connection.execute(
            "SELECT evidence_json FROM attempt_completion WHERE attempt_id = ?", (attempt_id,)).fetchone()[0]
    check("a complete set of receipts closes the attempt", closed_at is not None)
    check("the closing evidence keeps all four receipts",
          set(json.loads(evidence)) == {"accepted", "terminated", "archived", "cleaned"})


def test_native_turn(root: Path):
    workspace = r"C:\Users\alex_\copy-line-test"
    prompt = "复制一行"
    session = "session-1234"
    header = {"type": "session", "version": 4, "id": session, "cwd": workspace, "isSeeded": False,
              "createdAt": 1100}
    start = {"type": "turn/start", "seq": 1, "data": {"turn": 1}}
    user = {"type": "user/message", "seq": 2, "data": {"source": {"kind": "user"}, "content": prompt}}
    reply = {"type": "assistant/message", "seq": 3,
             "data": {"turn": 1, "message": {"content": [{"type": "text", "text": "已完成"}]}}}
    end = {"type": "turn/end", "seq": 4, "data": {"turn": 1, "reason": {"kind": "completed"}}}

    def inspect(*events, expected_workspace=workspace, not_before=1000, trailing_newline=True):
        payload = "\n".join(json.dumps(row, ensure_ascii=False) for row in (header, *events))
        if trailing_newline:
            payload += "\n"
        return inspect_snapshot(payload.encode("utf-8"), expected_workspace, prompt, session, not_before)

    complete = inspect(start, user, reply, end)
    check("fast native turn with one exact prompt completes", complete["NativeTurnEnd"] == end and
          complete["Acceptance"]["OperatorSubmissions"] == 1 and complete["ReplyText"] == "已完成")
    check("duplicate prompt does not confirm acceptance", not inspect(start, user, reply, end, {**user, "seq": 5}))
    check("foreign workspace and old session are excluded",
          not inspect(start, user, reply, end, expected_workspace=workspace + "-old") and
          not inspect(start, user, reply, end, not_before=1200))
    wrong_end = {**end, "data": {**end["data"], "turn": 2}}
    check("terminal event for another turn cannot finish the task", not inspect(start, user, reply, wrong_end))
    check("a partially written terminal row is not proof", "NativeTurnEnd" not in
          inspect(start, user, reply, end, trailing_newline=False))

    # A correct output may be written while the turn still runs.
    output = root / "native-test" / "output" / "result.txt"
    output.parent.mkdir(parents=True)
    output.write_text("sample", encoding="utf-8")
    pending = inspect(start, user, reply)
    check("an early output does not end the native turn", pending["Acceptance"]["AcceptanceVerified"] and
          "NativeTurnEnd" not in pending)
    aborted = {**end, "data": {**end["data"], "reason": {"kind": "aborted"}}}
    failed = inspect(start, user, aborted)
    check("non-completed native status remains visible", failed["TurnStatus"] == "aborted" and
          failed["ReplyText"] is None)


def test_summary(root: Path):
    store = root / "requests" / "demo-001"
    record = json.loads((store / "request.json").read_text(encoding="utf-8"))
    state = tr.new_state(record, "TASK-demo-001-abc12345", "formal")
    state["stage"] = "closed"
    state["result"] = {"task_result": "pass", "submissions": {"formal": 1, "diagnostic": 0}}
    tr.save_state(store, state)
    summary = tr.summarize(store)
    check("summary reports the final stage and submissions",
          summary["stage"] == "closed" and summary["submissions"]["formal"] == 1)


def test_isolation_admission(root: Path):
    def write_json(path, data):
        path.write_text(json.dumps(data), encoding="utf-8")

    def no_formal_permit(ledger, go):
        with sqlite3.connect(ledger) as connection:
            count = connection.execute("""
                SELECT COUNT(*) FROM submission_permits JOIN attempts USING (attempt_id) WHERE kind = 'formal'
            """).fetchone()[0]
        return count == 0 and not go.exists()

    for scenario in ("pass", "readable-marker", "missing-read", "changed-boot", "changed-config", "changed-proof",
                     "changed-archive", "open-diagnostic"):
        store = root / scenario
        directory = store / "isolation"
        sample_path = directory / "inputs" / "input" / "sample.txt"
        sample_path.parent.mkdir(parents=True)
        ledger = store / "attempts.sqlite3"
        initialize_attempt_ledger(ledger)
        initialize_submission_tables(ledger)
        initialize_completion_table(ledger)
        diagnostic_id = "ISO-a1b2c3d4e5f6a7b8"
        working_root = rf"C:\Users\alex_\AppData\Local\Temp\{diagnostic_id}"
        workspace = working_root + f"\\WS-{diagnostic_id[-8:]}"
        session = "session-1234"
        prompt = "Read the two registered paths."
        sample = b"authorized sample\r\n"
        marker = b"0123456789abcdef0123456789abcdef"
        protected_path = r"\\172.21.144.1\E$\synthetic.txt"
        boot = {"RecordId": 1060, "CreatedUtc": "2026-11-19T00:00:00.0000000Z"}
        context = {"BootEvent": boot, "ProtectedUNC": protected_path, "MarkerSha256": tr.sha256_bytes(marker)}
        write_json(directory / "context.json", context)
        context_hash = tr.sha256_file(directory / "context.json")
        (directory / "prompt.txt").write_text(prompt, encoding="utf-8")
        (directory / "smb-protected-marker.txt").write_bytes(marker)
        sample_path.write_bytes(sample)
        parent = {"IsolationRequestId": diagnostic_id, "VmId": "test-vm", "RequestId": "copy-line-test",
                  "PromptSha256": "formal-prompt", "Inputs": []}
        diagnostic = {"RequestId": diagnostic_id, "VmId": parent["VmId"], "WorkingRoot": working_root,
                      "PromptSha256": tr.sha256_bytes(prompt.encode()),
                      "Inputs": [{"path": "input/sample.txt", "sha256": tr.sha256_bytes(sample)}]}
        write_json(directory / "request.json", diagnostic)
        ready = {"BootEvent": boot, "IsolationContextSha256": context_hash, "Workspace": workspace,
                 "PromptMatches": True, "PromptReadbackSha256": diagnostic["PromptSha256"]}
        write_json(directory / "ready.json", ready)

        def event(kind, seq, data):
            return {"type": kind, "seq": seq, "data": data}

        header = {"type": "session", "version": 4, "id": session, "cwd": workspace,
                  "isSeeded": False, "createdAt": 1}
        end = event("turn/end", 7, {"turn": 1, "reason": {"kind": "completed"}})
        positive = {"turn": 1, "message": {"toolCallId": "sample", "isError": False},
                    "meta": {"path": workspace + r"\input\sample.txt", "offset": 1, "totalLines": 1,
                             "lines": [{"number": 1, "text": "authorized sample"}]}}
        marker_readable = scenario == "readable-marker"
        negative = {"turn": 1, "message": {"toolCallId": "marker", "isError": not marker_readable,
                    "content": [{"type": "text", "text": marker.decode() if marker_readable
                                  else f"ECONNRESET reading {protected_path}"}]}, "error": {"code": "FS_IO_ERROR"}}
        rows = [header, event("turn/start", 1, {"turn": 1}),
                event("user/message", 2, {"content": prompt, "source": {"kind": "user"}}),
                event("tool/call", 3, {"turn": 1, "name": "read", "callId": "sample",
                                      "arguments": json.dumps({"file_path": "input/sample.txt"})}),
                event("tool/result", 4, positive)]
        if scenario != "missing-read":
            rows.extend([event("tool/call", 5, {"turn": 1, "name": "read", "callId": "marker",
                                               "arguments": json.dumps({"file_path": protected_path})}),
                         event("tool/result", 6, negative)])
        trace = directory / "session.v4.jsonl"
        trace.write_bytes(("\n".join(json.dumps(row) for row in [*rows, end]) + "\n").encode())
        report = {"Verdict": "pass", "FinishedAt": "done", "ScenePath": "guest-scene",
                  "Cleanup": {"TaskRemains": 0, "WorkingRootExists": False, "DshRemains": 0,
                              "DiagnosticSessionExists": scenario == "open-diagnostic"},
                  "Completion": {"Acceptance": {"SessionId": session, "AcceptanceVerified": True}, "Turn": 1,
                                 "TurnStatus": "completed", "UserMessageSequence": 2, "NativeTurnEnd": end,
                                 "Basis": "native_turn_end", "TraceName": trace.name, "TraceSha256": tr.sha256_file(trace)}}
        write_json(directory / "report.json", report)
        state = tr.new_state({"request_id": "copy-line-test", "task_id": "copy-line", "task_version": "1"}, None, "formal")
        go = store / "go.json"
        try:
            decision, proof_hash = run_dsh_task.run_isolation(directory, store / "report.json", ledger,
                                                             state, store, parent, 0.2, 0.2)
            formal_ready = {**ready, "Workspace": r"C:\Users\alex_\formal", "IsolationProofSha256": proof_hash}
            if scenario == "changed-boot":
                formal_ready["BootEvent"] = {**boot, "RecordId": 1061}
            if scenario == "changed-config":
                formal_ready["IsolationContextSha256"] = "0" * 64
            if scenario == "changed-proof":
                formal_ready["IsolationProofSha256"] = "0" * 64
            if scenario == "changed-archive":
                archive_receipt = directory / "receipts" / "archived.json"
                archive_receipt.write_bytes(archive_receipt.read_bytes() + b" ")
            run_dsh_task.authorize_send(ledger, go, parent, formal_ready, "formal-test", "formal",
                                       isolation=decision, isolation_sha256=proof_hash)
        except (ValueError, RuntimeError):
            check(f"isolation {scenario} blocks formal authorization", scenario != "pass" and no_formal_permit(ledger, go))
            if scenario == "open-diagnostic":
                proof_hash = "1" * 64
                formal_ready = {**ready, "IsolationProofSha256": proof_hash}
                decision = {"verdict": "pass", "diagnostic_attempt_id": diagnostic_id, "boot_event": boot,
                            "context_sha256": context_hash, "trace_sha256": tr.sha256_file(trace)}
                try:
                    run_dsh_task.authorize_send(ledger, go, parent, formal_ready, "formal-test", "formal",
                                               isolation=decision, isolation_sha256=proof_hash)
                except ValueError as error:
                    check("the formal ledger gate independently requires diagnostic closure",
                          "no closed lifecycle" in str(error) and no_formal_permit(ledger, go))
                else:
                    check("the formal ledger gate independently requires diagnostic closure", False)
            continue
        grant = json.loads(go.read_bytes())
        check("isolation permits formal send only after matching closed diagnostic", scenario == "pass"
              and grant["isolation_context_sha256"] == context_hash and grant["isolation_proof_sha256"] == proof_hash
              and not no_formal_permit(ledger, go))

    try:
        run_dsh_task.authorize_send(ledger, go, parent, ready, "formal-without-proof", "formal")
    except ValueError:
        check("missing isolation proof writes no formal permit", no_formal_permit(ledger, go))
    else:
        check("missing isolation proof writes no formal permit", False)


def main() -> int:
    root = Path(tempfile.mkdtemp(prefix="harness-task-selftest-"))
    try:
        test_freeze(root)
        test_stage_order(root)
        test_outputs(root)
        test_native_turn(root)
        test_ledger(root)
        test_summary(root)
        test_isolation_admission(root / "isolation-fixtures")
    finally:
        shutil.rmtree(root, ignore_errors=True)
    failed = [name for name, ok, _ in RESULTS if not ok]
    print("")
    print(f"{len(RESULTS) - len(failed)}/{len(RESULTS)} checks passed")
    if failed:
        print("failed: " + ", ".join(failed))
        return 1
    print("offline self-test: pass (no virtual machine, no real ledger)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
