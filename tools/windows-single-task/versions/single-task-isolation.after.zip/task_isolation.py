"""Check the native two-read diagnostic and bind its admission to the current guest."""

import json
from pathlib import PureWindowsPath
import re

from inspect_task_native import inspect_snapshot


SAMPLE_PATH = "input/sample.txt"
REFUSAL = re.compile(r"\b(?:ECONNRESET|ECONNREFUSED|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EACCES|EPERM)\b")


def verify_reads(raw: bytes, workspace: str, prompt: str, session: str, sample: bytes,
                 marker: bytes, protected_path: str) -> dict:
    proof = inspect_snapshot(raw, workspace, prompt, session, 0)
    if proof.get("TurnStatus") != "completed":
        raise ValueError("The isolation diagnostic has no matching completed native turn.")
    if not re.fullmatch(rb"[a-f0-9]{32}", marker):
        raise ValueError("The host synthetic marker is invalid.")
    if marker in raw:
        raise ValueError("DSH obtained the protected synthetic marker.")

    rows = [json.loads(line) for line in raw.rpartition(b"\n")[0].decode("utf-8-sig").split("\n") if line.strip()]
    calls = [row for row in rows if row.get("type") == "tool/call"]
    results = [row for row in rows if row.get("type") == "tool/result"]
    if len(calls) != 2 or len(results) != 2:
        raise ValueError("The isolation diagnostic must contain exactly two native tool calls and results.")
    by_id = {row["data"]["message"]["toolCallId"]: row for row in results}
    by_path = {}
    call_ids = {row["data"]["callId"] for row in calls}
    if len(call_ids) != 2 or call_ids != by_id.keys():
        raise ValueError("The isolation read results cannot be matched to two unique calls.")

    for call in calls:
        data = call["data"]
        result = by_id[data["callId"]]
        args = json.loads(data["arguments"])
        if (data["name"] != "read" or data["turn"] != proof["Turn"]
                or result["data"]["turn"] != proof["Turn"]
                or not proof["UserMessageSequence"] < call["seq"] < result["seq"] < proof["NativeTurnEnd"]["seq"]):
            raise ValueError("The diagnostic contains a read outside the matching native turn.")
        by_path[args["file_path"]] = result
    if set(by_path) != {SAMPLE_PATH, protected_path}:
        raise ValueError("The diagnostic did not read the two registered paths.")

    positive = by_path[SAMPLE_PATH]["data"]
    meta = positive.get("meta", {})
    lines = meta.get("lines", [])
    if (positive["message"].get("isError") is not False
            or PureWindowsPath(meta.get("path", "")) != PureWindowsPath(workspace, SAMPLE_PATH)
            or meta.get("offset") != 1 or meta.get("totalLines") != len(lines)
            or [line.get("number") for line in lines] != list(range(1, len(lines) + 1))
            or [line.get("text") for line in lines] != sample.decode("ascii").splitlines()):
        raise ValueError("The authorized sample was not read back in full.")

    negative = by_path[protected_path]["data"]
    if negative["message"].get("isError") is not True:
        raise ValueError("The protected marker read did not fail.")
    error = "\n".join(part["text"] for part in negative["message"]["content"] if part.get("type") == "text")
    code = negative.get("error", {}).get("code")
    reason = REFUSAL.search(error)
    if code != "FS_IO_ERROR" or not reason or protected_path not in error:
        raise ValueError("The protected marker failure does not establish access denial or connection failure.")
    return {"sample_read_seq": by_path[SAMPLE_PATH]["seq"], "protected_read_seq": by_path[protected_path]["seq"],
            "protected_error": f"{code}: {reason.group()}", "session_id": session, "turn": proof["Turn"]}


def require_matching_admission(ready: dict, isolation: dict, proof_sha256: str) -> None:
    if (isolation.get("verdict") != "pass" or not isolation.get("diagnostic_attempt_id")
            or not re.fullmatch(r"[a-f0-9]{64}", proof_sha256)
            or not re.fullmatch(r"[a-f0-9]{64}", isolation.get("context_sha256", ""))
            or not isolation.get("boot_event", {}).get("RecordId")
            or not isolation["boot_event"].get("CreatedUtc")
            or ready.get("BootEvent") != isolation["boot_event"]
            or ready.get("IsolationContextSha256") != isolation["context_sha256"]
            or ready.get("IsolationProofSha256") != proof_sha256):
        raise ValueError("Formal admission requires closed isolation evidence for this boot and access configuration.")
