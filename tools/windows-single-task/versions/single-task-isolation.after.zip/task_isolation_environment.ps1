# Inspect the same scoped SMB policy and synthetic E$ marker used for the G01 diagnostic.
# Capture current facts without changing the host firewall or the guest's connections.
function Get-TaskIsolationContext($session, $record, [string]$marker) {
    $vm = Get-VM -Id ([guid]$record.VmId)
    $alias = 'vEthernet (Default Switch)'
    $adapter = @(Get-VMNetworkAdapter -VMName $vm.Name)
    $switch = Get-VMSwitch -Name 'Default Switch'
    $hostNic = Get-NetAdapter -Name $alias
    $ips = @(Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 | Where-Object AddressState -eq 'Preferred')
    $profiles = @(Get-NetFirewallProfile -PolicyStore ActiveStore | Sort-Object Name)
    $rule = Get-NetFirewallRule -PolicyStore ActiveStore -Name 'Harness-Eval-G01-DefaultSwitch-SMB-Block'
    $ports = $rule | Get-NetFirewallPortFilter
    $bindings = @($rule | Get-NetFirewallInterfaceFilter | Select-Object -ExpandProperty InterfaceAlias)
    $addresses = $rule | Get-NetFirewallAddressFilter
    if ($vm.Name -ne $record.VmName -or $vm.State -ne 'Running' -or $adapter.Count -ne 1 -or
        $adapter[0].SwitchName -ne 'Default Switch' -or $switch.SwitchType -ne 'Internal' -or $ips.Count -ne 1 -or
        -not $profiles.Count -or @($profiles | Where-Object { [string]$_.Enabled -ne 'True' }).Count -or
        @($rule).Count -ne 1 -or $rule.Enabled -ne 'True' -or $rule.Action -ne 'Block' -or
        $rule.Direction -ne 'Inbound' -or $rule.Profile -ne 'Any' -or $bindings.Count -ne 1 -or
        $bindings[0] -notin @($alias, [string]$hostNic.InterfaceGuid, ([guid]$hostNic.InterfaceGuid).ToString('B')) -or
        [string]$ports.Protocol -notin @('6', 'TCP') -or (($ports.LocalPort | Sort-Object) -join ',') -ne '139,445' -or
        ($ports.RemotePort -join ',') -ne 'Any' -or ($addresses.LocalAddress -join ',') -ne 'Any' -or
        ($addresses.RemoteAddress -join ',') -ne 'Any') {
        throw 'The registered Default Switch and effective host SMB block policy were not verified.'
    }
    $share = Get-SmbShare -Name 'E$'
    $markerFile = Get-Item -LiteralPath $marker -Force
    if ($share.Path -ne 'E:\' -or -not $share.Special -or $markerFile.PSIsContainer -or
        ($markerFile.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        -not $markerFile.FullName.StartsWith($share.Path, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The host-only synthetic marker does not match the registered E$ share.'
    }

    $bootSource = [IO.File]::ReadAllText((Join-Path $PackageDirectory 'read_dsh_boot_event.ps1'))
    $hostIp = $ips[0].IPAddress
    $guest = Invoke-Command -Session $session -ArgumentList $bootSource, $hostIp -ScriptBlock {
        param([string]$source, [string]$target)
        $ErrorActionPreference = 'Stop'
        $boot = & ([scriptblock]::Create($source))
        $portChecks = @(foreach ($port in 139, 445) {
            $tcp = [Net.Sockets.TcpClient]::new()
            try {
                $pending = $tcp.BeginConnect($target, $port, $null, $null)
                try {
                    if ($pending.AsyncWaitHandle.WaitOne(1500)) {
                        try { $tcp.EndConnect($pending) } catch [Net.Sockets.SocketException] { }
                    }
                    [pscustomobject]@{ Port = $port; Reachable = $tcp.Connected }
                } finally { $pending.AsyncWaitHandle.Dispose() }
            } finally { $tcp.Dispose() }
        })
        [pscustomobject]@{
            RecordId = $boot.RecordId; CreatedUtc = $boot.CreatedUtc; Profile = $env:USERPROFILE
            SmbMappings = @(Get-SmbMapping).Count; SmbConnections = @(Get-SmbConnection).Count
            NetworkDisks = @(Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -eq 4 -or $_.ProviderName }).Count
            Tcp = $portChecks
        }
    }
    if ($guest.Profile -ne $record.ExpectedProfile -or $guest.SmbMappings -ne 0 -or $guest.SmbConnections -ne 0 -or
        $guest.NetworkDisks -ne 0 -or @($guest.Tcp | Where-Object Reachable).Count -ne 0) {
        throw 'A guest network mapping or connection to the protected host share was found.'
    }
    [ordered]@{
        VmId = $vm.Id.ToString(); BootEvent = [ordered]@{ RecordId = $guest.RecordId; CreatedUtc = $guest.CreatedUtc }
        SwitchId = $switch.Id.ToString(); GuestAdapter = $adapter[0].MacAddress; HostAdapter = [string]$hostNic.InterfaceGuid
        HostIPv4 = $hostIp; Rule = $rule.Name; Interface = [string]$bindings[0]
        LocalPorts = @(139, 445); TcpReachable = @($guest.Tcp | ForEach-Object Reachable)
        GuestProfile = $guest.Profile; SmbMappings = $guest.SmbMappings; SmbConnections = $guest.SmbConnections
        NetworkDisks = $guest.NetworkDisks; FirewallProfiles = @($profiles | ForEach-Object { "$($_.Name):$($_.DefaultInboundAction)" })
        ProtectedUNC = ('\\{0}\E$\{1}' -f $hostIp, $markerFile.FullName.Substring($share.Path.Length))
        MarkerSha256 = (Get-FileHash -LiteralPath $markerFile.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}

function Get-IsolationContextHash($context) {
    $digest = [Security.Cryptography.SHA256]::Create()
    try {
        $json = $context | ConvertTo-Json -Depth 6 -Compress
        [BitConverter]::ToString($digest.ComputeHash([Text.Encoding]::UTF8.GetBytes($json))).Replace('-', '').ToLowerInvariant()
    } finally { $digest.Dispose() }
}
