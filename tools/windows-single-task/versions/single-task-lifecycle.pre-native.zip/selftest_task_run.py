"""Offline checks for the single-task entry: no virtual machine, no real ledger.

The point is to prove the parts that decide correctness before anything touches Hyper-V:
freezing is idempotent, a changed task is refused, stages only move forward, missing and
unreadable outputs stay distinguishable, and the ledger still refuses to close without a
submission plus the four receipts.
"""

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import shutil
import sys
import tempfile

import run_dsh_task
import task_request as tr
from attempt_completion import CompletionNotVerified, close_completed_attempt, initialize_completion_table
from attempt_ledger import initialize_attempt_ledger, register_attempt
from submission_permit import (
    initialize_submission_tables,
    begin_submission,
    issue_submission_permit,
)

RESULTS = []


def check(name, condition, detail=""):
    RESULTS.append((name, bool(condition), detail))
    print(f"{'PASS' if condition else 'FAIL'} {name}" + (f" — {detail}" if detail and not condition else ""))


def make_task(root: Path, prompt: str = "读取 input/sample.txt，把这一行原样写入 output/result.txt，然后回复“已完成”。") -> Path:
    package = root / "tasks" / "copy-line-v1"
    (package / "input").mkdir(parents=True, exist_ok=True)
    (package / "input" / "sample.txt").write_text("第一行样本\n", encoding="utf-8")
    manifest = {
        "task_id": "copy-line",
        "version": "1",
        "prompt": prompt,
        "inputs": ["input/sample.txt"],
        "outputs": ["output/result.txt"],
        "expect": {"output/result.txt": "第一行样本\n"},
    }
    path = package / "task.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
    return path


def test_freeze(root: Path):
    task = make_task(root)
    store = root / "requests" / "demo-001"
    record, reused = tr.freeze_request(store, "demo-001", task)
    check("freeze writes a record", (store / "request.json").is_file() and not reused)
    check("freeze pins the prompt hash", record["prompt_sha256"] == tr.sha256_bytes(record["prompt"].encode("utf-8")))
    check("freeze pins the input hash", record["inputs"][0]["sha256"] == tr.sha256_file(task.parent / "input" / "sample.txt"))

    same, reused_again = tr.freeze_request(store, "demo-001", task)
    check("a repeat freeze reuses the record", reused_again and same["prompt_sha256"] == record["prompt_sha256"])

    changed = make_task(root, prompt="换成另一道题")
    try:
        tr.freeze_request(store, "demo-001", changed)
        check("a changed prompt is refused", False, "no exception")
    except tr.RequestConflict:
        check("a changed prompt is refused", True)


def test_stage_order(root: Path):
    state = tr.new_state({"request_id": "demo-001", "task_id": "copy-line", "task_version": "1"}, None, "formal")
    tr.advance(state, "restored")
    tr.advance(state, "dispatched")
    check("stages advance forward", state["stage"] == "dispatched")
    try:
        tr.advance(state, "prepared")
        check("stages refuse to move backwards", False, "no exception")
    except tr.TaskLayoutError:
        check("stages refuse to move backwards", True)
    check("stage_reached is monotonic", tr.stage_reached(state, "prepared") and not tr.stage_reached(state, "closed"))


def test_outputs(root: Path):
    record = {"outputs": ["output/result.txt"], "expect": {"output/result.txt": "第一行样本\n"}}
    results = root / "results"
    (results / "output").mkdir(parents=True, exist_ok=True)

    check("missing output is named as missing",
          tr.verify_outputs(results, record)["verdict"] == "task_missing_output")

    (results / "output" / "result.txt").write_text("第一行样本\n", encoding="utf-8")
    passing = tr.verify_outputs(results, record)
    check("correct content passes", passing["verdict"] == "pass" and passing["files"][0]["matches_expect"])

    (results / "output" / "result.txt").write_text("第一行样本\n多出来一行\n", encoding="utf-8")
    wrong = tr.verify_outputs(results, record)
    check("wrong content is its own verdict", wrong["verdict"] == "task_wrong_content")

    (results / "output" / "result.txt").write_bytes(b"\xff\xfe\x00broken")
    unreadable = tr.verify_outputs(results, record)
    check("unreadable content is not called a wrong answer",
          unreadable["verdict"] == "collection_incomplete")

    (results / "output" / "result.txt").write_text("第一行样本\n\n", encoding="utf-8")
    tolerant = tr.verify_outputs(results, record)
    check("one trailing newline is tolerated", tolerant["verdict"] == "pass")


def test_ledger(root: Path):
    ledger = root / "attempts.sqlite3"
    initialize_attempt_ledger(ledger)
    initialize_submission_tables(ledger)
    initialize_completion_table(ledger)
    attempt_id = "TASK-demo-001-abc12345"
    register_attempt(ledger, attempt_id, "formal")
    expires = datetime.now(timezone.utc) + timedelta(minutes=15)
    permit = issue_submission_permit(ledger, attempt_id, "fp-1", expires)

    receipts = root / "receipts" / attempt_id
    report = {
        "Dispatch": {"MessageCountAfterSend": 1, "SendClicks": 1, "PromptReadbackSha256": "p"},
        "Completion": {"Basis": "ui_idle_stable_reply", "NativeTurnEnd": None, "ReplySha256": "r"},
        "FinalRestore": {"Verdict": "pass", "BootEvent": {"RecordId": 1061}, "Residue": []},
        "Cleanup": {"TaskRemains": 0},
    }
    results = {"verdict": "pass", "files": [], "host_root": str(root / "results")}

    try:
        close_completed_attempt(ledger, attempt_id, receipts)
        check("closing without a submission is refused", False, "no exception")
    except CompletionNotVerified:
        check("closing without a submission is refused", True)

    begin_submission(ledger, attempt_id, permit, "fp-1")
    try:
        close_completed_attempt(ledger, attempt_id, receipts)
        check("closing without receipts is refused", False, "no exception")
    except CompletionNotVerified:
        check("closing without receipts is refused", True)

    run_dsh_task.write_receipts(receipts, attempt_id, report, results)
    close_completed_attempt(ledger, attempt_id, receipts)
    import sqlite3
    with sqlite3.connect(ledger) as connection:
        closed_at = connection.execute(
            "SELECT closed_at FROM attempts WHERE attempt_id = ?", (attempt_id,)).fetchone()[0]
        evidence = connection.execute(
            "SELECT evidence_json FROM attempt_completion WHERE attempt_id = ?", (attempt_id,)).fetchone()[0]
    check("a complete set of receipts closes the attempt", closed_at is not None)
    check("the closing evidence keeps all four receipts",
          set(json.loads(evidence)) == {"accepted", "terminated", "archived", "cleaned"})


def test_summary(root: Path):
    store = root / "requests" / "demo-001"
    record = json.loads((store / "request.json").read_text(encoding="utf-8"))
    state = tr.new_state(record, "TASK-demo-001-abc12345", "formal")
    state["stage"] = "closed"
    state["result"] = {"task_result": "pass", "submissions": {"formal": 1, "diagnostic": 0}}
    tr.save_state(store, state)
    summary = tr.summarize(store)
    check("summary reports the final stage and submissions",
          summary["stage"] == "closed" and summary["submissions"]["formal"] == 1)


def main() -> int:
    root = Path(tempfile.mkdtemp(prefix="harness-task-selftest-"))
    try:
        test_freeze(root)
        test_stage_order(root)
        test_outputs(root)
        test_ledger(root)
        test_summary(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    failed = [name for name, ok, _ in RESULTS if not ok]
    print("")
    print(f"{len(RESULTS) - len(failed)}/{len(RESULTS)} checks passed")
    if failed:
        print("failed: " + ", ".join(failed))
        return 1
    print("offline self-test: pass (no virtual machine, no real ledger)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
