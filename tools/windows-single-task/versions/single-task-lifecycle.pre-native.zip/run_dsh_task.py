"""Run one prepared task through the controlled DSH desktop and close its record.

The entry owns everything that must be durable: it freezes the task, keeps the request
stage on disk, and is the only process that writes the attempt ledger, the one-time
submission permit, and the four closing receipts. The elevated stage only drives the
virtual machine, and it pauses before sending until this process authorises the send, so
"the permit is consumed" always happens strictly before "the interface sends".
"""

import argparse
import hashlib
import json
import os
from contextlib import closing
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from attempt_completion import CompletionNotVerified, close_completed_attempt
from attempt_ledger import UnclosedAttempt, register_attempt, require_no_open_attempt
from host_powershell import windows_powershell
from startup_lock import StartupLockBusy, WINDOWS_LOCK_DATABASE, acquire_startup_lock
from submission_permit import (
    PermitUnavailable,
    begin_submission,
    issue_submission_permit,
)
from task_request import (
    RequestConflict,
    advance,
    freeze_request,
    load_state,
    new_state,
    save_state,
    sha256_bytes,
    sha256_file,
    stage_reached,
    summarize,
    verify_outputs,
)

VM_ID = "72d3b668-2aa5-4719-bad7-95e6ba990090"
VM_NAME = "Harness-DSH-Win11"
CHECKPOINT_NAME = "DSH-Win11-Base-v2"
CHECKPOINT_ID = "cdc3f478-1b98-44f0-8948-5e843d1fb0c7"
EXPECTED_PROFILE = r"C:\Users\alex_"
SHORTCUT_NAME = "DeepSeek Harness - Accessibility.lnk"


def control_root() -> Path:
    return WINDOWS_LOCK_DATABASE.parent


def ledger_path(root: Path) -> Path:
    return root / "attempts.sqlite3"


def request_store(root: Path, request_id: str) -> Path:
    return root / "requests" / request_id


def stage_request(root: Path, record: dict, attempt_prefix: str,
                  prompt_timeout: float, task_timeout: float,
                  wait_signin: int = 0, attach: bool = False) -> dict:
    """What the elevated stage needs. The prompt travels as a file, never as a command line."""
    return {
        "RequestId": record["request_id"],
        "AttemptPrefix": attempt_prefix,
        "Activity": "diagnostic" if attach else "formal",
        "Attach": bool(attach),
        "CaseVersion": f"single task {record['task_id']} v{record['task_version']}",
        "ProductVersion": "0.2.2.0 installed (not queried by the stage)",
        "TaskId": record["task_id"],
        "TaskVersion": record["task_version"],
        "PromptSha256": record["prompt_sha256"],
        "Inputs": record["inputs"],
        "Outputs": record["outputs"],
        "VmId": VM_ID,
        "VmName": VM_NAME,
        "CheckpointId": CHECKPOINT_ID,
        "CheckpointName": CHECKPOINT_NAME,
        "ExpectedProfile": EXPECTED_PROFILE,
        "ShortcutName": SHORTCUT_NAME,
        "AccessibilityArgument": "--force-renderer-accessibility=complete",
        "StageDirectory": str(root / "requests" / record["request_id"] / "stage"),
        "WorkingRoot": rf"{EXPECTED_PROFILE}\AppData\Local\Temp\{record['request_id']}",
        "PromptTimeoutSeconds": int(prompt_timeout),
        "TaskTimeoutSeconds": int(task_timeout),
        "WaitForSignInSeconds": int(wait_signin),
        "RequestedAt": datetime.now(timezone.utc).isoformat(),
    }


def write_wrapper(store: Path, package: Path) -> Path:
    """The elevated process: credential helper, the stage script, then an exit marker."""
    helper = (package / "harness_guest_credential.ps1").read_text(encoding="utf-8")
    text = "\n".join([
        "param([string]$StageDirectory, [string]$PackageDirectory)",
        "$ErrorActionPreference = 'Stop'",
        helper,
        "$log = Join-Path $StageDirectory 'host-log.txt'",
        "$code = 1",
        "$failure = $null",
        "Start-Transcript -LiteralPath $log -Force | Out-Null",
        "try {",
        "    $source = [IO.File]::ReadAllText((Join-Path $PackageDirectory 'run_dsh_task_stage.ps1'))",
        "    $null = & ([scriptblock]::Create($source)) -StageDirectory $StageDirectory -PackageDirectory $PackageDirectory",
        "    $code = 0",
        "} catch {",
        "    $failure = $_ | Out-String",
        "} finally {",
        "    Stop-Transcript | Out-Null",
        "    if ($failure) { Add-Content -LiteralPath $log -Value $failure -Encoding UTF8 }",
        "    [pscustomobject]@{ ExitCode = $code; FinishedAt = (Get-Date).ToString('o') } | "
        "ConvertTo-Json | Set-Content -LiteralPath (Join-Path $StageDirectory 'elevated-exit.json') -Encoding UTF8",
        "}",
        "exit $code",
        "",
    ])
    path = store / "run-task-stage.ps1"
    path.write_text(text, encoding="utf-8")
    return path


def launch_elevated(wrapper: Path, stage_directory: Path, package: Path) -> None:
    powershell = windows_powershell()
    arguments = ["-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(wrapper),
                 "-StageDirectory", str(stage_directory), "-PackageDirectory", str(package)]
    quoted = ", ".join("'" + item.replace("'", "''") + "'" for item in arguments)
    command = (f"Start-Process -FilePath '{powershell}' -Verb RunAs "
               f"-ArgumentList @({quoted}) -WorkingDirectory '{stage_directory}'")
    subprocess.run([str(powershell), "-NoLogo", "-NoProfile", "-Command", command], check=False)


def launch_elevated_script(script: Path, arguments: list[str]) -> None:
    """Start one prepared script elevated and return without waiting for it."""
    powershell = windows_powershell()
    full = ["-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script), *arguments]
    quoted = ", ".join("'" + item.replace("'", "''") + "'" for item in full)
    command = (f"Start-Process -FilePath '{powershell}' -Verb RunAs "
               f"-ArgumentList @({quoted}) -WorkingDirectory '{script.parent}'")
    subprocess.run([str(powershell), "-NoLogo", "-NoProfile", "-Command", command], check=False)


def collect_sources(request_id: str, store: Path, root: Path) -> int:
    """Copy the guest probe directory back so a failed run can be explained afterwards.

    The probe writes its report and screenshots inside the guest, and reading them needs the same
    elevation the stage already has, so this runs as its own elevated helper.
    """
    destination = store / "guest"
    destination.mkdir(parents=True, exist_ok=True)
    credential = (Path(os.environ["LOCALAPPDATA"]) / "Harness-Eval" / "Credentials"
                  / f"{VM_NAME}.xml")
    guest_path = rf"C:\Users\alex_\AppData\Local\Temp\{request_id}\probe"
    text = "\n".join([
        "param([string]$GuestPath, [string]$Destination, [string]$CredentialPath)",
        "$ErrorActionPreference = 'Stop'",
        f"$log = Join-Path '{destination}' 'collect-log.txt'",
        "Start-Transcript -LiteralPath $log -Force | Out-Null",
        "try {",
        "    $cred = Import-Clixml $CredentialPath",
        f"    $vm = Get-VM -Name '{VM_NAME}'",
        "    $session = New-PSSession -VMId $vm.Id -Credential $cred",
        "    if (-not (Test-Path -LiteralPath $GuestPath -PathType Container -ErrorAction SilentlyContinue)) { }",
        "    Copy-Item -FromSession $session -LiteralPath $GuestPath -Destination $Destination -Recurse -Force",
        "    Remove-PSSession $session",
        "    'copied' | Write-Output",
        "} catch {",
        "    ('ERROR: ' + $_.Exception.Message) | Write-Output",
        "} finally {",
        "    Stop-Transcript | Out-Null",
        f"    'done' | Set-Content -LiteralPath (Join-Path '{destination}' 'finished.txt') -Encoding UTF8",
        "}",
        "",
    ])
    script = store / "collect-guest.ps1"
    script.write_text(text, encoding="utf-8")
    launch_elevated_script(script, [guest_path, str(destination), str(credential)])
    print(f"Waiting for the elevated collector. Confirm the Windows administrator prompt.")
    marker = destination / "finished.txt"
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        if marker.exists():
            break
        time.sleep(2)
    if not marker.exists():
        print("The collector did not finish inside the allowed time.", file=sys.stderr)
        return 1
    landed = destination / "probe"
    print(f"Collected: {landed}")
    for item in sorted(landed.rglob("*")) if landed.exists() else []:
        if item.is_file():
            print(f"  {item.relative_to(destination)}  {item.stat().st_size} B")
    return 0


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def wait_for_ready(report_path: Path, ready_path: Path, timeout: float) -> dict:
    """Block until the guest has pasted the prompt and read it back, or the stage stops."""
    deadline = time.monotonic() + timeout
    last_stage = None
    while time.monotonic() < deadline:
        ready = read_json(ready_path)
        if ready:
            return ready
        report = read_json(report_path)
        if report and report.get("Stage") != last_stage:
            last_stage = report.get("Stage")
            print(f"stage: {last_stage}", flush=True)
        if report and report.get("FinishedAt"):
            raise RuntimeError(f"The stage stopped before the prompt was ready: {report.get('Error')}")
        time.sleep(2)
    raise TimeoutError("The prompt was not pasted inside the allowed time.")


def wait_for_report(report_path: Path, timeout: float) -> dict:
    deadline = time.monotonic() + timeout
    last_stage = None
    while time.monotonic() < deadline:
        report = read_json(report_path)
        if report and report.get("FinishedAt"):
            return report
        if report and report.get("Stage") != last_stage:
            last_stage = report.get("Stage")
            print(f"stage: {last_stage}", flush=True)
        time.sleep(2)
    raise TimeoutError("The task stage did not finish inside the allowed time.")


def write_receipts(directory: Path, attempt_id: str, report: dict, results: dict) -> None:
    """Four receipts, each naming the evidence it rests on and what it does not prove."""
    directory.mkdir(parents=True, exist_ok=True)
    dispatch = report.get("Dispatch") or {}
    completion = report.get("Completion") or {}
    cleanup = report.get("FinalRestore") or {}
    receipts = {
        "accepted": {
            "event": "accepted",
            "detail": {
                "message_count": dispatch.get("MessageCountAfterSend"),
                "send_clicks": dispatch.get("SendClicks"),
                "send_control_name": dispatch.get("SendControlName"),
                "send_state_after_click": dispatch.get("SendStateAfterClick"),
                "composer_empty_after_send": dispatch.get("ComposerEmptyAfterSend"),
                "prompt_readback_sha256": dispatch.get("PromptReadbackSha256"),
                "source": "guest UI Automation after one send click",
            },
        },
        "terminated": {
            "event": "terminated",
            "detail": {
                "basis": completion.get("Basis"),
                "native_turn_end": completion.get("NativeTurnEnd"),
                "busy_observed": completion.get("BusyObserved"),
                "final_send_name": completion.get("FinalSendName"),
                "baseline_length": completion.get("BaselineLength"),
                "final_length": completion.get("FinalLength"),
                "state_samples": completion.get("StateSamples"),
                "reply_sha256": completion.get("ReplySha256"),
                "observed_seconds": completion.get("ObservedSeconds"),
                "note": completion.get("Note"),
                "does_not_prove": "The send control transition shows the product's own turn boundary; "
                                  "it does not identify which model produced the reply.",
            },
        },
        "archived": {
            "event": "archived",
            "detail": {
                "verdict": results.get("verdict"),
                "files": results.get("files"),
                "host_root": results.get("host_root"),
            },
        },
        "cleaned": {
            "event": "cleaned",
            "detail": {
                "verdict": cleanup.get("Verdict"),
                "boot_event": cleanup.get("BootEvent"),
                "residue": cleanup.get("Residue"),
                "guest_task_remains": (report.get("Cleanup") or {}).get("TaskRemains"),
            },
        },
    }
    for name, payload in receipts.items():
        body = {"attempt_id": attempt_id, "at": datetime.now(timezone.utc).isoformat(), **payload}
        (directory / f"{name}.json").write_text(json.dumps(body, ensure_ascii=False, indent=2),
                                                encoding="utf-8")


def abandon_unsubmitted(ledger: Path, attempt_id: str, store: Path, reason: str) -> Path | None:
    """Close an attempt that never received a permit. Nothing was sent, so nothing is owed.

    An attempt that did get a permit is refused: the permit is evidence that a send may have
    happened, and only an operator can decide how that ends.
    """
    uri = ledger.resolve().as_uri() + "?mode=rw"
    with closing(sqlite3.connect(uri, uri=True, timeout=0)) as connection, connection:
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT closed_at FROM attempts WHERE attempt_id = ?", (attempt_id,)).fetchone()
        if not row or row[0]:
            return None
        if connection.execute("SELECT 1 FROM submissions WHERE attempt_id = ?", (attempt_id,)).fetchone():
            raise RuntimeError("A submission record exists; the attempt cannot be abandoned this way")
        if connection.execute("SELECT 1 FROM submission_permits WHERE attempt_id = ?", (attempt_id,)).fetchone():
            raise RuntimeError("A permit exists; the attempt cannot be abandoned this way")
        closed_at = datetime.now(timezone.utc).isoformat()
        payload = json.dumps({
            "attempt_id": attempt_id,
            "outcome": "blocked_before_permit",
            "recorded_at_utc": closed_at,
            "reason": reason,
            "permits_issued": 0,
            "submissions_written": 0,
        }, indent=2).encode("utf-8")
        path = store / f"recovery-{uuid4().hex[:8]}.json"
        path.write_bytes(payload)
        connection.execute("INSERT INTO attempt_recovery VALUES (?, ?, ?, ?)",
                           (attempt_id, "blocked_before_permit", str(path),
                            hashlib.sha256(payload).hexdigest()))
        connection.execute("UPDATE attempts SET closed_at = ? WHERE attempt_id = ?", (closed_at, attempt_id))
    return path


def run(record: dict, state: dict, store: Path, root: Path, package: Path,
        timeout: float, prompt_timeout: float, wait_signin: int = 0,
        attach: bool = False) -> int:
    stage_directory = store / "stage"
    stage_directory.mkdir(parents=True, exist_ok=True)
    request = stage_request(root, record, f"TASK-{record['request_id']}",
                            prompt_timeout, timeout, wait_signin, attach)
    (stage_directory / "request.json").write_text(json.dumps(request, ensure_ascii=False, indent=2),
                                                  encoding="utf-8")
    (stage_directory / "prompt.txt").write_text(record["prompt"], encoding="utf-8")
    # Inputs travel as files so the stage copies bytes, never a re-typed string.
    inputs_directory = stage_directory / "inputs"
    if inputs_directory.exists():
        shutil.rmtree(inputs_directory)
    task_root = Path(record["task_file"]).parent
    for item in record["inputs"]:
        target = inputs_directory / item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(task_root / item["path"], target)
    wrapper = write_wrapper(store, package)

    report_path = stage_directory / "report.json"
    ready_path = stage_directory / "ready.json"
    go_path = stage_directory / "go.json"
    for stale in (report_path, ready_path, go_path):
        if stale.exists():
            stale.unlink()

    launch_elevated(wrapper, stage_directory, package)
    print("Waiting for the elevated stage. Confirm the Windows administrator prompt.", flush=True)

    ready = wait_for_ready(report_path, ready_path, prompt_timeout + wait_signin + 60)
    if not ready.get("PromptMatches"):
        raise RuntimeError("The composer text did not read back as the frozen prompt.")
    # The stage name stays "restored" so the ordering model is unchanged; the detail records
    # that an attached run did not come from the registered baseline.
    advance(state, "restored",
            {"boot_event": ready.get("BootEvent"), "baseline_restored": not attach})
    save_state(store, state)

    attempt_id = f"TASK-{record['request_id']}-{uuid4().hex[:8]}"
    ledger = ledger_path(root)
    fingerprint = sha256_bytes(json.dumps({
        "request_id": record["request_id"],
        "attempt_id": attempt_id,
        "prompt_sha256": record["prompt_sha256"],
        "workspace": ready.get("Workspace"),
        "boot_event": ready.get("BootEvent"),
    }, sort_keys=True).encode("utf-8"))

    # An attached run reuses a signed-in desktop that was not started from the registered
    # baseline, so it is recorded as a diagnostic attempt and never compared with formal runs.
    attempt_kind = "diagnostic" if attach else "formal"
    register_attempt(ledger, attempt_id, attempt_kind)
    state["attempt_id"] = attempt_id
    save_state(store, state)

    permit_id = issue_submission_permit(
        ledger, attempt_id, fingerprint,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=15),
        kind=attempt_kind)
    begin_submission(ledger, attempt_id, permit_id, fingerprint)
    advance(state, "prepared", {"attempt_id": attempt_id, "workspace": ready.get("Workspace")})
    save_state(store, state)

    go_path.write_text(json.dumps({
        "attempt_id": attempt_id,
        "permit_id": permit_id,
        "binding_fingerprint": fingerprint,
        "prompt_sha256": record["prompt_sha256"],
        "authorized_at": datetime.now(timezone.utc).isoformat(),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    advance(state, "dispatched", {"permit_id": permit_id})
    save_state(store, state)

    report = wait_for_report(report_path, timeout)
    dispatch = report.get("Dispatch") or {}
    if int(dispatch.get("SendClicks") or 0) != 1:
        # The permit is consumed but the interface never sent. The attempt stays open on
        # purpose: only an operator can decide whether this counts as a run of the task.
        raise RuntimeError(
            "No send click was recorded. The permit is consumed, nothing was submitted, "
            "and the attempt stays open for an operator decision.")

    # The running state is the turn boundary. Without it a fast reply and a send that never
    # started look the same, so the attempt is left open instead of being closed on a guess.
    completion = report.get("Completion") or {}
    if not completion.get("BusyObserved"):
        raise RuntimeError(
            "The send control never entered its running state, so the turn boundary is "
            "unconfirmed; the permit is consumed and the attempt stays open for an operator decision.")

    stage_results = stage_directory / "results"
    verification = verify_outputs(stage_results, record)
    # Copy fidelity: the stage records the guest-side hash of every declared output, so the
    # host copy is judged against the guest bytes instead of being trusted on its own.
    fidelity = []
    for item in (report.get("Outputs") or []):
        relative = item.get("Path")
        host_file = stage_results / relative if relative else None
        matches = bool(host_file and host_file.is_file()
                       and sha256_file(host_file) == item.get("Sha256"))
        fidelity.append({"path": relative, "guest_sha256": item.get("Sha256"),
                         "host_matches": matches})
    if fidelity and not all(entry["host_matches"] for entry in fidelity):
        if verification["verdict"] == "pass":
            verification["verdict"] = "collection_incomplete"
    results_payload = {
        "verdict": verification["verdict"],
        "files": verification["files"],
        "copy": fidelity,
        "host_root": str(stage_results),
    }
    advance(state, "completed", {"completion": report.get("Completion")})
    save_state(store, state)

    receipt_dir = store / "receipts" / attempt_id
    write_receipts(receipt_dir, attempt_id, report, results_payload)
    advance(state, "retrieved", verification)
    save_state(store, state)

    state["result"] = {
        "task_result": verification["verdict"],
        "verification": verification,
        "completion": report.get("Completion"),
        "dispatch": report.get("Dispatch"),
        "restore": report.get("FinalRestore"),
        "submissions": {"formal": report.get("FormalSubmissions", 0),
                        "diagnostic": report.get("DiagnosticSubmissions", 0)},
        "manual_steps": report.get("ManualSteps"),
    }
    save_state(store, state)

    if verification["verdict"] == "collection_incomplete":
        state["failure"] = "Result collection was incomplete; the attempt stays open for a re-collect."
        save_state(store, state)
        print_json(summarize(store))
        return 1

    close_completed_attempt(ledger, attempt_id, receipt_dir, kind=attempt_kind)
    advance(state, "closed", {"attempt_id": attempt_id})
    save_state(store, state)
    print_json(summarize(store))
    return 0 if verification["verdict"] == "pass" else 4


def print_json(payload) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def command_run(args, root: Path, package: Path) -> int:
    attach = bool(getattr(args, "attach", False))
    store = request_store(root, args.request_id)
    try:
        record, reused = freeze_request(store, args.request_id, Path(args.task))
    except RequestConflict as error:
        print(f"Refused: {error}", file=sys.stderr)
        return 5
    state = load_state(store)
    if state and stage_reached(state, "dispatched"):
        print("This request already reached the send stage; showing the stored progress instead.")
        print_json(summarize(store))
        return 0
    if reused:
        print(f"Reusing the frozen task for request {args.request_id}.")

    if getattr(args, "dry_run", False):
        print_json({
            "request_id": record["request_id"],
            "task": f"{record['task_id']} v{record['task_version']}",
            "prompt_sha256": record["prompt_sha256"],
            "inputs": record["inputs"],
            "outputs": record["outputs"],
            "expect": record["expect"],
            "would_send": 1,
            "note": "Nothing was restored, launched, or sent; only the frozen record was written.",
        })
        return 0

    lock = root / "startup-lock.sqlite3"
    try:
        with acquire_startup_lock(lock):
            require_no_open_attempt(ledger_path(root))
            if state is None:
                state = new_state(record, None, "diagnostic" if attach else "formal")
                save_state(store, state)
            return run(record, state, store, root, package, args.timeout, args.prompt_timeout,
                       getattr(args, "wait_signin", 0), attach)
    except StartupLockBusy:
        print("Blocked: another run holds the startup lock.", file=sys.stderr)
        return 3
    except UnclosedAttempt as error:
        print(f"Blocked: {error}. Close or resume that attempt first.", file=sys.stderr)
        return 3
    except PermitUnavailable as error:
        _record_failure(store, f"the submission permit was not available: {error}")
        print(f"Blocked: the submission permit was not available ({error}).", file=sys.stderr)
        return 1
    except CompletionNotVerified as error:
        _record_failure(store, f"refused to close the attempt: {error}")
        print(f"Refused to close the attempt: {error}", file=sys.stderr)
        return 1
    except (OSError, ValueError, RuntimeError, TimeoutError, sqlite3.Error) as error:
        _record_failure(store, str(error))
        print(f"Task run stopped: {error}", file=sys.stderr)
        return 1
    finally:
        # A run that never reached the permit stage owes nothing. Leaving its record open would
        # block every later run for a reason that has no evidence behind it.
        attempt_id = (state or {}).get("attempt_id")
        if attempt_id:
            try:
                closed = abandon_unsubmitted(
                    ledger_path(root), attempt_id, store,
                    "the run stopped before a submission permit was issued")
                if closed:
                    print(f"Unsubmitted attempt closed: {attempt_id} ({closed.name})", file=sys.stderr)
            except (OSError, RuntimeError, sqlite3.Error) as error:
                print(f"The unsubmitted attempt could not be closed: {error}", file=sys.stderr)


def _record_failure(store: Path, message: str) -> None:
    """Keep the reason on the request so a resume starts from what actually happened."""
    state = load_state(store)
    if state is None:
        return
    state["failure"] = message
    save_state(store, state)


def command_status(args, root: Path) -> int:
    store = request_store(root, args.request_id)
    if not (store / "request.json").exists():
        print(f"No request named {args.request_id}.")
        return 2
    print_json(summarize(store))
    return 0


def command_resume(args, root: Path, package: Path) -> int:
    store = request_store(root, args.request_id)
    if not (store / "request.json").exists():
        print(f"No request named {args.request_id}.")
        return 2
    record = json.loads((store / "request.json").read_text(encoding="utf-8"))
    state = load_state(store)
    if state is None:
        print("The request was frozen but never started; rerun it instead of resuming.")
        return 2
    if stage_reached(state, "closed"):
        print("This request is already closed; returning the stored result.")
        print_json(summarize(store))
        return 0
    if not stage_reached(state, "dispatched"):
        print("Nothing was sent yet, so the run is restarted from the beginning.")
        args.task = args.task or record["task_file"]
        return command_run(args, root, package)
    # A send already happened. Re-sending is never allowed, so only the evidence gap is reported.
    print("A send was already recorded for this request; automatic re-send is disabled.")
    print_json(summarize(store))
    return 4


def void_attempt(ledger: Path, attempt_id: str, store: Path, reason: str) -> Path | None:
    """Close a record whose permit was consumed but whose send an operator watched fail.

    A consumed permit normally blocks every automatic path, because it is evidence that a send
    may have happened. Only a person looking at the product can rule that out, so the record
    keeps the operator's reason next to the permit and submission counts.
    """
    uri = ledger.resolve().as_uri() + "?mode=rw"
    with closing(sqlite3.connect(uri, uri=True, timeout=0)) as connection, connection:
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT closed_at FROM attempts WHERE attempt_id = ?", (attempt_id,)).fetchone()
        if not row or row[0]:
            return None
        permit = connection.execute(
            "SELECT permit_id, consumed_at FROM submission_permits WHERE attempt_id = ?",
            (attempt_id,)).fetchone()
        submissions = connection.execute(
            "SELECT COUNT(*) FROM submissions WHERE attempt_id = ?", (attempt_id,)).fetchone()[0]
        closed_at = datetime.now(timezone.utc).isoformat()
        payload = json.dumps({
            "attempt_id": attempt_id,
            "outcome": "operator_voided_unsent",
            "recorded_at_utc": closed_at,
            "reason": reason,
            "operator": os.environ.get("USERNAME"),
            "permits_issued": 1 if permit else 0,
            "permit_consumed": bool(permit and permit[1]),
            "submissions_written": submissions,
        }, indent=2).encode("utf-8")
        path = store / f"void-{uuid4().hex[:8]}.json"
        path.write_bytes(payload)
        connection.execute("INSERT INTO attempt_recovery VALUES (?, ?, ?, ?)",
                           (attempt_id, "operator_voided_unsent", str(path),
                            hashlib.sha256(payload).hexdigest()))
        connection.execute("UPDATE attempts SET closed_at = ? WHERE attempt_id = ?",
                           (closed_at, attempt_id))
    return path


def command_void(args, root: Path) -> int:
    """Close an attempt after an operator confirms that no message was sent."""
    store = request_store(root, args.request_id)
    state = load_state(store)
    if not state or not state.get("attempt_id"):
        print("No registered attempt exists for this request.")
        return 2
    try:
        closed = void_attempt(ledger_path(root), state["attempt_id"], store, args.reason)
    except sqlite3.Error as error:
        print(f"Refused: {error}", file=sys.stderr)
        return 1
    if not closed:
        print(f"{state['attempt_id']} was already closed.")
        return 0
    state["stage"] = "voided"
    state["failure"] = args.reason
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    save_state(store, state)
    print(f"Voided {state['attempt_id']} as operator_voided_unsent.")
    print(f"Evidence: {closed}")
    return 0


def command_recover(args, root: Path) -> int:
    """Close a record that was opened but never reached a permit, after checking that fact."""
    store = request_store(root, args.request_id)
    state = load_state(store)
    if not state or not state.get("attempt_id"):
        print("No registered attempt exists for this request.")
        return 2
    try:
        closed = abandon_unsubmitted(
            ledger_path(root), state["attempt_id"], store,
            "closed by an operator: the run stopped before any permit was issued")
    except (OSError, RuntimeError, sqlite3.Error) as error:
        print(f"Recovery refused: {error}", file=sys.stderr)
        return 1
    if not closed:
        print(f"{state['attempt_id']} was already closed.")
        return 0
    print(f"Closed {state['attempt_id']} as blocked_before_permit.")
    print(f"Evidence: {closed}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control-root", type=Path, default=control_root())
    parser.add_argument("--timeout", type=float, default=1800,
                        help="Seconds allowed for the whole stage")
    parser.add_argument("--prompt-timeout", type=float, default=600,
                        help="Seconds allowed for launching, workspace selection, and paste readback")
    commands = parser.add_subparsers(dest="command", required=True)
    run_parser = commands.add_parser("run", help="Freeze a task and run it once")
    run_parser.add_argument("--task", required=True, help="Path to the task.json manifest")
    run_parser.add_argument("--request-id", required=True)
    run_parser.add_argument("--wait-signin", type=int, default=0, metavar="SECONDS",
                            help="After the restore, wait this long for an operator to sign in "
                                 "before giving up (the baseline has no automatic logon)")
    run_parser.add_argument("--attach", action="store_true",
                            help="Use the signed-in desktop as it is: no shutdown, no baseline "
                                 "restore, and no closing restore. Recorded as a diagnostic "
                                 "attempt because it did not start from the baseline.")
    run_parser.add_argument("--dry-run", action="store_true",
                            help="Freeze the task and print the plan without touching the VM")
    status_parser = commands.add_parser("status", help="Show stored progress read-only")
    status_parser.add_argument("--request-id", required=True)
    resume_parser = commands.add_parser("resume", help="Continue a request that has not sent")
    resume_parser.add_argument("--request-id", required=True)
    resume_parser.add_argument("--task", help="Unused when the request is already frozen")
    resume_parser.add_argument("--wait-signin", type=int, default=0, metavar="SECONDS")
    recover_parser = commands.add_parser(
        "recover", help="Close an attempt that stopped before any permit was issued")
    recover_parser.add_argument("--request-id", required=True)
    void_parser = commands.add_parser(
        "void", help="Close an attempt whose send an operator watched fail")
    void_parser.add_argument("--request-id", required=True)
    void_parser.add_argument("--reason", required=True,
                             help="What the operator saw that proves no message was sent")
    collect_parser = commands.add_parser(
        "collect", help="Copy the guest probe report and screenshots back")
    collect_parser.add_argument("--request-id", required=True)
    args = parser.parse_args()

    if os.name != "nt":
        print("The controlled desktop run needs the Windows host.", file=sys.stderr)
        return 2
    package = Path(__file__).resolve().parent
    root = args.control_root
    if args.command == "run":
        return command_run(args, root, package)
    if args.command == "status":
        return command_status(args, root)
    if args.command == "recover":
        return command_recover(args, root)
    if args.command == "void":
        return command_void(args, root)
    if args.command == "collect":
        return collect_sources(args.request_id, request_store(root, args.request_id), root)
    return command_resume(args, root, package)


if __name__ == "__main__":
    sys.exit(main())
