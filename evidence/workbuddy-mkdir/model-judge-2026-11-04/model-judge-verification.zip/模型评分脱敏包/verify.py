"""读取包内已保存的目录创建评分，复算规则、校验输出并统计一致项。"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import json

from 证据.checker import VERSION, assess
from 证据.validate import SCORES, validate_output


EVIDENCE = Path(__file__).resolve().parent / "证据"


def read(name):
    return json.loads((EVIDENCE / name).read_text(encoding="utf-8"))


def require(condition, context):
    if not condition:
        raise SystemExit(f"核对失败：{context}")


def fixture_sample(suite, fixture):
    sample = deepcopy(suite["base"])
    for path, value in fixture["set"].items():
        block, key = path.split(".")
        sample[block][key] = value
    for path in fixture["remove"]:
        block, key = path.split(".")
        del sample[block][key]
    return sample


def main():
    suite = read("fixtures.json")
    fixtures = {row["id"]: row for row in suite["cases"]}
    historical = read("历史观察摘录.json")
    labels = read("reference_labels.json")["labels"]
    prompt = (EVIDENCE / "prompt.md").read_text(encoding="utf-8")
    counts = Counter()
    raw_disagreements, invalid_outputs, seen = [], [], set()
    expected_ids = [f"J{i:03d}" for i in range(1, 21)]
    require(sorted(p.stem for p in EVIDENCE.glob("J*.json")) == expected_ids, "20 份逐项证据文件")
    for cid in expected_ids:
        doc = read(cid + ".json")
        sid = doc["source_sample_id"]
        group = doc["source_type"]
        require(doc["case_id"] == cid and sid not in seen, cid + " 的编号或来源映射")
        seen.add(sid)
        if group == "真实观察":
            source, reference = historical[sid], labels[sid]
        else:
            require(group == "合成样例", cid + " 的来源类型")
            fixture = fixtures[sid]
            source, reference = fixture_sample(suite, fixture), fixture["expected"]

        request = doc["saved_request"]
        system, user = request["messages"]
        require(system == {"role": "system", "content": prompt} and user["role"] == "user", cid + " 的原提示词")
        sample = json.loads(user["content"])
        observed = {key: value for key, value in source["observed"].items() if key != "slot"}
        require(sample == {"case_id": cid, "initial_state": source["initial_state"],
                           "arguments": source["arguments"], "observed": observed}, cid + " 的输入字段与来源")

        result = assess({**sample, "sample_id": sid, "schema_version": source["schema_version"]})
        require(
            doc["versions"]["rules"] == VERSION
            and result["verdict"] == doc["rule"]["verdict"] == doc["reference"]["verdict"] == reference
            and result["reason"] == doc["rule"]["reason"]
            and doc["rule"]["score"] == doc["reference"]["score"] == SCORES[reference],
            cid + " 的规则和参照",
        )

        response = doc["saved_response_excerpt"]
        output = json.loads(response["choices"][0]["message"]["content"])
        validation = validate_output(response, sample)
        final = output["verdict"] if validation["valid"] else "JUDGE_ERROR"
        difference = doc["difference"]
        require(
            validation == doc["saved_validation"]
            and output["verdict"] == difference["raw_model_label"]
            and output["score"] == difference["raw_model_score"]
            and final == difference["comparison_label"]
            and SCORES.get(final) == difference["comparison_score"]
            and (final == reference) == difference["agrees_with_both"],
            cid + " 的模型判定和校验",
        )
        counts[group, "样例"] += 1
        counts[group, "一致"] += final == reference
        counts[group, "输出有效"] += validation["valid"]
        if output["verdict"] != reference:
            raw_disagreements.append(cid)
        if not validation["valid"]:
            invalid_outputs.append(cid)

    require(seen == set(historical) | set(fixtures), "所有真实观察与合成样例均覆盖")
    require(tuple(counts["真实观察", key] for key in ("一致", "样例", "输出有效")) == (4, 4, 4), "真实观察统计")
    require(tuple(counts["合成样例", key] for key in ("一致", "样例", "输出有效")) == (13, 16, 15), "合成样例统计")
    require(raw_disagreements == ["J006", "J010", "J011"] and invalid_outputs == ["J011"], "标签差异及校验重合")
    print("真实观察 4/4 一致，合成样例 13/16 一致，输出校验通过 19/20。")
    print("模型原答标签差异 J006、J010、J011。唯一校验错误 J011 与标签差异重合。")


if __name__ == "__main__":
    main()
