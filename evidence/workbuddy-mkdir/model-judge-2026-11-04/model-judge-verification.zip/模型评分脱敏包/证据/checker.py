"""目录创建观察项检查器 v1.1；不读取参照标签，不执行 mkdir 或产品。"""

VERSION = "mkdir-semantics-1.1"


def assess(sample):
    """只检查一次 exist_ok=True 调用；结果状态与批处理是否成功分开。"""
    def result(verdict, reason):
        return {"sample_id": sample.get("sample_id"), "checker_version": VERSION,
                "verdict": verdict, "reason": reason,
                "scope": "本次记录条件下的一项目录调用；不裁定根因、修复或跨产品排名"}

    if sample.get("schema_version") != "mkdir-sample-1.0":
        return result("INVALID", "不支持的样本版本")
    if not isinstance(sample.get("sample_id"), str) or not sample["sample_id"]:
        return result("INVALID", "缺少有效样本ID")
    initial, args, observed = (sample.get(k) for k in ("initial_state", "arguments", "observed"))
    if any(not isinstance(x, dict) for x in (initial, args, observed)):
        return result("UNKNOWN", "缺少初态、参数或调用结果")
    for name in ("exists", "is_dir", "is_symlink", "parent_is_dir", "parent_is_symlink"):
        if name not in initial or initial[name] is None:
            return result("UNKNOWN", "初态字段缺失：" + name)
        if type(initial[name]) is not bool:
            return result("INVALID", "初态必须使用布尔值：" + name)
    if (initial["is_symlink"] or initial["parent_is_symlink"]
            or not initial["parent_is_dir"] or initial["exists"] != initial["is_dir"]):
        return result("INVALID", "不属于本版的普通目录或不存在目标场景")
    if type(args.get("exist_ok")) is not bool or type(args.get("parents")) is not bool:
        return result("INVALID", "调用参数缺失或类型错误")
    if not args["exist_ok"] or args["parents"]:
        return result("INVALID", "本版只覆盖 exist_ok=True、parents=False")
    if observed.get("precondition_valid") is not True:
        return result("UNKNOWN", "未确认脚本前提有效")
    required = ("returned_normally", "final_exists", "final_is_dir", "initial_exists",
                "mkdir_attempts", "exception_type", "exception_text")
    if any(k not in observed or (observed[k] is None and k not in
                               {"exception_type", "exception_text"}) for k in required):
        return result("UNKNOWN", "调用结果字段不完整")
    for name in ("returned_normally", "final_exists", "final_is_dir", "initial_exists"):
        if type(observed[name]) is not bool:
            return result("INVALID", "调用结果必须使用布尔值：" + name)
    if type(observed["mkdir_attempts"]) is not int or observed["mkdir_attempts"] != 1:
        return result("INVALID", "不属于单次调用场景")
    if observed["initial_exists"] != initial["exists"]:
        return result("UNKNOWN", "前提与结果中的初态冲突")
    if observed["final_is_dir"] and not observed["final_exists"]:
        return result("UNKNOWN", "目录终态字段互相矛盾")
    exception_type, exception_text = observed["exception_type"], observed["exception_text"]
    if observed["returned_normally"]:
        if exception_type is not None or exception_text is not None:
            return result("UNKNOWN", "正常返回与异常记录互相矛盾")
        if not observed["final_exists"] or not observed["final_is_dir"]:
            return result("FAIL", "调用正常返回，但未取得目标目录终态")
        return result("PASS", "正常返回且目标最终为目录")
    if not isinstance(exception_type, str) or not exception_type or not isinstance(exception_text, str) or not exception_text:
        return result("UNKNOWN", "报告异常返回，但缺少异常详情")
    return result("FAIL", "预期正常返回，实际抛出异常；目录存在不能代替调用成功")
