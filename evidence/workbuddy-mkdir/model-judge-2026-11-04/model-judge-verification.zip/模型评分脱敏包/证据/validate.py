"""历史输出校验源码摘录。原样保留常量、查询函数与校验函数。"""

import json

SCORES = {"PASS": 1, "FAIL": 0, "UNKNOWN": None, "INVALID": None}


def lookup(document, path):
    current = document
    for key in path.split("."):
        if not isinstance(current, dict) or key not in current:
            raise KeyError(path)
        current = current[key]
    return current


def validate_output(body, sample):
    errors = []
    try:
        choice = body["choices"][0]
        if choice.get("finish_reason") != "stop":
            raise ValueError("输出未正常结束：" + str(choice.get("finish_reason")))
        content = choice["message"]["content"]
        if not isinstance(content, str) or not content.strip():
            raise ValueError("模型返回空白正文")
        result = json.loads(content, parse_constant=lambda x: (_ for _ in ()).throw(ValueError("非标准JSON常量")))
        if not isinstance(result, dict) or set(result) != {"case_id", "verdict", "score", "reason", "evidence"}:
            raise ValueError("输出字段不符合约定")
        if result["case_id"] != sample["case_id"] or result["verdict"] not in SCORES:
            raise ValueError("编号或标签不合法")
        score, expected = result["score"], SCORES[result["verdict"]]
        if type(score) is not type(expected) or score != expected:
            raise ValueError("分数与标签不一致")
        if not isinstance(result["reason"], str) or not result["reason"].strip():
            raise ValueError("缺少评分理由")
        if not isinstance(result["evidence"], list) or not result["evidence"]:
            raise ValueError("缺少证据字段引用")
        for citation in result["evidence"]:
            if not isinstance(citation, dict) or set(citation) != {"path", "value"}:
                raise ValueError("证据引用结构错误")
            path = citation["path"]
            if not isinstance(path, str) or path.split(".")[0] not in {"initial_state", "arguments", "observed"}:
                raise ValueError("证据引用超出执行字段")
            actual = lookup(sample, path)
            if type(actual) is not type(citation["value"]) or actual != citation["value"]:
                raise ValueError("证据引用值与输入不符")
        return {"valid": True, "judgment": result, "errors": []}
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        errors.append(str(exc))
        return {"valid": False, "judgment": None, "errors": errors}
