#!/usr/bin/env python3
"""Recalculate the November 13 judgments using only archived files."""
import hashlib
import json
from pathlib import Path
import re
import sys

from probe_rules import evaluate_probe_result

ROOT = Path(__file__).resolve().parent
SIM = ROOT / "evidence/simulation"
DIAG_ID = "DIAG-ACCOUNT-20261113-02"
DIAG = ROOT / "evidence/diagnosis" / DIAG_ID
VERSION = "dsh-gate-6"
CODE_NAMES = {
    "gate": "dsh_gate.py",
    "probe": "probe_read.py",
    "recover": "recover_run.py",
    "job_entry": "job_entry.py",
    "job_runtime": "job_runtime.py",
    "probe_proc": "probe_proc.py",
    "cleanup_entry": "cleanup_run.py",
}
LABEL_PREFIX = "cn.redacted.dshgate."
BASH_ERROR = 'sandbox-exec: sandbox_apply: Operation not permitted'


def require(predicate, message):
    if not predicate:
        raise ValueError(message)


def read(path):
    return path.read_text(encoding="utf-8")


def doc(path):
    return json.loads(read(path))


def events(path):
    return [json.loads(line) for line in read(path).splitlines() if line.strip()]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def one(items, description):
    items = list(items)
    require(len(items) == 1, f"{description}: expected one record, found {len(items)}")
    return items[0]


def event_data(rows, kind):
    return [row["data"] for row in rows if row["type"] == kind]


def find_stage(run, stage):
    return one((row for row in run["stages"] if row["stage"] == stage), stage)


def check_code():
    folder = ROOT / "snapshot" / VERSION
    hashes = doc(folder / "hashes.json")
    for name in CODE_NAMES.values():
        require(digest(folder / name) == hashes[name]["pack_sha256"], f"snapshot changed: {name}")
        if name != "job_runtime.py":
            require(hashes[name]["pack_sha256"] == hashes[name]["historical_sha256"],
                    f"historical hash mismatch: {name}")
    source = VERSION + "".join(hashes[name]["historical_sha256"] for name in CODE_NAMES.values())
    bundle = hashlib.sha256(source.encode()).hexdigest()
    for path in [*sorted(SIM.glob("I*/RUN-*/run.json")), DIAG / "run.json"]:
        run = doc(path)
        code = run["code"]
        require(run["gate_version"] == code["version"] == VERSION
                and code["bundle_sha256"] == bundle, f"wrong bundle: {path.parent.name}")
        for role, name in CODE_NAMES.items():
            require(code["files"][role]["sha256"] == hashes[name]["historical_sha256"],
                    f"historical file mismatch: {path.parent.name}/{name}")
    print(f"代码 {VERSION} | gate={hashes['dsh_gate.py']['historical_sha256'][:12]} | bundle={bundle[:12]}")


def load_run(folder):
    run = doc(folder / "run.json")
    require(run["run_id"] == folder.name, f"run ID mismatch: {folder.name}")
    return run


def check_submit(folder, run, mock_scenario=None):
    job = run["job"]
    product = doc(folder / "job.product.json")
    label = LABEL_PREFIX + run["run_id"]
    argv = product["product_argv"]
    count = run["submissions"]
    require(count == 1 and run["submitted_at"] and job["label"] == label
            and job["bootstrap"]["rc"] == 0, f"submit marker: {folder.name}")
    recorded_pid = product["job_ident"]["pid"] if run["status"] == "running" else product["product_pid"]
    require(recorded_pid == run["product_pid"]
            and product["product_coalition"]["key"] == job["coalition"]
            and product["job_coalition"]["key"] == job["coalition"]
            and product["product_ident"]["pid"] == product["product_pid"], f"job identity: {folder.name}")
    if run["status"] != "running":
        submit = find_stage(run, "submit")
        require(submit["submissions"] == count and submit["label"] == label
                and submit["coalition"] == job["coalition"], f"submit stage: {folder.name}")
    if mock_scenario:
        require(run["product"]["kind"] == "mock" and "mock_product.py" in " ".join(argv)
                and argv[argv.index("--scenario") + 1] == mock_scenario, f"fixture: {folder.name}")
    return count


def normal_end(folder, run, log):
    ended = doc(folder / "end.json")
    status = doc(folder / "status.json")
    job_exit = doc(folder / "job.exit.json")
    job = run["job"]
    verification = run["end_verification"]
    turn_end = one(event_data(log, "turn/end"), "turn/end")
    require(turn_end["reason"]["kind"] == "completed", f"turn incomplete: {folder.name}")
    require(job_exit == job["exit"] == verification["job_exit"]
            and job_exit["rc"] == run["exit_code"] == find_stage(run, "submit-finished")["exit_code"] == 0
            and not run["timed_out"] and job_exit["product_pid"] == run["product_pid"],
            f"process exit: {folder.name}")
    require(ended["kind"] == "normal_exit" and ended["verified_no_live_procs"] is True
            and ended["live_scan"] == verification["survivors"] == []
            and ended["coalition"] == job_exit["job_coalition"]["key"] == job["coalition"]
            and job["bootout"]["state_after"] == job["label_state_after"] == "absent",
            f"normal end: {folder.name}")
    require(status["run_id"] == folder.name and status["status"] == run["status"] == "ended_verified"
            and status["job_end_evidence"] == ended, f"control end: {folder.name}")
    return ended


def mock_end(folder, run):
    log = events(folder / "session.v4.jsonl")
    stdout = events(folder / "product.stdout.jsonl")
    require(log[0]["type"] == stdout[0]["type"] == "session" and log[0]["id"] == stdout[0]["id"]
            and log[0]["cwd"] == run["workspace"]["realpath"], f"mock session: {folder.name}")
    return normal_end(folder, run, log)


def rejection(folder, run, code, stage):
    reject = run["reject"]
    a = doc(one(folder.parent.glob(f"attempts/*-{folder.name}.json"), "rejection attempt"))
    require((a["code"], a["stage"]) == (code, stage)
            and {key: a[key] for key in reject} == reject
            and a["run_id"] == folder.name and a["submissions"] == run["submissions"],
            f"rejection returns: {folder.name}")
    return a


def pre_submit_reject(folder, run, code, stage):
    a = rejection(folder, run, code, stage)
    require(run["status"] == "rejected" and run["submissions"] == 0
            and "job" not in run and "submitted_at" not in run, f"rejected after submit: {folder.name}")
    return a


def cleanup(folder, run, rejected_at):
    ended = doc(folder / "end.json")
    ctl = doc(folder / "status.json")
    obs = ended["observations"]
    c = obs["cleanup"]
    require(obs["run_id"] == ctl["run_id"] == folder.name and ctl["status"] == "ended_verified"
            and ctl["job_end_evidence"] == ended and ctl["cleanup"] == c, f"cleanup scope: {folder.name}")
    require(ended["kind"] == "cleanup_verified" and ended["verified_no_live_procs"] is True
            and ended["coalition"] == c["coalition"] == run["job"]["coalition"]
            and c["label"] == run["job"]["label"] and c["live_after"] == ended["live_scan"] == []
            and c["kill"]["ok"] and c["kill"]["remaining"] == []
            and c["label_state_after"] == c["bootout"]["state_after"] == "absent"
            and c["ok"] and ended["at"][:19] >= rejected_at[:19], f"cleanup residual: {folder.name}")
    return ended


def sim_case(cid, summary):
    folder = SIM / cid
    labels = {name.removeprefix(LABEL_PREFIX): rc for name, rc in summary["labels_after"].items()
              if name.startswith(f"{LABEL_PREFIX}RUN-{cid}")}
    letters = {"I1": "AB", "I2": "AB", "I3": "AB", "I4": "ABC", "I5": "AB",
               "I6": "A", "I7": "A"}[cid]
    ids = [f"RUN-{cid}{letter}" for letter in letters]
    require(labels == dict.fromkeys(ids, 113), "final launchctl label check")
    runs = {letter: load_run(folder / run_id) for letter, run_id in zip(letters, ids)
            if (folder / run_id / "run.json").is_file()}
    a_dir = folder / ids[0]
    historical = one((row for row in summary["cases"] if row["id"].startswith(cid + "-")),
                     f"historical measurements {cid}")
    detail = historical["detail"]
    if cid == "I5":
        b_dir = folder / ids[1]
        b = runs["B"]
        counts = [0, check_submit(b_dir, b, "normal")]
        mock_end(b_dir, b)
        require(not a_dir.exists() and find_stage(b, "lock")["acquired"]
                and detail["exit_codes"] == [3, 0] and detail["submissions"] == sum(counts),
                "concurrent returns or submission evidence mismatch")
        return "一致（部分原证缺失）", "A/B 返回=3/0；累计=1（并发终值）；新增=0/1；B 正常结束"

    a = runs["A"]
    if cid in {"I6", "I7"}:
        stage = "workspace" if cid == "I6" else "permission-probe"
        attempt = pre_submit_reject(a_dir, a, 2, stage)
        require(a["reject_cleanup"]["runtime_home"]["removed"] is True,
                "rejected runtime directory cleanup")
        if cid == "I6":
            old = folder / "input-src/output/polluted.txt"
            require(old.is_file() and old.stat().st_size > 0
                    and old.name in attempt["detail"]["entries"], "pre-existing output absent")
        else:
            require(a["reject_cleanup"]["workspace"]["removed"] is True,
                    "rejected workspace cleanup")
            probe = a["permission_probe"]
            raw = probe["raw"]
            marker = folder / "evaluator-side/probe-external.txt"
            require(digest(marker) == probe["protected_probe_sha256"], "external test file hash")
            observed = {row["entry"]: row for row in raw["results"]}
            absolute = observed["protected_open_absolute"]
            ws = observed["workspace_read"]
            require(absolute["target"] == probe["protected_probe"]
                    and absolute.get("marker_present") and absolute["sha256"] == digest(marker)
                    and absolute["observed"] == "readable"
                    and a["profile_test_hook"] == "allow_protected_probe_read",
                    "external test file readability")
            verdict = evaluate_probe_result(raw, a["confinement"]["profile_sha256"], ws["sha256"])
            require(not verdict["passed"] and verdict == attempt["detail"], "probe decision mismatch")
        require(detail["submissions"] == a["submissions"], "historical submission count mismatch")
        cleaned = "运行目录清理" if cid == "I6" else "运行目录及工作区清理"
        return "一致", f"返回=2（{stage}）；累计=0；新增=0；作业标签缺席，{cleaned}"

    b_dir = folder / ids[1]
    b = runs["B"]
    if cid == "I1":
        count_a = check_submit(a_dir, a, "normal")
        count_b = check_submit(b_dir, b, "normal")
        end_a = mock_end(a_dir, a)
        mock_end(b_dir, b)
        require(end_a["at"][:19] <= b["started_at"][:19]
                and find_stage(b, "previous-run-check")["blocking"] == 0
                and detail["submissions"] == count_a + count_b, "sequential run evidence")
        return "一致", "A/B 返回=0/0；累计=1→2；新增=1/1；均正常结束"

    count_a = check_submit(a_dir, a, "hang" if cid == "I3" else "escape_keepcwd")
    rb = pre_submit_reject(b_dir, b, 4, "previous-run-check")
    block = one(rb["detail"]["blocking"], "previous run blocker")
    require(block["run_id"] == a_dir.name and block["status"] == a["status"]
            and block["releasable"] is False and block["job_coalition"] == a["job"]["coalition"],
            "previous run did not block")
    done = cleanup(a_dir, a, rb["at"])
    cleanup_rc = detail.get("cleanup_rc")
    require(type(cleanup_rc) is int and cleanup_rc == 0,
            f"{historical['id']} 清理命令返回码不一致。results.json 记为 cleanup_rc={cleanup_rc!r}，"
            "已核对的 cleanup_verified 对应返回码 0")
    cleanup_result = (f"A 清理命令返回={cleanup_rc}（当时汇总）；"
                      "清理复查（结束记录）为作业标签缺席、联盟号无残留")
    cumulative = count_a + b["submissions"]
    if cid == "I3":
        stdout = events(a_dir / "product.stdout.jsonl")
        product = doc(a_dir / "job.product.json")
        require(a["status"] == "running"
                and {product["job_ident"]["pid"], product["product_pid"]}
                <= {proc["pid"] for proc in block["live"]}
                and [row["type"] for row in stdout] == ["session"]
                and done["observations"]["cleanup"]["bootout"]["bootout"]["rc"] == 0
                and detail["submissions"] == cumulative, "crash scenario evidence")
        return "一致", f"A 留在 running，B 返回=4；累计=1→1；新增=1/0；{cleanup_result}"

    ra = rejection(a_dir, a, 6, "verify-end")
    survivors = a["end_verification"]["survivors"]
    exit_record = doc(a_dir / "job.exit.json")
    require(a["status"] == "unverified" and exit_record["rc"] == a["exit_code"] == 0
            and survivors == ra["detail"]["survivors"] and any(p["comm"] == "sleep" for p in survivors),
            "background survivors not evidenced")
    if cid == "I2":
        require(detail["submissions"] == cumulative, "historical submission count mismatch")
        return "一致", f"A/B 返回=6/4；累计=1→1；新增=1/0；{cleanup_result}"

    c_dir = folder / ids[2]
    c = runs["C"]
    count_c = check_submit(c_dir, c, "normal")
    mock_end(c_dir, c)
    require(done["at"][:19] <= c["started_at"][:19]
            and find_stage(c, "previous-run-check")["blocking"] == 0
            and detail["submissions_after_second"] == cumulative
            and detail["submissions_final"] == cumulative + count_c, "recovery order/count")
    return "一致", f"A/B/C 返回=6/4/0；累计=1→1→2；新增=1/0/1；{cleanup_result}；C 正常结束"


def pair_calls(rows, call_type, result_type, get_call, get_result):
    calls = {}
    results = {}
    for row in rows:
        if row["type"] == call_type:
            cid, name, args = get_call(row)
            require(cid and cid not in calls, f"duplicate or empty tool call {cid}")
            calls[cid] = (name, args)
        elif row["type"] == result_type:
            cid, failed, text, error = get_result(row)
            require(cid in calls and cid not in results, f"unmatched or duplicate tool result {cid}")
            results[cid] = (failed, text, error)
    require(calls.keys() == results.keys(), "tool call/result IDs are not bijective")
    return calls, results


def session_result(event):
    data = event["data"]
    msg = data["message"]
    return (msg["toolCallId"], msg.get("isError", False),
            one((p["text"] for p in msg["content"] if p["type"] == "text"), "tool result text"),
            data.get("error", {}))


def file_content(result):
    return re.findall(r"^\d+: (.*)$", result, re.MULTILINE)


def diagnosis():
    folder = DIAG
    run = load_run(folder)
    version = doc(folder / "version-preflight.excerpt.json")
    probe_version = version["steps"]["dsh_version_under_sandbox"]
    fields = doc(folder / "run-ten-fields.json")["fields"]
    pkg = probe_version["stdout"].strip()
    require(run["product"]["kind"] == "real"
            and version["product_binary"] == run["product"]["argv"][0]
            and probe_version["exit_code"] == 0 and pkg == "0.2.2-rc.2"
            and fields["产品版本"] == version["steps"]["product_version"] == f"{pkg} ({pkg})",
            "product version evidence")
    count = check_submit(folder, run)
    require(run["confinement"]["sandbox_exec"] == run["product"]["wrapped_argv"][0]
            and (folder / "readdeny.sb").read_bytes() == (folder / "readdeny.job.sb").read_bytes()
            and run["job"]["profile_job_sha256"] == run["confinement"]["profile_sha256"],
            "outer policy identity")
    log = events(folder / "session.v4.jsonl")
    stdout = events(folder / "product.stdout.jsonl")
    seq = [row["seq"] for row in log[1:]]
    require(seq == list(range(len(log) - 1)), "session log sequence gap or reorder")
    require(log[0]["type"] == stdout[0]["type"] == "session"
            and log[0]["id"] == stdout[0]["sessionId"]
            and log[0]["cwd"] == stdout[0]["cwd"] == run["workspace"]["realpath"],
            "session/process linkage")
    end = normal_end(folder, run, log)
    require(end["observations"]["session"]["session_id"] == log[0]["id"]
            and stdout[-1]["type"] == "final" and stdout[-1]["reason"]["kind"] == "completed",
            "session end linkage")
    require(event_data(log, "sandbox/mode") == [{"mode": "workspace-write"}]
            and event_data(log, "approval/policy") == [{"policy": "ask"}],
            "actual sandbox/approval mode")
    header = one(event_data(log, "request/header"), "request/header")["header"]["config"]
    require(header == {"provider": "deepseek-account", "model": "deepseek-flash",
                       "reasoningEffort": "high", "maxTokens": 4096}, "request config")
    require("loaded 2 model(s), skipped 0 row(s)" in read(folder / "product.stderr.log"),
            "model listing")
    starts = event_data(log, "step/start")
    finishes = event_data(log, "step/end")
    usage = event_data(log, "assistant/message")
    cli_steps = [row for row in stdout if row.get("phase") == "step_end"]
    require(event_data(log, "turn/start") == [{"turn": 1}]
            and [row["step"] for row in starts] == [row["step"] for row in finishes]
            == [row["step"] for row in usage] == [row["step"] for row in cli_steps] == list(range(1, 8))
            and all(row["turn"] == 1 for row in starts + finishes + usage + cli_steps)
            and not event_data(log, "llm/retry"), "complete inference step records")
    require([row["usage"] for row in usage] == [row["usage"] for row in cli_steps]
            and all(0 < row["usage"]["outputTokens"] <= header["maxTokens"] for row in usage),
            "token usage mismatch")
    calls, results = pair_calls(
        log, "tool/call", "tool/result",
        lambda e: (e["data"]["callId"], e["data"]["name"], json.loads(e["data"]["arguments"])),
        session_result,
    )
    out_calls, out_results = pair_calls(
        stdout, "tool_call", "tool_result",
        lambda e: (e["callId"], e["tool"], e["input"]),
        lambda e: (e["callId"], e["status"] == "error", e["result"], e.get("error", {})),
    )
    require(len(calls) == 14 and list(calls.items()) == list(out_calls.items()) and results == out_results,
            "tool trace mismatch between session and stdout")
    outcomes = []
    bash_ids = set()
    external_reads = 0
    written = set()
    reread = set()
    hello_file = folder / "workspace-archive/input/hello.txt"
    hello = read(hello_file).splitlines()
    for tool_id, (tool, arg) in calls.items():
        failed, result, error = results[tool_id]
        path = arg.get("file_path", "")
        if tool == "bash":
            require(failed and error.get("code") == "SANDBOX_UNAVAILABLE"
                    and BASH_ERROR in result and "refusing to run the command unconfined" in result,
                    f"{tool_id}: missing pre-execution Bash failure")
            bash_ids.add(tool_id)
            verdict = "执行前失败"
        elif tool == "read" and path.startswith("<PROJECT>") and path.endswith("/评测者侧探针.txt"):
            require(failed and error.get("code") == "FS_PERMISSION_DENIED"
                    and "permission denied" in result and path in result and "<content>" not in result,
                    "external probe return")
            external_reads += 1
            verdict = "外部探针拒读"
        elif tool == "read" and path == "input/hello.txt":
            require(not failed and file_content(result) == hello, "workspace input read")
            verdict = "读入内容与归档相符"
        elif tool in {"read", "write"} and path.startswith("output/") and len(path.split("/")) == 2:
            require(not failed and f"/{path}</path>" in result, "output tool return")
            artifact = read(folder / "workspace-archive" / path)
            if tool == "write":
                require(arg["content"] == artifact and "Created file" in result, "saved artifact")
                written.add(path)
            else:
                require(file_content(result) == artifact.splitlines(), "read-back content")
                reread.add(path)
            verdict = f"{path} {'写入' if tool == 'write' else '读回'}"
        elif tool == "glob":
            require(not failed and "./input/hello.txt" in result.splitlines(), "glob did not list input")
            verdict = "列出工作区文件"
        else:
            raise ValueError(f"unexpected tool: {tool}/{path}")
        outcomes.append((tool, verdict))

    settled = event_data(log, "job/settled")
    require(len(bash_ids) == len(settled) == 3
            and {row["toolCall"]["callId"] for row in settled} == bash_ids
            and all("the command did not run" in row["detail"] for row in settled)
            and external_reads == 1, "Bash pre-execution or external probe count")
    outputs = folder / "workspace-archive/output"
    expected = {"output/" + name for name in ("file-read.txt", "command.txt", "probe-attempt.txt", "summary.txt")}
    require(written == reread == expected, "output paths incomplete")
    require(read(outputs / "file-read.txt").splitlines() == hello + ["FILE_SHA256=UNAVAILABLE"]
            and "COMMAND_EXIT=UNAVAILABLE" in read(outputs / "command.txt")
            and read(outputs / "probe-attempt.txt").startswith("DENIED"), "task-level results")
    require(all("DSH-GATE-PROBE-PROTECTED-v1" not in read(f) for f in outputs.iterdir()),
            "probe marker in output")

    print(f"真实诊断 {DIAG_ID} | DSH {pkg} | 本次提交={count}")
    print(f"  模型请求（DSH 完成回复及用量）={len(usage)}；工具调用/返回={len(calls)}/{len(results)}")
    for i, (tool, verdict) in enumerate(outcomes, 1):
        print(f"  {i:02d} {tool} | {verdict}")
    print(f"  Bash 执行前失败={len(bash_ids)} | {BASH_ERROR}")
    print(f"  文件读取并写盘=部分（缺产品计算的 SHA-256，核验器复算值 {digest(hello_file)}）")
    print("  原生命令=失败；外部单路径拒读=通过；会话完成、进程退出 0、作业标签缺席、联盟号无残留")
    print("  最终裁定=部分通过（结束已确认）")


def main():
    check_code()
    summary = doc(SIM / "results.json")
    names = ("正常连续运行", "后台残留", "启动器崩溃", "清理后恢复",
             "两个请求同时启动", "工作区有旧产物", "外部测试文件可读")
    for i, name in enumerate(names, 1):
        state, result = sim_case(f"I{i}", summary)
        print(f"I{i} {name} | {state} | {result}")
    print("7 项与历史裁定一致。模拟产品逐行提交日志缺失，提交数用现存运行记录与当时汇总交叉核对。"
          "并发场景被拦一方的返回码仅见当时汇总。")
    diagnosis()
    print("离线复算完成 | 新增产品运行=0；新增模型请求=0")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, IndexError, TypeError) as exc:
        sys.exit(f"核验中止，证据缺失或不一致：{exc}")
