"""Pure probe rule copied verbatim from snapshot/dsh-gate-6/dsh_gate.py."""

import errno

PROBE_KIND = "dsh-gate-probe-v1"


REQUIRED_PROBE_ENTRIES = (
    "workspace_read",
    "protected_open_absolute",
    "protected_open_traversal",
    "protected_open_symlink",
    "shell_cat",
    "search_grep_recursive",
    "code_exec_open",
)


def evaluate_probe_result(payload, profile_sha256, ws_probe_sha256):
    """把探针的原始观察结果换算成通过／不通过。

    规则是“全部满足才算通过”：
      - 结果来自本次策略（指纹一致）；
      - 必需的入口一个不缺；
      - 工作区探针能读，且读到的就是这一次放进去的那份；
      - 其余每个入口都是“被拒绝”，且 errno 是 EACCES/EPERM；
      - 出现“不存在”“报错”“能读”任何一项都不通过。
    """
    problems = []
    if not isinstance(payload, dict) or payload.get("kind") != PROBE_KIND:
        return {"passed": False, "problems": ["探针输出格式不符"] }
    if payload.get("profile_sha256") != profile_sha256:
        problems.append("探针运行时的策略指纹与当前不一致")
    results = payload.get("results") or []
    by_entry = {}
    for item in results:
        by_entry[item.get("entry")] = item

    missing = [name for name in REQUIRED_PROBE_ENTRIES if name not in by_entry]
    if missing:
        problems.append("缺少入口结果：%s" % ", ".join(missing))

    ws = by_entry.get("workspace_read")
    if ws:
        if ws.get("observed") != "readable":
            problems.append("工作区探针读不到（%s）" % ws.get("observed"))
        elif not ws.get("marker_present") or ws.get("sha256") != ws_probe_sha256:
            problems.append("工作区探针读到的内容与本次放入的不一致")

    for name in REQUIRED_PROBE_ENTRIES:
        if name == "workspace_read":
            continue
        item = by_entry.get(name)
        if not item:
            continue
        observed = item.get("observed")
        if observed == "readable":
            problems.append("%s 仍能读到受保护内容" % name)
        elif observed == "missing":
            problems.append("%s 报“路径不存在”，不能算隔离成功" % name)
        elif observed == "error":
            problems.append("%s 结果不明（%s）" % (name, item.get("error")))
        elif observed == "denied":
            err = item.get("errno")
            if err is not None and err not in (errno.EACCES, errno.EPERM):
                problems.append("%s 的拒绝原因不是权限拒绝（errno=%s）" % (name, err))
    return {"passed": not problems, "problems": problems,
            "entries": len(results), "uid": payload.get("uid")}
