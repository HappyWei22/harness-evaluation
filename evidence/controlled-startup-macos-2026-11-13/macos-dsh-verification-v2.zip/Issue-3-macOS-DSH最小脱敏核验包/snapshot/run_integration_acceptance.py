#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""正式启动程序集成验收：launchd 作业 + 联盟号归属 + 清理恢复，用模拟任务。

复用 `验收/run_acceptance.py` 的 fixture / 配置 / 提交计数工具，不重写一套。
本脚本只跑模拟任务：不启动真实 DSH、不调用模型接口。

7 个场景：
  I1 正常连续运行          I2 后台残留（拒绝且提交不增）
  I3 启动器崩溃（拒绝）    I4 清理恢复（清理后下一场实际启动）
  I5 同时启动（只有一个提交） I6 工作区污染（拒绝、提交 0）
  I7 外部探针可读（拒绝、提交 0）
"""
import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CONTROL = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import run_acceptance as RA  # noqa: E402

PY = RA.PY
GATE = RA.GATE
CASES = []
RESULTS = []
ALL_RUNS = []


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


def make_case(base, tag, *, submit_seconds=30, probe_seconds=30):
    paths, protected = RA.make_fixture(os.path.join(base, "cases", tag))
    cfg = RA.base_config(paths, protected, submit_seconds=submit_seconds,
                         probe_seconds=probe_seconds)
    cfg["residual"] = {"attribution": "launchd_coalition"}
    cfg["timeouts"]["residual_grace_seconds"] = 0.5
    # 作业交换区必须让 launchd 读得到：放到 /tmp，而不是 ~/Documents 下的 case 目录。
    # records_root 仍留在 case 目录（评测侧持有），产品由 readdeny profile 挡住。
    tmp_run_root = os.path.join("/tmp", "dsh-gate-integration",
                                os.path.basename(base), tag)
    shutil.rmtree(tmp_run_root, ignore_errors=True)
    os.makedirs(tmp_run_root, exist_ok=True)
    cfg["run_root"] = tmp_run_root
    # 模拟产品脚本与 mock 日志也必须放在 launchd/产品可读写的 /tmp 作业区；
    # 生产真实产品在 /Applications，不受 ~/Documents TCC 影响。
    mock_copy = os.path.join(tmp_run_root, "mock_product.py")
    shutil.copyfile(RA.MOCK, mock_copy)
    paths["mock_log"] = os.path.join(tmp_run_root, "mock-log")
    os.makedirs(paths["mock_log"], exist_ok=True)
    cfg["mock"] = {"command": [PY, mock_copy],
                   "args": ["--log-dir", paths["mock_log"]]}
    cfg_path = RA.write_config(paths["case_dir"], cfg)
    return paths, cfg_path, cfg


def run_gate(cfg, run_id, paths, *, scenario="normal", extra_env=None, timeout=180):
    ALL_RUNS.append((paths, run_id))
    return RA.run_gate(cfg, run_id, scenario=scenario, paths=paths,
                       extra_env=extra_env, timeout=timeout)


def run_cleanup(cfg, run_id, paths, timeout=120):
    cmd = [PY, GATE, "--config", cfg, "--cleanup-run", run_id, "--product", "mock"]
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          env=RA.gate_env(paths), timeout=timeout)


def status(paths, run_id):
    p = os.path.join(paths["control"], "runs", run_id, "status.json")
    if not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except ValueError:
        return None


def end_evidence(paths, run_id):
    p = os.path.join(paths["control"], "runs", run_id, "end.json")
    if not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except ValueError:
        return None


def wait_for(fn, timeout=30, interval=0.1):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            value = fn()
        except Exception:  # noqa: BLE001
            value = None
        if value:
            return value
        time.sleep(interval)
    return None


def submissions(paths):
    return RA.submission_count(paths)


def case(case_id, expectation):
    def deco(fn):
        CASES.append({"id": case_id, "expectation": expectation, "fn": fn})
        return fn
    return deco


@case("I1-正常连续运行", "第一场 ended_verified；第二场放行并实际提交；提交数 1→2")
def i1(base):
    paths, cfg, _ = make_case(base, "I1")
    first = run_gate(cfg, "RUN-I1A", paths)
    st1 = status(paths, "RUN-I1A") or {}
    end1 = end_evidence(paths, "RUN-I1A") or {}
    second = run_gate(cfg, "RUN-I1B", paths)
    st2 = status(paths, "RUN-I1B") or {}
    ok = (first["exit_code"] == 0 and st1.get("status") == "ended_verified"
          and end1.get("kind") == "normal_exit"
          and second["exit_code"] == 0 and st2.get("status") == "ended_verified"
          and submissions(paths) == 2)
    return ok, {"first_exit": first["exit_code"], "first_status": st1.get("status"),
                "first_end": end1.get("kind"), "second_exit": second["exit_code"],
                "second_status": st2.get("status"), "submissions": submissions(paths)}


@case("I2-后台残留", "第一场 unverified；第二场拒绝且提交数仍为 1；清理后残留消失")
def i2(base):
    paths, cfg, _ = make_case(base, "I2")
    first = run_gate(cfg, "RUN-I2A", paths, scenario="escape_keepcwd")
    st1 = status(paths, "RUN-I2A") or {}
    endv = (st1.get("end_verification") or {})
    second = run_gate(cfg, "RUN-I2B", paths)
    subs_after_second = submissions(paths)
    cleanup = run_cleanup(cfg, "RUN-I2A", paths)
    st_after = status(paths, "RUN-I2A") or {}
    ok = (first["exit_code"] == 6 and st1.get("status") == "unverified"
          and bool(endv.get("survivors"))
          and second["exit_code"] == 4 and subs_after_second == 1
          and cleanup.returncode == 0
          and st_after.get("status") == "ended_verified")
    return ok, {"first_exit": first["exit_code"], "first_status": st1.get("status"),
                "survivors": endv.get("survivors"),
                "second_exit": second["exit_code"], "submissions": subs_after_second,
                "cleanup_rc": cleanup.returncode,
                "status_after_cleanup": st_after.get("status")}


@case("I3-启动器崩溃", "杀外部启动器后作业仍在；下一场拒绝；清理后可恢复")
def i3(base):
    paths, cfg, _ = make_case(base, "I3", submit_seconds=300)
    ALL_RUNS.append((paths, "RUN-I3A"))
    cmd = [PY, GATE, "--config", cfg, "--run-id", "RUN-I3A", "--product", "mock",
           "--mock-arg=--scenario", "--mock-arg=hang",
           "--prompt-file", os.path.join(paths["case_dir"], "prompt.txt")]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=RA.gate_env(paths))
    running = wait_for(lambda: (status(paths, "RUN-I3A") or {}).get("status") == "running", 30)
    sub_started = wait_for(lambda: submissions(paths) >= 1, 30)
    time.sleep(0.5)
    os.kill(proc.pid, signal.SIGKILL)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        pass
    st_after_kill = status(paths, "RUN-I3A") or {}
    coalition = (st_after_kill.get("job") or {}).get("coalition")
    second = run_gate(cfg, "RUN-I3B", paths)
    subs_after_second = submissions(paths)
    cleanup = run_cleanup(cfg, "RUN-I3A", paths)
    st_after_cleanup = status(paths, "RUN-I3A") or {}
    ok = (bool(running) and bool(sub_started) and coalition
          and st_after_kill.get("status") == "running"
          and second["exit_code"] == 4 and subs_after_second == 1
          and cleanup.returncode == 0
          and st_after_cleanup.get("status") == "ended_verified")
    return ok, {"running_before_kill": st_after_kill.get("status"),
                "coalition": coalition, "second_exit": second["exit_code"],
                "submissions": subs_after_second, "cleanup_rc": cleanup.returncode,
                "status_after_cleanup": st_after_cleanup.get("status")}


@case("I4-清理恢复", "有残留时拒绝；cleanup_verified 后下一场实际启动；提交 1→2")
def i4(base):
    paths, cfg, _ = make_case(base, "I4")
    first = run_gate(cfg, "RUN-I4A", paths, scenario="escape_keepcwd")
    st1 = status(paths, "RUN-I4A") or {}
    second = run_gate(cfg, "RUN-I4B", paths)
    subs_after_second = submissions(paths)
    cleanup = run_cleanup(cfg, "RUN-I4A", paths)
    end1 = end_evidence(paths, "RUN-I4A") or {}
    st1_after = status(paths, "RUN-I4A") or {}
    third = run_gate(cfg, "RUN-I4C", paths)
    st3 = status(paths, "RUN-I4C") or {}
    ok = (first["exit_code"] == 6 and st1.get("status") == "unverified"
          and second["exit_code"] == 4 and subs_after_second == 1
          and cleanup.returncode == 0 and end1.get("kind") == "cleanup_verified"
          and st1_after.get("status") == "ended_verified"
          and third["exit_code"] == 0 and st3.get("status") == "ended_verified"
          and submissions(paths) == 2)
    return ok, {"first_exit": first["exit_code"], "first_status": st1.get("status"),
                "second_exit": second["exit_code"], "submissions_after_second": subs_after_second,
                "cleanup_rc": cleanup.returncode, "end_kind": end1.get("kind"),
                "third_exit": third["exit_code"], "third_status": st3.get("status"),
                "submissions_final": submissions(paths)}


@case("I5-同时启动", "两个请求同时到：只有一个提交，另一个被锁拒绝；提交数 1")
def i5(base):
    paths, cfg, _ = make_case(base, "I5")
    env = RA.gate_env(paths)
    procs = []
    for rid in ("RUN-I5A", "RUN-I5B"):
        ALL_RUNS.append((paths, rid))
        procs.append(subprocess.Popen(
            [PY, GATE, "--config", cfg, "--run-id", rid, "--product", "mock",
             "--mock-arg=--scenario", "--mock-arg=normal",
             "--prompt-file", os.path.join(paths["case_dir"], "prompt.txt")],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env))
    codes = [p.wait(timeout=240) for p in procs]
    accepted = sum(1 for c in codes if c == 0)
    locked = sum(1 for c in codes if c == 3)
    ok = accepted == 1 and locked == 1 and submissions(paths) == 1
    return ok, {"exit_codes": codes, "submissions": submissions(paths)}


@case("I6-工作区污染", "输出目录初始非空 → 拒绝启动，提交数 0")
def i6(base):
    paths, cfg, _ = make_case(base, "I6")
    polluted = os.path.join(paths["input_src"], "output", "polluted.txt")
    os.makedirs(os.path.dirname(polluted), exist_ok=True)
    with open(polluted, "w", encoding="utf-8") as fh:
        fh.write("pre-existing output\n")
    out = run_gate(cfg, "RUN-I6A", paths)
    ok = (out["exit_code"] == 2 and RA.reject_stage(paths, "RUN-I6A") == "workspace"
          and submissions(paths) == 0)
    return ok, {"exit_code": out["exit_code"], "stage": RA.reject_stage(paths, "RUN-I6A"),
                "submissions": submissions(paths)}


@case("I7-外部探针可读", "读取限制被放宽到能读外部探针 → 拒绝启动，提交数 0")
def i7(base):
    paths, cfg, _ = make_case(base, "I7")
    out = run_gate(cfg, "RUN-I7A", paths,
                   extra_env={"GATE_TEST_HOOK": "allow_protected_probe_read"})
    ok = (out["exit_code"] == 2 and RA.reject_stage(paths, "RUN-I7A") == "permission-probe"
          and submissions(paths) == 0)
    return ok, {"exit_code": out["exit_code"], "stage": RA.reject_stage(paths, "RUN-I7A"),
                "submissions": submissions(paths)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="", help="逗号分隔：I1,I2,...")
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    stamp = time.strftime("%Y%m%dT%H%M%S", time.localtime())
    base = os.path.join(CONTROL, "证据", "集成验收", "run-" + stamp)
    os.makedirs(base, exist_ok=True)

    seatbelt_ok, seatbelt_note = RA.seatbelt_usable()
    if not seatbelt_ok:
        print(json.dumps({"status": "BLOCKED", "why": seatbelt_note}, ensure_ascii=False, indent=2))
        return 3

    todo = [c for c in CASES if (not args.only or c["id"].split("-")[0] in args.only.split(","))]
    for c in todo:
        print("[case] %s" % c["id"], file=sys.stderr)
        t0 = time.monotonic()
        try:
            ok, detail = c["fn"](base)
            status_text = "PASS" if ok else "FAIL"
        except Exception as exc:  # noqa: BLE001
            ok, detail, status_text = False, {"error": "%s: %s" % (type(exc).__name__, exc)}, "ERROR"
        row = {"id": c["id"], "expectation": c["expectation"], "status": status_text,
               "ok": bool(ok), "detail": detail, "seconds": round(time.monotonic() - t0, 2)}
        RESULTS.append(row)
        print("[%s] %s %s" % (status_text, c["id"], json.dumps(detail, ensure_ascii=False)[:500]),
              file=sys.stderr)

    # 最佳努力清理：对没到终态的 run 执行 cleanup；记录独立标签复查。
    cleanup_rows = []
    seen = set()
    for paths, rid in ALL_RUNS:
        key = (paths["case_dir"], rid)
        if key in seen:
            continue
        seen.add(key)
        cfg = os.path.join(paths["case_dir"], "config.json")
        st = status(paths, rid) or {}
        if st.get("status") in ("running", "submitting", "unverified"):
            cp = run_cleanup(cfg, rid, paths)
            cleanup_rows.append({"run_id": rid, "rc": cp.returncode,
                                 "stderr": (cp.stderr or b"").decode("utf-8", "replace")[-300:]})
    labels = {}
    for paths, rid in ALL_RUNS:
        label = "cn.redacted.dshgate." + rid
        r = subprocess.run(["/bin/launchctl", "print", "gui/%d/%s" % (os.getuid(), label)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        labels[label] = r.returncode
    summary = {
        "at": now(), "stamp": stamp, "seatbelt": {"ok": seatbelt_ok, "note": seatbelt_note},
        "cases": RESULTS, "cleanup": cleanup_rows,
        "labels_after": labels,
        "labels_all_absent": all(code != 0 for code in labels.values()),
        "pass": sum(1 for r in RESULTS if r["status"] == "PASS"),
        "fail": sum(1 for r in RESULTS if r["status"] != "PASS"),
        "total": len(RESULTS),
    }
    out_path = args.out or os.path.join(base, "results.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)
    print(json.dumps({"results": out_path, "pass": summary["pass"], "fail": summary["fail"],
                      "total": summary["total"], "labels_all_absent": summary["labels_all_absent"]},
                     ensure_ascii=False, indent=2))
    return 0 if summary["fail"] == 0 and summary["labels_all_absent"] else 1


if __name__ == "__main__":
    sys.exit(main())
