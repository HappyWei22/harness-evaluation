#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""模拟任务：验收时替代真实产品进程。

它只替代“产品这一侧”，不替代启动程序的任何检查：
工作区准备、权限探针、限流锁、结束校验、记录归档全部照常执行。

每次被调用都会先在提交日志里留一行，用来核对“拒绝时产品提交次数为零”。
用法与 dsh headless 对齐：任务从 stdin 或 `-` 读取，--json 风格的事件写到 stdout。
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import uuid

EVENTS = ("final", "session", "turn/start", "turn/end", "sandbox/mode", "approval/policy")


def append_log(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def write_session_home(home, session_id, workspace, completed=True, tools=(), unbalanced=False):
    """按 DSH 的实际存放结构写一份会话日志，让启动程序的结束校验有据可查。

    真实产品由 DSH 自己写；这里模拟它的结构（session / turn/start / sandbox/mode /
    approval/policy / tool/call / tool/result / turn/end），目的是验证启动程序读取和
    判断这些记录的逻辑。
    """
    sessions_root = os.path.join(home, "sessions")
    encoded = "--" + workspace.strip("/").replace("/", "-").replace(" ", "~0020") + "--"
    session_dir = os.path.join(sessions_root, encoded, session_id)
    os.makedirs(session_dir, exist_ok=True)
    log_path = os.path.join(session_dir, "session.v4.jsonl.zstd")
    lines = [
        {"type": "session", "version": 4, "id": session_id,
         "createdAt": int(time.time() * 1000), "cwd": workspace,
         "isSeeded": False, "delegationDepth": 0, "agentPreset": "standard"},
        {"type": "permission/preset", "seq": 0, "data": {"preset": "workspace-write"}},
        {"type": "sandbox/mode", "seq": 1, "data": {"mode": "workspace-write"}},
        {"type": "approval/policy", "seq": 2, "data": {"policy": "ask"}},
        {"type": "turn/start", "data": {"turn": 1}},
        {"type": "step/start", "data": {"turn": 1, "step": 1}},
    ]
    seq = 3
    for index, name in enumerate(tools):
        call_id = "call-%d" % index
        lines.append({"type": "tool/call", "seq": seq,
                      "data": {"turn": 1, "step": 1, "callId": call_id,
                               "name": name, "arguments": "{}"}})
        seq += 1
        if unbalanced and index == len(tools) - 1:
            continue   # 故意不给结果：模拟“工具还没回来就被打断”
        lines.append({"type": "tool/result", "seq": seq,
                      "data": {"turn": 1, "step": 1, "callId": call_id,
                               "message": {"toolCallId": call_id}}})
        seq += 1
    lines.append({"type": "step/end", "data": {"turn": 1, "step": 1}})
    lines.append({"type": "turn/end", "data": {"turn": 1,
                                               "reason": {"kind": "completed" if completed else "error"}}})
    plain = log_path + ".plain"
    with open(plain, "w", encoding="utf-8") as handle:
        for line in lines:
            handle.write(json.dumps(line, ensure_ascii=False) + "\n")
    zstd = os.environ.get("GATE_ZSTD", "zstd")
    proc = subprocess.run([zstd, "-q", "-f", plain, "-o", log_path],
                          stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise SystemExit("zstd failed: %s" % proc.stderr.decode("utf-8", "replace"))
    os.unlink(plain)
    return session_dir


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", default="normal")
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--sleep", type=float, default=0.3)
    parser.add_argument("task", nargs="*")
    args = parser.parse_args()

    task_bytes = sys.stdin.buffer.read() if (not args.task or args.task == ["-"]) else " ".join(args.task).encode()
    run_id = os.environ.get("DSH_GATE_RUN_ID", "unknown")
    workspace = os.getcwd()
    session_id = "session-" + str(uuid.uuid4())

    append_log(os.path.join(args.log_dir, "submissions.jsonl"), {
        "run_id": run_id,
        "session_id": session_id,
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "at": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime()),
        "cwd": workspace,
        "task_bytes": len(task_bytes),
        "task_sha256": hashlib.sha256(task_bytes).hexdigest(),
        "scenario": args.scenario,
    })

    print(json.dumps({"type": "session", "id": session_id}, ensure_ascii=False), flush=True)

    if args.scenario == "hang":
        # 提交后长时间不结束：用来验证超时与“不得凭等待足够久就放行”。
        while True:
            time.sleep(1)

    time.sleep(args.sleep)

    if args.scenario in ("escape_keepcwd", "escape_stealth"):
        # 反例：子进程 setsid 脱离进程组与会话，启动程序还能不能发现它。
        #   escape_keepcwd：保留工作目录在运行目录下（现实里“忘了关掉”的常见形态）
        #   escape_stealth：切走工作目录、断开全部继承 fd、清空环境、命令行不含路径
        if args.scenario == "escape_keepcwd":
            subprocess.Popen(["/bin/sleep", "40"], cwd=workspace, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["/bin/sleep", "40"], cwd="/tmp", start_new_session=True,
                             env={}, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, close_fds=True)
        write_session_home(os.environ["DSH_HOME"], session_id, workspace,
                           tools=("bash",))
        print(json.dumps({"type": "final", "text": "spawned background work"},
                         ensure_ascii=False), flush=True)
        # 立刻退出：让采样看不见这个子进程的出生，这就是“看不见的形态”。
        sys.stdout.flush()
        os._exit(0)

    if args.scenario == "tool_unbalanced":
        # 反例：会话日志里有一次工具调用没有结果（工具可能还在跑）
        write_session_home(os.environ["DSH_HOME"], session_id, workspace,
                           tools=("bash",), unbalanced=True)
        print(json.dumps({"type": "final", "text": "tool interrupted"},
                         ensure_ascii=False), flush=True)
        return 0

    if args.scenario == "orphan":
        # 模拟“接口已返回、后台还在跑”：主进程退出，子进程留在同一进程组继续写。
        subprocess.Popen(["/bin/sh", "-c", "sleep 45; echo late >> late.txt"], cwd=workspace)
        write_session_home(os.environ["DSH_HOME"], session_id, workspace)
        print(json.dumps({"type": "final", "text": "accepted"}, ensure_ascii=False), flush=True)
        return 0

    if args.scenario == "no_session":
        print(json.dumps({"type": "final", "text": "no session log"}, ensure_ascii=False), flush=True)
        return 0

    out_dir = os.path.join(workspace, "output")
    if os.path.isdir(out_dir):
        with open(os.path.join(out_dir, "mock-result.txt"), "w", encoding="utf-8") as handle:
            handle.write("mock product output for %s\n" % run_id)

    completed = args.scenario not in ("nonzero",)
    write_session_home(os.environ["DSH_HOME"], session_id, workspace, completed=completed)
    print(json.dumps({"type": "turn_end", "reason": "completed" if completed else "error"},
                     ensure_ascii=False), flush=True)
    print(json.dumps({"type": "final", "text": "mock done"}, ensure_ascii=False), flush=True)
    return 0 if completed else 3


if __name__ == "__main__":
    sys.exit(main())
