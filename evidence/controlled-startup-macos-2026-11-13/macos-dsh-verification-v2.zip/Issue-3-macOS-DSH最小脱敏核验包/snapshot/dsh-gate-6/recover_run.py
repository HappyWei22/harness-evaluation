#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""为一场「未确认结束」的运行生成一份人工观察记录（旁证）。

文件名 recover_run.py 是历史遗留，**它现在已经不能恢复任何东西、也不放行任何东西**。
原因是：这个程序能查的东西和启动程序完全是同一套——同样的多信号扫描，还少一路
（运行目录归档后 lsof 那一项查不了）。它没有引入任何新的证据来源，所以它写出来的
文件只能证明「有人在那个时刻按同样的方式看过一遍、当场没看到」，不能把未知变成已知。
启动程序因此不再把它当放行依据，只把它原样挂到阻塞项里供人读。

它现在还有的用处：把「人看过的时间、看过的方式、看到了什么、看不到什么」固定成一条
带指纹的记录，避免这类判断只留在对话里。任何一条扫描不通过，它仍然拒绝生成记录。

用法：
    python3 gate/recover_run.py --run-id RUN-X --by 张三 --basis "说明为什么认为这场已经结束"
    python3 gate/recover_run.py --run-id RUN-X --by 张三 --basis "..." --dry-run
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import dsh_gate  # noqa: E402


def load_status(control_root, run_id):
    path = os.path.join(control_root, "runs", run_id, "status.json")
    if not os.path.isfile(path):
        raise SystemExit("找不到运行登记：%s" % path)
    with open(path, "r", encoding="utf-8") as handle:
        return path, json.load(handle)


def find_session_log(record):
    """在归档目录或运行期目录里找会话日志。归档之后路径才是稳定可核对的。"""
    roots = []
    run_dir = record.get("records_run_dir")
    if run_dir:
        roots.append(os.path.join(run_dir, "runtime-home-archive", "dsh", "sessions"))
    home_root = record.get("home_root")
    if home_root:
        roots.append(os.path.join(home_root, "dsh", "sessions"))
    best = None
    for sessions_root in roots:
        for dirpath, _dirnames, filenames in os.walk(sessions_root):
            for name in filenames:
                if name == "session.v4.jsonl.zstd":
                    candidate = os.path.join(dirpath, name)
                    if best is None or os.path.getmtime(candidate) > os.path.getmtime(best):
                        best = candidate
    return best


def read_turn_end(path):
    zstd = os.environ.get("GATE_ZSTD") or "/opt/homebrew/bin/zstd"
    import subprocess
    try:
        proc = subprocess.run([zstd, "-dc", path], stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    reason = None
    for line in proc.stdout.decode("utf-8", "replace").splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if event.get("type") == "turn/end":
            reason = event.get("data", {}).get("reason")
    return reason


class _ScanStub:
    """只为了复用 Gate.find_survivors 的判定逻辑，不启动任何产品进程。

    这里必须老实交代两件事，否则就等于假装查过了：
      1. 运行目录在收尾时已经归档搬走，所以「有进程持有运行目录」这一路信号
         一定是空的——不是查过没有，是查不了；
      2. 没有 monitor，所以「采样期间见过的后代」这一路信号也是空的。
    减去这两路之后，剩下的判断力写进旁证的 scan_signals_missing，不许当成五路俱全。
    """

    @staticmethod
    def ps_table():
        # Gate.ps_table 本身是 staticmethod，直接搬过来会变成实例方法，
        # 于是 self.ps_table() 会多传一个 self（这个坑第一次跑就踩到了）。
        return dsh_gate.Gate.ps_table()

    def ancestors(self):
        # Gate.ancestors 要 self，只能在桩上再包一层。
        return dsh_gate.Gate.ancestors(self)

    def __init__(self, record):
        self.child = None
        self.child_pgid = None
        self.monitor = None
        self.run_id = record.get("run_id")
        self.record = {"workspace": {"path": record.get("workspace")}}
        # run_root 置空：归档之后按运行根目录匹配已经没有意义，
        # 若填 "/" 会让每个进程的命令行都命中，扫出来全是假残留。
        self.config = {"run_root": None}

    def run_root_holders(self):
        return {}

    def holds_run_root(self, pid):
        return False


def scan_survivors(control_root, record):
    """用与启动程序相同的多信号逻辑，独立扫一遍。

    注意这里少了不只一路：运行目录归档后 lsof 那一项查不了，也没有采样记录。
    少了哪一路必须写进旁证，不能把「查不到」说成「都查过了」。
    """
    stub = _ScanStub(record)
    return dsh_gate.Gate.find_survivors(
        stub, pgid=record.get("product_pgid"), run_id=record.get("run_id"),
        pid=record.get("product_pid"))


def main(argv=None):
    parser = argparse.ArgumentParser(description="生成人工观察旁证（不放行、不确认）")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--by", required=True, help="核实人")
    parser.add_argument("--basis", required=True, help="凭据依据：凭什么认定这场已经结束")
    parser.add_argument("--control-root", default=None)
    parser.add_argument("--dry-run", action="store_true", help="只检查，不写凭据")
    args = parser.parse_args(argv)

    control_root = os.path.realpath(
        os.path.expanduser(args.control_root or dsh_gate.DEFAULT_CONTROL_ROOT))
    status_path, record = load_status(control_root, args.run_id)
    print("登记：%s" % status_path)
    print("状态：%s（阶段 %s）" % (record.get("status"), record.get("stage")))

    problems = []
    log_path = find_session_log(record)
    turn_end = None
    log_sha = None
    if not log_path:
        problems.append("找不到归档的会话日志，无法证明轮次已结束")
    else:
        log_sha = dsh_gate.sha256_file(log_path)
        turn_end = read_turn_end(log_path)
        if not turn_end:
            problems.append("会话日志里没有 turn/end，不能认定轮次已结束")
    alive_pid = dsh_gate.Gate.probe_pid(record.get("product_pid"))
    if alive_pid:
        problems.append("记录里的产品进程 %s 仍然存在" % record.get("product_pid"))
    survivors = scan_survivors(control_root, record)
    if survivors is None:
        problems.append("无法枚举进程，不能认定没有残留")
    elif survivors:
        problems.append("仍能看到属于该场的进程：%s" % survivors)

    if problems:
        print("拒绝生成旁证：")
        for item in problems:
            print("  - %s" % item)
        return 2

    attribution = (record.get("end_verification") or {}).get("attribution") or \
        ((record.get("control") or {}).get("attribution")) or "multi_signal"
    voucher = {
        "kind": dsh_gate.RECOVERY_KIND,
        "run_id": args.run_id,
        "resolved_by": args.by,
        "resolved_at": dsh_gate.now_iso(),
        "basis": args.basis,
        "status_at_recovery": record.get("status"),
        # 这句话是这张记录的定位：只是一次观察，既不放行也不确认。
        # 写成 released／confirmed 都会被启动程序判为越权声明。
        "claims": "observation_only",
        "evidence": {
            "session_log_path": log_path,
            "session_log_sha256": log_sha,
            "turn_end_reason": turn_end,
            "product_pid": record.get("product_pid"),
            "product_pid_alive": False,
            "product_pgid": record.get("product_pgid"),
            "survivors": survivors or [],
            "survivors_scan_at": dsh_gate.now_iso(),
            "attribution": attribution,
            "scan_method": "pgid／sess／命令行含运行目录",
            "scan_signals_missing": [
                "lsof 持有运行目录（运行目录已归档搬走，本阶段查不到）",
                "250ms 后代采样（生成旁证时没有 monitor，看不到采样期）",
            ],
            "unknown": dsh_gate.residual_gap_text(),
            "limit": dsh_gate.residual_gap_text(),
            "what_this_proves": [
                "按上面的扫描方式，在 survivors_scan_at 这个时刻看不到属于该场的进程",
                "会话日志存在，指纹与记录一致，日志里有 turn/end 及其原因",
                "记录里的产品进程 pid 在生成这条记录时已经不存在",
            ],
            "what_this_does_not_prove": [
                "不证明该场没有留下它看不到的进程（见 unknown 那段）",
                "不证明这些进程在生成记录之后不会再出现",
                "**不构成下一场可以开始的依据**：它用的还是同一套有漏检的扫描，"
                "少一路 lsof，没有引入任何新证据；把它当放行依据等于用多写一个文件换「未知变已知」",
            ],
        },
    }
    target_dir = os.path.join(control_root, "recovery")
    os.makedirs(target_dir, mode=0o700, exist_ok=True)
    target = os.path.join(target_dir, args.run_id + ".json")
    if args.dry_run:
        print("（dry-run）旁证可以生成：%s" % target)
        print(json.dumps(voucher, ensure_ascii=False, indent=2))
        return 0
    dsh_gate.write_json(target, voucher)
    print("已写入旁证：%s" % target)
    print("注意：它不放行下一场。启动程序只会把它挂到阻塞项里作参考，"
          "上一场该阻塞的照样阻塞。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
