#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读进程探针（a2 专用）。

给出一个 pid 的**稳定身份**与**联盟号**：
  * 身份 = (pid, 启动时刻)，来自 proc_pidinfo flavor 3 (proc_bsdinfo, 136 字节)。
    pid 会被系统复用，光凭 pid 说"还是那个进程"是不成立的；带上启动时刻才能区分。
    这也是本验证**不靠 pid 文件**判断死活的办法。
  * 联盟号 = proc_pidinfo flavor 20 (proc_pidcoalitioninfo, 40 字节)。
    launchd 每个作业一个联盟号，与 session / process group 无关。

只读：不写文件、不发信号、不改任何状态。
"""
from __future__ import annotations

import argparse
import ctypes
import ctypes.util
import json
import os
import sys

_libc = ctypes.CDLL(ctypes.util.find_library("c") or "/usr/lib/libSystem.B.dylib", use_errno=True)
_libc.proc_listpids.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_int]
_libc.proc_listpids.restype = ctypes.c_int
_libc.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
_libc.proc_pidinfo.restype = ctypes.c_int

PROC_ALL_PIDS = 1
FLAVOR_BSDINFO = 3
COALITION_FLAVORS = (20, 21, 22, 19)


class BsdInfo(ctypes.Structure):
    _fields_ = [
        ("pbi_flags", ctypes.c_uint32),
        ("pbi_status", ctypes.c_uint32),
        ("pbi_xstatus", ctypes.c_uint32),
        ("pbi_pid", ctypes.c_uint32),
        ("pbi_ppid", ctypes.c_uint32),
        ("pbi_uid", ctypes.c_uint32),
        ("pbi_gid", ctypes.c_uint32),
        ("pbi_ruid", ctypes.c_uint32),
        ("pbi_rgid", ctypes.c_uint32),
        ("pbi_svuid", ctypes.c_uint32),
        ("pbi_svgid", ctypes.c_uint32),
        ("rfu_1", ctypes.c_uint32),
        ("pbi_comm", ctypes.c_char * 16),
        ("pbi_name", ctypes.c_char * 32),
        ("pbi_nfiles", ctypes.c_uint32),
        ("pbi_pgid", ctypes.c_uint32),
        ("pbi_pjobc", ctypes.c_uint32),
        ("e_tdev", ctypes.c_uint32),
        ("e_tpgid", ctypes.c_uint32),
        ("pbi_nice", ctypes.c_int32),
        ("pbi_start_tvsec", ctypes.c_uint64),
        ("pbi_start_tvusec", ctypes.c_uint64),
    ]


class CoalitionInfo(ctypes.Structure):
    _fields_ = [
        ("coalition_id", ctypes.c_uint64 * 4),
        ("residency_flags", ctypes.c_uint64),
    ]


assert ctypes.sizeof(BsdInfo) == 136, ctypes.sizeof(BsdInfo)
assert ctypes.sizeof(CoalitionInfo) == 40, ctypes.sizeof(CoalitionInfo)


def all_pids():
    """枚举全量 pid；缓冲不够就翻倍重试。"""
    n = 8192
    for _ in range(6):
        buf = (ctypes.c_int32 * n)()
        size = ctypes.sizeof(buf)
        used = _libc.proc_listpids(PROC_ALL_PIDS, 0, buf, size)
        if used <= 0:
            return []
        count = used // 4
        if used < size:
            return [p for p in buf[:count] if p > 0]
        n *= 2
    return []


def bsd(pid):
    """proc_bsdinfo；读不到返回 None（进程不存在或无权读）。"""
    info = BsdInfo()
    rc = _libc.proc_pidinfo(int(pid), FLAVOR_BSDINFO, 0, ctypes.byref(info), ctypes.sizeof(info))
    if rc != ctypes.sizeof(info):
        return None
    return {
        "pid": info.pbi_pid,
        "ppid": info.pbi_ppid,
        "uid": info.pbi_uid,
        "pgid": info.pbi_pgid,
        "comm": info.pbi_comm.decode("utf-8", "replace").rstrip("\x00"),
        "name": info.pbi_name.decode("utf-8", "replace").rstrip("\x00"),
        "start_sec": info.pbi_start_tvsec,
        "start_usec": info.pbi_start_tvusec,
    }


def ident(pid):
    """稳定身份 (pid, start_sec, start_usec)。"""
    b = bsd(pid)
    if not b:
        return None
    return {"pid": b["pid"], "start_sec": b["start_sec"], "start_usec": b["start_usec"]}


def alive(idt):
    """按身份判断死活：pid 在、且启动时刻一致，才算"还是它"。"""
    if not idt:
        return False
    b = bsd(idt["pid"])
    if not b:
        return False
    return int(b["start_sec"]) == int(idt["start_sec"]) and int(b["start_usec"]) == int(idt["start_usec"])


def coalition(pid):
    """联盟号；试多个 flavor，读不到返回 None（不是空列表）。"""
    for flavor in COALITION_FLAVORS:
        info = CoalitionInfo()
        rc = _libc.proc_pidinfo(int(pid), flavor, 0, ctypes.byref(info), ctypes.sizeof(info))
        if rc == ctypes.sizeof(info):
            cid = [int(x) for x in info.coalition_id]
            return {"flavor": flavor, "id": cid, "key": ":".join(str(x) for x in cid)}
    return None


def members(cid_key):
    """当前所有联盟号等于 cid_key 的进程（含全部后代，与 pgid/sess/cwd/环境无关）。"""
    out = []
    for pid in all_pids():
        c = coalition(pid)
        if c and c["key"] == cid_key:
            b = bsd(pid)
            if b:
                out.append({
                    "pid": b["pid"], "ppid": b["ppid"], "comm": b["comm"],
                    "pgid": b["pgid"], "start_sec": b["start_sec"],
                    "start_usec": b["start_usec"], "coalition": cid_key,
                })
    return sorted(out, key=lambda r: r["pid"])


def snapshot():
    return {"self": {"pid": os.getpid(), "ident": ident(os.getpid()), "coalition": coalition(os.getpid())},
            "pid_count": len(all_pids())}


def main():
    ap = argparse.ArgumentParser(description="只读进程探针")
    ap.add_argument("--all", action="store_true", help="列出全量 pid 与联盟号")
    ap.add_argument("--coalition", help="只列该联盟号的成员")
    ap.add_argument("--verify", help="给出 identity 的 JSON 文件，逐个判死活")
    a = ap.parse_args()

    if a.verify:
        doc = json.load(open(a.verify))
        rows = doc if isinstance(doc, list) else doc.get("identities", [])
        out = [{"ident": r, "alive": alive(r)} for r in rows]
        print(json.dumps({"checked": len(out), "rows": out}, ensure_ascii=False, indent=2))
        return 0
    if a.coalition:
        print(json.dumps({"coalition": a.coalition, "members": members(a.coalition)}, ensure_ascii=False, indent=2))
        return 0
    if a.all:
        rows = []
        for pid in all_pids():
            b = bsd(pid)
            c = coalition(pid)
            if b:
                rows.append({"pid": b["pid"], "ppid": b["ppid"], "comm": b["comm"],
                             "coalition": c["key"] if c else None})
        print(json.dumps({"count": len(rows), "rows": rows[:400]}, ensure_ascii=False, indent=2))
        return 0
    print(json.dumps(snapshot(), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
