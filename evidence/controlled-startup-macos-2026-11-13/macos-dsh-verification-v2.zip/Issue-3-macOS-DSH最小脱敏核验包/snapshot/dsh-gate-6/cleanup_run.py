#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""清理/恢复入口的薄包装：复用 dsh_gate.py 的 --cleanup-run 模式。

用法：
    python3 gate/cleanup_run.py --config <cfg> --cleanup-run <RUN_ID> [--product mock|real]
它只清理该 run 记录的作业标签与联盟号，复查无残留后写 cleanup_verified；
任何未知/仍有活进程/标签状态未知都不写结束证据、返回非 0。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import dsh_gate  # noqa: E402

if __name__ == "__main__":
    sys.exit(dsh_gate.main(sys.argv[1:]))
