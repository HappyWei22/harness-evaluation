#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一实验启动入口（DSH 受控启动 gate）。

这个程序是后续受控实验唯一的提交入口。它按固定顺序执行，任何一步不满足就拒绝，
并在拒绝时不提交任务：

    取得独占运行资格 -> 准备并检查工作区 -> 检查实际读取权限
    -> 提交任务 -> 等待真实结束 -> 收集记录并清理 -> 释放运行资格

设计要点
--------
1. 只有本程序的 submit 函数会真正启动产品进程；所有检查都在它之前。
2. 没有 --force / --skip-check 一类的强制放行开关。检查失败只能修条件，不能绕过。
3. 探针只报“观察到的现象”，判定规则写在本程序里，避免探针自己宣布通过。
4. 结束以三条独立证据同时成立为准：进程退出码、会话日志的 turn/end、无残留子进程。
   任何一条缺失或矛盾，本场记为“未确认结束”，下一场一律拒绝启动。
5. 锁与运行登记放在固定的控制目录（默认 ~/.dsh-gate），不随配置文件或记录目录移动。
   否则换一份配置就等于换一把锁，两场可以同时启动。
6. 进程归属只用“多信号扫描 + 采样留档”，并明确写出它看不到的形态（见 residual_gap）。
   看不全就不许把结论写成“已确认”，这一点写在每条记录里，而不是只写在文档里。

退出码
------
0  正常结束并已确认
2  拒绝启动（检查未通过，未提交任务）
3  已有其他启动请求持有运行资格
4  存在上一场未确认结束的运行
5  提交后产品异常结束
6  提交后结束未确认（任务可能仍在运行）
"""

import argparse
import errno
import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import job_runtime as JR  # noqa: E402

GATE_VERSION = "dsh-gate-6"
JOB_ENTRY = os.path.join(HERE, "job_entry.py")
PROBE_KIND = "dsh-gate-probe-v1"
PROFILE_KIND = "dsh-gate-seatbelt-v1"
RECOVERY_KIND = "dsh-gate-recovery-v1"
JOB_ATTRIBUTION = "launchd_coalition"

def account_home():
    """账户的真实家目录：按 passwd 记录取，不看 $HOME。

    $HOME 只是一个环境变量，改它就能把整块登记（包括锁）搬到别处，从而让上一场
    的阻塞记录“消失”。位置要固定，就不能固定在一个可以被启动者改写的变量上。
    取不到 passwd 记录时才退回 expanduser（并在记录里注明依据是环境变量）。
    """
    try:
        import pwd
        return pwd.getpwuid(os.getuid()).pw_dir, "passwd"
    except Exception:  # noqa: BLE001 - 没有 passwd 的平台才走这里
        return os.path.expanduser("~"), "env"


ACCOUNT_HOME, HOME_BASIS = account_home()

# 锁的位置是硬编码的：任何配置项都不能改变它，否则“换份配置”就等于“换把锁”。
DEFAULT_CONTROL_ROOT = os.path.join(ACCOUNT_HOME, ".dsh-gate")
CONTROL_ROOT_ENV = "DSH_GATE_CONTROL_ROOT"
LOCK_PATH = os.path.join(DEFAULT_CONTROL_ROOT, "control.lock")

# 必须出现在探针结果里的入口。少一项即视为“缺少结果”，不能算通过。
REQUIRED_PROBE_ENTRIES = (
    "workspace_read",
    "protected_open_absolute",
    "protected_open_traversal",
    "protected_open_symlink",
    "shell_cat",
    "search_grep_recursive",
    "code_exec_open",
)

# 运行记录状态机。只有 ENDED_* 是终态。
ST_SUBMITTING = "submitting"
ST_RUNNING = "running"
ST_ENDED_VERIFIED = "ended_verified"
ST_ENDED_LIMITED = "ended_verified_limited"
ST_ENDED_FORCED = "ended_forced"
ST_UNVERIFIED = "unverified"
ST_REJECTED = "rejected"
TERMINAL_OK = (ST_ENDED_VERIFIED, ST_ENDED_LIMITED, ST_ENDED_FORCED)
TERMINAL_ALL = TERMINAL_OK + (ST_UNVERIFIED, ST_REJECTED)
KNOWN_STATES = (
    ST_SUBMITTING, ST_RUNNING, ST_ENDED_VERIFIED, ST_ENDED_LIMITED,
    ST_ENDED_FORCED, ST_UNVERIFIED, ST_REJECTED,
)

# 只有这两种状态构成下一场的放行依据，而且其中没有“人工恢复”这一条：
#   ended_verified —— 要求有可整体归属的进程边界（本版没有实现，所以实际不会出现）；
#   rejected       —— 要求确实一次都没提交（由 evaluate_previous_run 另行核对）。
#
# 恢复凭据**不在**这里，这是刻意的。凭据依赖的是同一套有漏检的扫描，它没有引入任何新的
# 证据来源；把凭据算成放行依据，等于用“多写一个字段”换“未知变已知”。要放行只有一条路：
# 真的拿到可整体归属的进程边界（见 方案-正常结束可放行.md），让状态变成 ended_verified。
RELEASING_STATES = (ST_ENDED_VERIFIED, ST_REJECTED)

# 其余一律挡住下一场。ended_verified_limited / ended_forced 的措辞是“三项证据齐”，
# 但既然证明不了所有后代都停了，就不能当作放行依据——这是本版最关键的取舍。
BLOCKING_STATES = tuple(s for s in KNOWN_STATES if s not in RELEASING_STATES)

# 工具链里可能出现“子进程”的工具。会话日志里这些工具一旦被调用，
# 单靠进程扫描就不足以断言“没有东西还在跑”。
PROCESS_SPAWNING_TOOLS = ("bash", "shell", "terminal", "exec", "run", "python", "node",
                          "subagent", "job", "task", "browser", "lsp")


def residual_gap_text():
    """多信号进程归属看不到的形态，逐字写进每条记录。"""
    return ("子进程若同时满足：调用 setsid(2) 脱离会话、清空环境变量、关闭全部继承的文件描述符、"
            "切换到与运行目录无关的工作目录，且命令行不含运行目录或运行 ID，"
            "则本程序的扫描在它父进程退出后看不到它。"
            "要闭合这一形态，需要在操作系统层面给产品及其全部后代划出一个可整体归属的边界；"
            "本版没有实现任何这样一层，也没有验证过哪种实现可行（候选见报告「待决」一节）。")


def attribution_requirement_text():
    """先说要保证什么，再说候选实现。避免把“独立 uid”写成已经证明的唯一解。"""
    return ("需要保证的是：产品提交之后派生出来的每一个进程——无论它怎么脱离进程组、会话、"
            "工作目录和文件描述符——在事后都能被判定“属于这一场”，从而能回答"
            "“它是不是还在跑”。这是判定串行的前提，不是某个具体命令的要求。"
            "候选实现至少包括：(a) 独立 uid 运行，按 uid 归属；(b) 容器／虚拟机，按整个运行实例归属；"
            "(c) 内核级审计（EndpointSecurity、dtrace、auditpipe 之类）按事件流归属；"
            "(d) 只允许受控启动器派生进程，产品不允许自己 fork／exec。"
            "四种都需要额外权限或额外运行环境，本版一种都没有实现，也一种都没有验证，"
            "因此不下“必须用哪一种”的结论。")


class ProcessMonitor(threading.Thread):
    """运行期间持续采样，把见过的后代进程记下来。

    为什么必须有它：子进程可能在父进程退出后的任意时刻 setsid 脱离进程组与会话。
    等结束再去扫，它已经不在任何可归属的集合里了。采样拿不到全部（间隔内的
    生死看不到），但能把“曾经是后代”这一事实留档，结束校验据此判断是否还活着。
    """

    def __init__(self, root_pid, interval=0.25):
        super(ProcessMonitor, self).__init__(daemon=True)
        self.root_pid = root_pid
        self.interval = interval
        self.seen = {}
        self.session_id = None
        self.samples = 0
        self.error = None
        self._stop_event = threading.Event()

    def run(self):
        while not self._stop_event.is_set():
            try:
                self.sample_once()
            except Exception as exc:  # noqa: BLE001  采样失败不能拖垮主流程，但要留痕
                self.error = str(exc)
            self._stop_event.wait(self.interval)

    def sample_once(self):
        rows = Gate.ps_table()
        if rows is None:
            self.error = "ps 不可用"
            return
        self.samples += 1
        by_pid = {row["pid"]: row for row in rows}
        root = by_pid.get(self.root_pid)
        if root is not None and self.session_id is None:
            self.session_id = root["sess"]
        # 从产品进程出发沿着 ppid 向下找，把整棵树记下来。
        children = {}
        for row in rows:
            children.setdefault(row["ppid"], []).append(row)
        stack = [self.root_pid]
        while stack:
            current = stack.pop()
            for child in children.get(current, []):
                if child["pid"] not in self.seen:
                    self.seen[child["pid"]] = {
                        "pid": child["pid"], "ppid": child["ppid"],
                        "pgid": child["pgid"], "sess": child["sess"],
                        "command": child["command"][:300], "at": now_iso(),
                    }
                stack.append(child["pid"])

    def stop(self):
        self._stop_event.set()
        self.join(timeout=5)
        return {"samples": self.samples, "seen": sorted(self.seen.values(),
                                                        key=lambda item: item["pid"]),
                "session_id": self.session_id, "error": self.error}


class Reject(Exception):
    """检查未通过。触发时任务一定尚未提交。"""

    def __init__(self, code, stage, reason, detail=None, evidence=None):
        super().__init__(reason)
        self.code = code
        self.stage = stage
        self.reason = reason
        self.detail = detail or {}
        self.evidence = evidence or {}


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def code_identity():
    """本版的代码身份：版本串 + 每个文件的 sha256。

    为什么要这个：回复里说「已保存 v3」而记录里写 `gate_version=dsh-gate-2`，就说不清测的是哪一版。
    版本串是人起的名字（会写错），指纹是内容算出来的（写不错）。两个都记，并且以指纹为准：
    结论只能和指纹一起引用，只有版本名不算凭据。
    """
    here = os.path.dirname(os.path.abspath(__file__))
    files = {
        "gate": os.path.abspath(__file__),
        "probe": os.path.join(here, "probe", "probe_read.py"),
        "recover": os.path.join(here, "recover_run.py"),
        "job_entry": os.path.join(here, "job_entry.py"),
        "job_runtime": os.path.join(here, "job_runtime.py"),
        "probe_proc": os.path.join(here, "probe_proc.py"),
        "cleanup_entry": os.path.join(here, "cleanup_run.py"),
    }
    out = {"version": GATE_VERSION, "python": sys.version.split()[0], "files": {}}
    for name, path in files.items():
        try:
            out["files"][name] = {"path": path, "sha256": sha256_file(path)}
        except OSError as exc:
            out["files"][name] = {"path": path, "sha256": None, "error": str(exc)}
    # 一个短的组合指纹，方便在标题/表格里引用（不是哈希的全部信息，长指纹在上面的 files 里）。
    joined = "".join((out["files"][k].get("sha256") or "") for k in
                     ("gate", "probe", "recover", "job_entry", "job_runtime", "probe_proc",
                      "cleanup_entry"))
    out["bundle_sha256"] = sha256_bytes((GATE_VERSION + joined).encode("utf-8"))
    out["bundle_short"] = out["bundle_sha256"][:12]
    return out


def write_json(path, payload):
    """直接写目标文件并 fsync。

    早期版本先写 `<path>.tmp` 再 os.replace 保证原子性。这台机器上有一层安全策略会拦截
    “删除/改名掉临时文件”的动作（实测 `os.replace` 直接失败），整条启动链会因此在
    建登记记录那一步崩掉。这里改成直写 + fsync：中途断电最多留下半个 JSON，
    而半个 JSON 在上一场检查里会被当成「无法解析」→ 拒绝启动，方向是保守的，
    不会把「没确认」误判成「已结束」。
    """
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def is_within(child, parent):
    """路径包含判断，按真实路径比较，避免 ../ 和符号链接造成的误判。"""
    child = os.path.realpath(child)
    parent = os.path.realpath(parent)
    return child == parent or child.startswith(parent.rstrip(os.sep) + os.sep)


class Gate(object):
    def __init__(self, config_path, run_id, prompt_path, product_kind, mock_extra):
        self.config_path = os.path.abspath(config_path)
        self.run_id = run_id
        self.prompt_path = os.path.abspath(prompt_path) if prompt_path else None
        self.product_kind = product_kind
        self.mock_extra = mock_extra
        self.started_at = now_iso()
        self.started_monotonic = time.monotonic()
        self.stage = "init"
        self.record = {
            "gate_version": GATE_VERSION,
            "code": code_identity(),
            "run_id": run_id,
            "started_at": self.started_at,
            "stages": [],
            "submissions": 0,
        }
        self.lock_handle = None
        self.child = None
        self.child_pgid = None
        self.monitor = None
        self.control_root = None
        self.control_run_dir = None

    # ------------------------------------------------------------------ 记录
    def note(self, stage, **fields):
        entry = {"stage": stage, "at": now_iso()}
        entry.update(fields)
        self.record["stages"].append(entry)
        print("[gate] %-22s %s" % (stage, json.dumps(fields, ensure_ascii=False)), file=sys.stderr)

    # ------------------------------------------------------------------ 配置
    def load_config(self):
        try:
            cfg = read_json(self.config_path)
        except OSError as exc:
            raise Reject(2, "config", "配置文件读取失败", {"path": self.config_path,
                                                          "error": str(exc)})
        except ValueError as exc:
            raise Reject(2, "config", "配置文件不是合法 JSON", {"path": self.config_path,
                                                                "error": str(exc)})
        if cfg.get("schema") != "dsh-gate-config-v1":
            raise Reject(2, "config", "配置格式不匹配", {"schema": cfg.get("schema")})

        # 统一规范化，后续所有比较都用真实路径。
        cfg["run_root"] = os.path.realpath(os.path.expanduser(cfg["run_root"]))
        cfg["records_root"] = os.path.realpath(os.path.expanduser(cfg["records_root"]))
        cfg["protected_roots"] = [os.path.realpath(os.path.expanduser(p)) for p in cfg["protected_roots"]]
        cfg["protected_probe"] = os.path.realpath(os.path.expanduser(cfg["protected_probe"]))
        inputs = cfg.get("inputs", {})
        inputs["source_dir"] = os.path.realpath(os.path.expanduser(inputs["source_dir"]))
        inputs["manifest"] = os.path.realpath(os.path.expanduser(inputs["manifest"]))
        cfg["inputs"] = inputs

        self.config = cfg
        self.check_entry_separation(cfg)
        # 配置指纹：规范化后的内容，任何一个字段变化都会让旧检查失效。
        self.config_sha256 = sha256_bytes(
            json.dumps(cfg, ensure_ascii=False, sort_keys=True).encode("utf-8")
        )
        self.record["config_path"] = self.config_path
        self.record["config_sha256"] = self.config_sha256
        self.resolve_control_root()

    def check_entry_separation(self, cfg):
        """模拟入口与真实入口必须指向不同的东西，否则「验收」会把额度花在真产品上。

        这是验收隔离的关键一条：模拟用例全都不该有机会启动真实产品。能查的只有一条——
        模拟入口的命令行里不能出现真实产品的可执行文件；模拟任务内部若自己去 exec 真实
        二进制，本程序看不到（这属于「检查范围」而不是「已验证」）。所以记录里写清楚查了
        什么、没查什么，不写成「已保证」。
        """
        product_cmd = (cfg.get("product") or {}).get("command") or []
        mock_cmd = (cfg.get("mock") or {}).get("command") or []
        real_bin = os.path.realpath(product_cmd[0]) if product_cmd else None
        mock_bin = os.path.realpath(mock_cmd[0]) if mock_cmd else None
        forbidden_dirs = [os.path.realpath("/Applications/DeepSeek Harness.app")]
        info = {"product_bin": real_bin, "mock_bin": mock_bin,
                "product_kind": self.product_kind,
                "checked": ["mock.command[0] 与 product.command[0] 是否同一个文件",
                            "mock.command[0] 是否落在 DeepSeek Harness 应用包内"],
                "not_checked": ["模拟任务内部是否自行 exec 真实产品二进制",
                                "模拟入口用到的解释器是否被替换"]}
        if mock_bin and real_bin and mock_bin == real_bin:
            raise Reject(2, "config", "模拟入口指向了真实产品，验收与真实提交没有分开",
                         dict(info, conflict="mock_bin == product_bin"))
        if mock_bin:
            for root in forbidden_dirs:
                if is_within(mock_bin, root):
                    raise Reject(2, "config", "模拟入口落在真实产品应用包内，验收与真实提交没有分开",
                                 dict(info, conflict="mock_bin_in_app_bundle", root=root))
        info["real_product_excluded"] = True
        self.record["entry_separation"] = info

    def resolve_control_root(self):
        """确定锁与运行登记的位置。

        锁永远是 ~/.dsh-gate/control.lock，不受配置或环境变量影响。
        登记目录默认与锁同处一地。重定向只给验收用，并且**对真实入口一律不成立**：
        真实产品的提交必须登记在固定位置，否则“换一个登记目录”就等于把上一场藏起来，
        启动程序会以为自己是第一场。这条不随配置放宽——配置只能管模拟任务。
        """
        cfg = self.config
        ctl = cfg.get("control") or {}
        allow_override = bool(ctl.get("allow_override", False))
        override = os.environ.get(CONTROL_ROOT_ENV)
        if override and self.product_kind == "real":
            raise Reject(2, "config",
                         "真实入口不允许改运行登记位置",
                         {"env": override, "product": self.product_kind,
                          "lock_path": LOCK_PATH,
                          "why": "登记换地方，上一场的阻塞记录就会被看不见；"
                                 "重定向只允许用于 --product mock 的验收。"})
        if override and not allow_override:
            raise Reject(2, "config",
                         "环境变量 %s 想把运行登记挪到别处，但配置不允许" % CONTROL_ROOT_ENV,
                         {"env": override, "control.allow_override": allow_override})
        root = override if override else DEFAULT_CONTROL_ROOT
        self.control_root = os.path.realpath(os.path.expanduser(root))
        self.record["control"] = {
            "root": self.control_root,
            "root_overridden": bool(override),
            "override_allowed_for": "mock-only" if allow_override else "none",
            "product_kind": self.product_kind,
            "lock_path": LOCK_PATH,
            "lock_fixed": True,
            "home_basis": HOME_BASIS,
            "default_root": DEFAULT_CONTROL_ROOT,
            "note": "锁固定在同一位置；真实入口的登记位置也固定，换配置或换目录都不生效。"
                    "默认位置按账户真实家目录（passwd）计算，不随 $HOME 变化。",
        }

    # ------------------------------------------------------------------ 资格
    def acquire_lock(self):
        self.stage = "lock"
        # 先做准备再取锁：控制目录固定，创建它与“谁先到”无关。
        os.makedirs(os.path.dirname(LOCK_PATH), mode=0o700, exist_ok=True)
        lock_path = LOCK_PATH
        handle = open(lock_path, "a+")
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            handle.seek(0)
            holder = handle.read().strip()
            handle.close()
            if exc.errno in (errno.EAGAIN, errno.EACCES):
                raise Reject(3, "lock", "已有另一个启动请求持有运行资格",
                             {"lock_path": lock_path, "holder": holder,
                              "note": "锁固定在 %s，与配置文件和记录目录无关。" % lock_path})
            raise
        # 把持有者信息写进锁文件，便于拒绝时给出是谁在跑。
        handle.seek(0)
        handle.truncate()
        handle.write(json.dumps({"pid": os.getpid(), "run_id": self.run_id,
                                 "since": now_iso()}, ensure_ascii=False))
        handle.flush()
        os.fsync(handle.fileno())
        self.lock_handle = handle
        self.note("lock", acquired=True, lock_path=lock_path, fixed=True)

    def release_lock(self):
        if self.lock_handle is None:
            return
        try:
            self.lock_handle.seek(0)
            self.lock_handle.truncate()
            self.lock_handle.write(json.dumps({"released_at": now_iso()}, ensure_ascii=False))
            self.lock_handle.flush()
            fcntl.flock(self.lock_handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.lock_handle.close()
            self.lock_handle = None
        self.note("lock", released=True)

    def scan_previous_runs(self):
        """上一场是否已经真正结束。

        锁只能证明“此刻没有别的启动程序”，不能证明“上一场产品已停止”：
        启动程序崩溃时锁会自动释放，产品进程却可能还活着。所以这里查运行登记。

        判定是“只有确认过才算结束”，不是“没看到问题就算结束”：
          - 目录在、记录不在        -> 无法确认，拒绝
          - 记录在、状态字段缺失    -> 无法确认，拒绝
          - 状态值不在已知集合内    -> 无法确认，拒绝
          - 已停止状态的证据不完整  -> 无法确认，拒绝
          - 改状态字符串不算恢复；人工旁证也不算恢复（它用的还是同一套扫描）
        """
        self.stage = "previous-run-check"
        runs_dir = os.path.join(self.control_root, "runs")
        blocking = []
        if os.path.isdir(runs_dir):
            for name in sorted(os.listdir(runs_dir)):
                path = os.path.join(runs_dir, name)
                if not os.path.isdir(path):
                    blocking.append({"run_id": name, "problem": "stray_entry",
                                     "why": "运行登记目录里有非目录条目，无法判断它是什么"})
                    continue
                blocking.extend(self.evaluate_previous_run(name, path))
        if not blocking:
            self.note("previous-run-check", blocking=0, registry=runs_dir)
            return
        raise Reject(4, "previous-run-check",
                     "存在无法确认已结束的上一场运行，必须先核实并人工处理",
                     {"blocking": blocking,
                      "registry": runs_dir,
                      "how_to_resolve": "本版没有解除途径，这是刻意的。"
                                        "gate/recover_run.py 生成的旁证只能说明「有人在那个时刻"
                                        "看过一遍」，它用的还是同一套有漏检的扫描（且少一路 lsof），"
                                        "不会把未知变成已知，因此不放行。"
                                        "要恢复必须先有可整体归属的进程边界（见 "
                                        "方案-正常结束可放行.md），让本场状态真的成为 ended_verified。"
                                        "本程序不提供强制放行开关，也不接受改写状态字符串。"})

    def evaluate_previous_run(self, name, path):
        """返回这条历史登记带来的阻塞项列表；空列表表示可以确认它已结束。"""
        status_file = os.path.join(path, "status.json")
        if not os.path.isfile(status_file):
            return [{"run_id": name, "problem": "record_missing",
                     "why": "运行目录存在但状态记录缺失，无法判断该场是否结束",
                     "path": status_file}]
        try:
            rec = read_json(status_file)
        except (OSError, ValueError) as exc:
            return [{"run_id": name, "problem": "record_unreadable",
                     "why": "运行记录无法解析，无法判断该场是否结束",
                     "path": status_file, "error": str(exc)}]
        status = rec.get("status")
        if not isinstance(status, str) or not status:
            return [{"run_id": name, "problem": "status_missing",
                     "why": "记录里没有状态字段，无法判断该场是否结束",
                     "path": status_file, "record_keys": sorted(rec.keys())}]
        if status not in KNOWN_STATES:
            return [{"run_id": name, "problem": "status_unknown",
                     "why": "状态值不在已知集合内，无法判断该场是否结束",
                     "path": status_file, "status": status,
                     "known_states": list(KNOWN_STATES)}]

        # 作业模式（launchd_coalition）的记录：有作业边界，按联盟号 + 结束证据判定。
        if rec.get("job") or (isinstance(rec.get("attribution"), dict)
                              and rec["attribution"].get("mode") == JOB_ATTRIBUTION):
            return self.evaluate_previous_job(name, rec, status_file)

        # 旧的多信号模式：凭据不是放行依据，这一点是刻意的。
        # 凭据记录的只是「有人在那个时刻看过一遍」，而看的那一眼用的是和本程序
        # 同一套有漏检的多信号扫描（还少一路 lsof），没有引入任何新的证据来源。
        # 把它算成放行依据，等于用「多写一个文件」把同一个未知重新包装成「已确认」。
        # 所以它只作旁证原样写进阻塞项：看得到、看得懂、但仍不免除阻塞。
        voucher = self.verify_recovery_voucher(name, rec)
        voucher_note = None
        if voucher.get("present"):
            voucher_note = {
                "present": True,
                "valid": bool(voucher.get("valid")),
                "problems": voucher.get("problems") or [],
                "resolved_by": voucher.get("resolved_by"),
                "resolved_at": voucher.get("resolved_at"),
                "attribution": voucher.get("attribution"),
                "declared_unknown": voucher.get("declared_unknown"),
                "role": "旁证，不构成放行依据",
                "why_not_a_release": (
                    "凭据依赖同一套多信号扫描（且少一路 lsof），没有引入新的证据来源；"
                    "写成凭据不改变「看不见的还是看不见」"),
            }

        if status in BLOCKING_STATES:
            if status in (ST_SUBMITTING, ST_RUNNING, ST_UNVERIFIED):
                problem, why = "not_ended", "该场没有确认结束"
            elif status == ST_ENDED_LIMITED:
                problem = "limited_not_released"
                why = ("三项证据一致，但没有可整体归属的进程边界；"
                       "「看不出还在跑」不等于「已停止」，不作为放行依据")
            elif status == ST_ENDED_FORCED:
                problem = "forced_not_released"
                why = ("超时后强制停止，同样没有可整体归属的进程边界；"
                       "强制停止不能代替“证明都停了”")
            else:
                problem, why = "unknown_blocking", "该状态不构成放行依据"
            entry = {"run_id": rec.get("run_id", name), "status": status,
                     "problem": problem, "why": why,
                     "pid": rec.get("product_pid"),
                     "pgid": rec.get("product_pgid"), "started_at": rec.get("started_at"),
                     "product_pid_alive": self.probe_pid(rec.get("product_pid")),
                     "releasable": False}
            if voucher_note:
                entry["voucher"] = voucher_note
            return [entry]

        if status == ST_REJECTED:
            if rec.get("submissions", 0) != 0:
                return [{"run_id": name, "problem": "rejected_but_submitted",
                         "why": "状态写着拒绝，但记录显示已经提交过，两者矛盾",
                         "submissions": rec.get("submissions")}]
            return []

        # 终态：必须带着「怎么确认的」证据，缺一项就等于没确认。
        # 凭据补不上这个洞：它没带来新证据，只是把同一次扫描换个文件再说一遍。
        problems = self.end_evidence_problems(rec, status)
        if problems:
            entry = {"run_id": name, "problem": "end_evidence_incomplete",
                     "why": "状态写着已结束，但支撑它的证据不完整",
                     "status": status, "problems": problems,
                     "releasable": False}
            if voucher_note:
                entry["voucher"] = voucher_note
            return [entry]
        return []

    def evaluate_previous_job(self, name, rec, status_file):
        """作业模式的上一场判定：状态 + 作业联盟号 + 结束证据三者一致才放行。"""
        job = rec.get("job") or {}
        coalition = job.get("coalition")
        status = rec.get("status")
        end = rec.get("job_end_evidence")
        if not end:
            end_path = os.path.join(os.path.dirname(status_file), "end.json")
            try:
                end = read_json(end_path) if os.path.isfile(end_path) else None
            except (OSError, ValueError):
                end = None
        base = {"run_id": name, "status": status, "job_label": job.get("label"),
                "job_coalition": coalition, "releasable": False}
        if status == ST_REJECTED:
            if rec.get("submissions", 0) != 0:
                return [dict(base, problem="rejected_but_submitted",
                             why="状态写着拒绝，但记录显示已经提交过")]
            return []
        if status in (ST_SUBMITTING, ST_RUNNING):
            if not coalition:
                return [dict(base, problem="job_boundary_missing",
                             why="该场处于运行中/提交中，但没有记录作业联盟号，无法判断是否结束")]
            live = JR.members(coalition)
            if live is None:
                return [dict(base, problem="coalition_scan_unavailable",
                             why="无法枚举作业联盟号，无法判断该场是否结束")]
            if live:
                return [dict(base, problem="not_ended",
                             why="该场没有确认结束：作业联盟号里仍有活进程",
                             live=[{"pid": r["pid"], "comm": r.get("comm")} for r in live])]
            return [dict(base, problem="end_evidence_missing",
                         why="作业联盟号里已无活进程，但没有结束证据，状态仍是未结束")]
        if status in (ST_ENDED_LIMITED, ST_ENDED_FORCED, ST_UNVERIFIED):
            return [dict(base, problem="job_status_blocks",
                         why="作业模式下的该状态不构成放行依据",
                         note="只有 ended_verified（normal_exit/cleanup_verified）才放行")]
        if status != ST_ENDED_VERIFIED:
            return [dict(base, problem="unknown_blocking", why="该状态不构成放行依据")]
        if not coalition:
            return [dict(base, problem="job_boundary_missing",
                         why="状态为 ended_verified，但没有记录作业联盟号")]
        if not isinstance(end, dict):
            return [dict(base, problem="end_evidence_missing",
                         why="状态为 ended_verified，但找不到 end.json 结束证据")]
        if end.get("kind") not in ("normal_exit", "cleanup_verified"):
            return [dict(base, problem="end_evidence_incomplete",
                         why="end.kind 不在允许集合内", kind=end.get("kind"))]
        if end.get("verified_no_live_procs") is not True:
            return [dict(base, problem="end_evidence_incomplete",
                         why="end.json 没有写明复查时无活进程")]
        if end.get("coalition") and end.get("coalition") != coalition:
            return [dict(base, problem="end_evidence_mismatch",
                         why="end.json 的联盟号与作业记录不一致",
                         end_coalition=end.get("coalition"))]
        live = JR.members(coalition)
        if live is None:
            return [dict(base, problem="coalition_scan_unavailable",
                         why="无法枚举作业联盟号，不能仅凭旧证据放行")]
        if live:
            return [dict(base, problem="live_in_coalition",
                         why="结束证据存在，但作业联盟号里仍有活进程",
                         live=[{"pid": r["pid"], "comm": r.get("comm")} for r in live])]
        return []

    @staticmethod
    def end_evidence_problems(rec, status):
        problems = []
        ev = rec.get("end_verification") or {}
        if "survivors" not in ev:
            problems.append("没有残留进程扫描结果")
        elif ev.get("survivors"):
            problems.append("记录里还留着残留进程")
        session = ev.get("session") or {}
        if session.get("state") != "found":
            problems.append("没有会话日志")
        elif not session.get("turn_end"):
            problems.append("会话日志没有 turn/end")
        if status == ST_ENDED_FORCED:
            if not ev.get("timed_out"):
                problems.append("强制结束状态但记录里没有超时标记")
        else:
            if ev.get("timed_out"):
                problems.append("状态与超时标记矛盾")
        return problems

    def verify_recovery_voucher(self, run_id, rec):
        """核对人工观察旁证（gate/recover_run.py 生成）。

        注意它的名字里虽然还有 voucher，但**结果不参与放行判定**：
        `valid` 只表示「这条观察记录本身自洽（指纹对得上、当时扫描为空、
        并且自己写明了看不到什么）」，不表示「上一场已经结束」。
        调用方（evaluate_previous_run）只用它当旁证，无论 valid 与否都不解除阻塞。

        核对方式：重新算一遍会话日志指纹、再当场扫一遍进程，任何一项对不上就 valid=False。
        """
        path = os.path.join(self.control_root, "recovery", run_id + ".json")
        if not os.path.isfile(path):
            return {"present": False, "path": path}
        try:
            doc = read_json(path)
        except (OSError, ValueError) as exc:
            return {"present": True, "valid": False, "path": path,
                    "problems": ["凭据无法解析：%s" % exc]}
        problems = []
        if doc.get("kind") != RECOVERY_KIND:
            problems.append("凭据类型不符")
        if doc.get("run_id") != run_id:
            problems.append("凭据里的运行 ID 与目录不一致")
        for field in ("resolved_by", "resolved_at", "basis"):
            if not str(doc.get(field) or "").strip():
                problems.append("缺少 %s" % field)
        evidence = doc.get("evidence") or {}
        log_sha = evidence.get("session_log_sha256")
        log_path = evidence.get("session_log_path")
        if not log_sha or not log_path:
            problems.append("凭据没有记录会话日志与指纹")
        elif not os.path.isfile(log_path):
            problems.append("凭据指向的会话日志不存在")
        else:
            actual = sha256_file(log_path)
            if actual != log_sha:
                problems.append("会话日志指纹与凭据不符（日志被改过？）")
        if not evidence.get("turn_end_reason"):
            problems.append("凭据没有记录 turn/end 的原因")
        if evidence.get("survivors") != []:
            problems.append("凭据里的残留进程列表不是空的")
        # 凭据必须自己说明「这个扫描看不到什么」。缺这一项，等于把同一个未知
        # 换个文件重新包装成“已确认”，所以直接判凭据无效。
        declares_limit = evidence.get("attribution") in ("multi_signal", "uid_isolation",
                                                        "launchd_coalition", "container")
        unknown_text = evidence.get("unknown")
        if isinstance(unknown_text, list):
            unknown_text = "；".join(str(x) for x in unknown_text)
        if not declares_limit or not str(unknown_text or "").strip():
            problems.append("凭据没有写明归属方式与它看不到的形态（等于把未知包装成已确认）")
        # 这张记录只能声称「看过」，不能声称「已放行」或「已清理」。
        # 允许的取值只有 observation_only；写成别的（尤其是 released／confirmed）
        # 说明生成方想用换个词的办法扩大它的效力，那这条记录就不可信。
        claims = str(doc.get("claims") or "")
        if claims != "observation_only":
            problems.append("旁证自称「%s」，超出「只记录一次观察」的范围" % (claims or "（空）"))
        # 现在再扫一遍：凭据说“没了”，就得现在还看不到。
        now_survivors = self.find_survivors(
            pgid=rec.get("product_pgid"), run_id=run_id, pid=rec.get("product_pid"))
        if now_survivors is None:
            problems.append("此刻无法枚举进程，无法复核凭据")
        elif now_survivors:
            problems.append("此刻仍能看到属于该场的进程")
        return {"present": True, "valid": not problems, "path": path,
                "problems": problems, "resolved_by": doc.get("resolved_by"),
                "resolved_at": doc.get("resolved_at"),
                "attribution": evidence.get("attribution"),
                "declared_unknown": unknown_text}

    def test_hook_crash(self, name, stage):
        """验收专用：在指定阶段让启动程序硬崩溃（SIGKILL，不给任何清理机会）。

        只由环境变量 GATE_TEST_HOOK 触发，用来复现“启动程序崩溃后留下一条
        status=submitting 的登记记录、锁被操作系统释放”的现场。
        它不是放行开关，也不改变任何判定规则：崩溃之后没有任何代码会跑。
        """
        if os.environ.get("GATE_TEST_HOOK") != name:
            return
        self.stage = stage
        os.kill(os.getpid(), signal.SIGKILL)

    def register_run(self):
        """在固定登记目录里为本次运行建一条状态记录。

        必须在提交之前建：启动程序若在提交后崩溃，这条记录就是下一场判断的依据。
        """
        runs_dir = os.path.join(self.control_root, "runs")
        os.makedirs(runs_dir, mode=0o700, exist_ok=True)
        self.control_run_dir = os.path.join(runs_dir, self.run_id)
        os.makedirs(self.control_run_dir)
        os.chmod(self.control_run_dir, 0o700)
        self.write_control_status()
        self.note("register", control_run_dir=self.control_run_dir)

    def write_control_status(self):
        if not self.control_run_dir:
            return
        payload = {
            "run_id": self.run_id,
            "gate_version": GATE_VERSION,
            "code": {"version": GATE_VERSION,
                     "bundle_short": (self.record.get("code") or {}).get("bundle_short"),
                     "gate_sha256": ((self.record.get("code") or {}).get("files") or {}).get(
                         "gate", {}).get("sha256")},
            "status": self.record.get("status", ST_SUBMITTING),
            "stage": self.stage,
            "updated_at": now_iso(),
            "started_at": self.record.get("started_at"),
            "submitted_at": self.record.get("submitted_at"),
            "ended_at": self.record.get("ended_at"),
            "submissions": self.record.get("submissions", 0),
            "product_pid": self.record.get("product_pid"),
            "product_pgid": self.record.get("product_pgid"),
            "job": self.record.get("job"),
            "job_end_evidence": self.record.get("job_end_evidence"),
            "attribution": self.record.get("attribution"),
            "workspace": self.record.get("workspace", {}).get("path"),
            "home_root": getattr(self, "home_root", None),
            "records_run_dir": getattr(self, "run_dir", None),
            "exit_code": self.record.get("exit_code"),
            "timed_out": self.record.get("timed_out"),
            "end_verification": self.record.get("end_verification"),
            "reject": self.record.get("reject"),
        }
        write_json(os.path.join(self.control_run_dir, "status.json"), payload)


    @staticmethod
    def probe_pid(pid):
        if not isinstance(pid, int) or pid <= 0:
            return None
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    # ------------------------------------------------------------------ 工作区
    def prepare_workspace(self):
        self.stage = "workspace"
        cfg = self.config
        ws_root = os.path.join(cfg["run_root"], "ws")
        os.makedirs(ws_root, exist_ok=True)
        workspace = os.path.join(ws_root, self.run_id)
        if os.path.exists(workspace):
            raise Reject(2, "workspace", "该运行 ID 的工作区已存在，拒绝复用",
                         {"workspace": workspace})
        real_ws = os.path.realpath(workspace)
        if real_ws != workspace:
            raise Reject(2, "workspace", "工作区路径含跳转，实际位置与预期不一致",
                         {"workspace": workspace, "realpath": real_ws})

        # 工作区不能落在受保护范围内，否则产品连自己的题面都读不到。
        for root in cfg["protected_roots"]:
            if is_within(workspace, root):
                raise Reject(2, "workspace", "工作区位于受保护目录内",
                             {"workspace": workspace, "protected_root": root})
        if is_within(workspace, cfg["records_root"]):
            raise Reject(2, "workspace", "工作区位于评测记录目录内",
                         {"workspace": workspace, "records_root": cfg["records_root"]})

        inputs = cfg["inputs"]
        if not os.path.isfile(inputs["manifest"]):
            raise Reject(2, "workspace", "输入清单不存在，先把冻结输入准备好并生成清单",
                         {"manifest": inputs["manifest"],
                          "how_to": "python3 gate/make_input_manifest.py <冻结输入目录>"})
        if not os.path.isdir(inputs["source_dir"]):
            raise Reject(2, "workspace", "输入目录不存在", {"source_dir": inputs["source_dir"]})
        try:
            manifest = read_json(inputs["manifest"])
        except ValueError as exc:
            raise Reject(2, "workspace", "输入清单无法解析", {"manifest": inputs["manifest"],
                                                              "error": str(exc)})
        files = manifest.get("files", [])
        if not files:
            raise Reject(2, "workspace", "输入清单为空", {"manifest": inputs["manifest"]})

        os.makedirs(workspace)
        ws_probe_name = cfg["workspace_probe_name"]
        copied = []
        try:
            for item in files:
                rel = item["path"]
                src = os.path.join(inputs["source_dir"], rel)
                dst = os.path.join(workspace, rel)
                if os.path.islink(src):
                    raise Reject(2, "workspace", "输入含符号链接，本版直接拒绝",
                                 {"path": src})
                if not os.path.isfile(src):
                    raise Reject(2, "workspace", "输入文件缺失或不是普通文件", {"path": src})
                actual = sha256_file(src)
                if actual != item["sha256"]:
                    raise Reject(2, "workspace", "输入文件内容与冻结清单不一致",
                                 {"path": src, "expected": item["sha256"], "actual": actual})
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(src, dst)
                os.chmod(dst, 0o644)
                copied_hash = sha256_file(dst)
                if copied_hash != item["sha256"]:
                    raise Reject(2, "workspace", "复制后指纹不一致",
                                 {"path": dst, "expected": item["sha256"], "actual": copied_hash})
                copied.append({"path": rel, "sha256": copied_hash})

            # 清单外的文件一律不允许（防止旧答案、别的组提示词混进来）。
            present = set()
            for dirpath, _dirnames, filenames in os.walk(workspace):
                for name in filenames:
                    full = os.path.join(dirpath, name)
                    present.add(os.path.relpath(full, workspace))
            expected = set(item["path"] for item in files)
            out_prefix = cfg["inputs"]["output_subdir"].rstrip("/") + "/"
            present = set(p for p in present if not p.startswith(out_prefix))
            extra = sorted(present - expected - {ws_probe_name})
            if extra:
                raise Reject(2, "workspace", "工作区出现清单外文件", {"extra": extra})

            # 输入包若自带内容，先如实复制进来，再检查工作区的输出目录是否为空。
            # 先建空目录再“检查”等于没检查，必须让污染有机会被看见。
            out_dir = os.path.join(workspace, cfg["inputs"]["output_subdir"])
            src_out = os.path.join(inputs["source_dir"], cfg["inputs"]["output_subdir"])
            os.makedirs(out_dir, exist_ok=True)
            if os.path.isdir(src_out):
                for name in os.listdir(src_out):
                    source_item = os.path.join(src_out, name)
                    if os.path.islink(source_item):
                        raise Reject(2, "workspace", "输入中的输出目录含符号链接",
                                     {"path": source_item})
                    target_item = os.path.join(out_dir, name)
                    if os.path.isdir(source_item):
                        shutil.copytree(source_item, target_item)
                    else:
                        shutil.copyfile(source_item, target_item)
            entries = sorted(os.listdir(out_dir))
            if entries:
                raise Reject(2, "workspace", "输出目录初始不为空",
                             {"output_dir": out_dir, "entries": entries})

            # 工作区探针：无业务内容，只用来证明“该读的能读”。
            probe_path = os.path.join(workspace, ws_probe_name)
            with open(probe_path, "w", encoding="utf-8") as handle:
                handle.write("DSH-GATE-PROBE-WORKSPACE-v1\n只用于读取权限检查，不含业务内容。\n")
            os.chmod(probe_path, 0o644)
        except Exception:
            # 准备失败时把半成品目录留在原地并标记，避免后续误把它当成干净工作区。
            write_json(os.path.join(workspace, ".gate-incomplete.json"),
                       {"reason": "workspace preparation failed", "at": now_iso()})
            raise

        self.workspace = workspace
        self.ws_probe_path = probe_path
        self.ws_probe_sha256 = sha256_file(probe_path)
        self.record["workspace"] = {"path": workspace, "realpath": workspace,
                                    "files": copied, "manifest_sha256": sha256_file(inputs["manifest"])}
        self.note("workspace", path=workspace, files=len(copied), output_empty=True)

    def check_path_distinctness(self):
        """不同名字可能指向同一位置，必须按真实路径和 inode 各查一遍。"""
        self.stage = "path-distinctness"
        cfg = self.config
        seen = {}
        targets = {
            "run_root": cfg["run_root"],
            "records_root": cfg["records_root"],
            "workspace": self.workspace,
        }
        for name, root in enumerate(cfg["protected_roots"]):
            targets["protected_root_%d" % name] = root
        for name, path in targets.items():
            real = os.path.realpath(path)
            try:
                st = os.stat(real)
                ident = (st.st_dev, st.st_ino)
            except OSError as exc:
                raise Reject(2, "path-distinctness", "路径无法解析", {"path": path,
                                                                      "error": str(exc)})
            if real in seen:
                raise Reject(2, "path-distinctness", "两个配置项实际指向同一位置",
                             {"a": seen[real][0], "b": name, "realpath": real})
            for other_ident, other in seen.values():
                if other_ident == ident:
                    raise Reject(2, "path-distinctness", "两个配置项指向同一 inode",
                                 {"a": other, "b": name, "realpath": real})
            seen[real] = (name, ident)
        self.note("path-distinctness", ok=True, count=len(targets))

    def check_run_root_clean(self):
        """运行根目录下只允许存在本次运行的目录。

        上一场的产物会被归档进评测记录目录（受保护），运行期目录也随清理搬走；
        因此这里若发现别的运行 ID，说明有上一场没有清理干净，不能继续。
        """
        self.stage = "run-root-check"
        others = {}
        for kind in ("ws", "home"):
            base = os.path.join(self.config["run_root"], kind)
            if not os.path.isdir(base):
                continue
            entries = sorted(name for name in os.listdir(base) if name != self.run_id)
            if entries:
                others[kind] = entries
        if others:
            raise Reject(2, "run-root-check", "运行根目录下还有其他运行的目录，未清理干净",
                         {"run_root": self.config["run_root"], "others": others})
        self.note("run-root-check", ok=True)

    def check_no_stale_context(self):
        """新建干净会话：工作区里不能带会自动加载的项目指令或历史记忆。"""
        self.stage = "context-check"
        suspicious = []
        names = {"AGENTS.md", "CLAUDE.md", ".agents", ".claude", ".codex", ".cursorrules",
                 ".dsh", "MEMORY.md", ".mcp.json"}
        for dirpath, dirnames, filenames in os.walk(self.workspace):
            for name in list(dirnames) + list(filenames):
                if name in names:
                    suspicious.append(os.path.relpath(os.path.join(dirpath, name), self.workspace))
            dirnames[:] = [d for d in dirnames if d not in (".git",)]
        if suspicious:
            raise Reject(2, "context-check", "工作区存在会自动加载的指令文件",
                         {"paths": suspicious})

        dsh_home = self.dsh_home
        if os.path.isdir(dsh_home) and os.listdir(dsh_home):
            raise Reject(2, "context-check", "本次 DSH_HOME 不是空目录，可能带入历史会话或记忆",
                         {"dsh_home": dsh_home, "entries": sorted(os.listdir(dsh_home))})
        self.note("context-check", ok=True, dsh_home_empty=True)

    # ------------------------------------------------------------------ 受限环境
    def check_attribution(self):
        """进程归属能力检查：能保证什么，才允许说“已结束”。

        这一项决定“结束”能说到多硬：
          - 多信号扫描：能给出“现在看不出还有东西在跑”，但给不出“所有后代都在边界内”；
          - 有归属边界（任何一种实现）：后代都可整体判定，才能说“确实没了”。
        本版只实现了多信号扫描；带归属边界的实现一种都没有做，也没有验证，
        所以这里只做两件事：把需要保证的东西写清楚；在没有边界时要求配置显式接受缺口。
        """
        self.stage = "attribution"
        residual = self.config.get("residual") or {}
        attribution = residual.get("attribution", "multi_signal")
        self.record["attribution"] = {
            "mode": attribution,
            "requirement": attribution_requirement_text(),
            "gap": residual_gap_text(),
            "accepted_gap": bool(residual.get("accepted_gap", False)),
            "euid": os.geteuid(),
            "implemented_modes": ["multi_signal"],
            "unimplemented_modes": ["uid_isolation", "container", "kernel_audit", "no_fork"],
        }
        if attribution == "uid_isolation":
            if os.geteuid() != 0:
                raise Reject(2, "attribution",
                             "配置要求按独立 uid 归属进程，但当前不是 root，无法建立该隔离",
                             {"euid": os.geteuid(), "requirement": attribution_requirement_text(),
                              "note": "uid 隔离只是候选实现之一，本版没有验证过它的效果。"})
            product_uid = residual.get("product_uid")
            if not isinstance(product_uid, int) or product_uid in (0, os.getuid()):
                raise Reject(2, "attribution",
                             "uid_isolation 需要 residual.product_uid 且不能是 0 或当前 uid",
                             {"product_uid": product_uid, "euid": os.geteuid()})
            raise Reject(2, "attribution",
                         "uid_isolation 只是候选实现，本版没有实现，也没有验证过",
                         {"requirement": attribution_requirement_text(),
                          "how_to": "要么先实现并验证一种归属边界；要么用 multi_signal 并"
                                    "显式接受缺口（结论只能是 ended_verified_limited，"
                                    "而它本身也不放行下一场）。"})
        if attribution == JOB_ATTRIBUTION:
            # 已验证过的“每场一个 launchd 作业 + 按联盟号归属”边界。
            # 外部启动程序在作业之外管理 bootstrap/bootout；产品仍由 sandbox-exec 套用与探针相同的 profile。
            self.record["attribution"] = {
                "mode": attribution,
                "boundary": "每场一个用户级 launchd 作业；作业内所有后代共享该作业的资源联盟号",
                "implemented_modes": ["multi_signal", JOB_ATTRIBUTION],
                "external_launcher": "dsh_gate.py（不在 launchd 作业里）",
                "tested_process": "sandbox-exec -f <readdeny.sb> <product/mock>（作业内，仍受读取限制）",
                "probe": "同一个 sandbox-exec 与同一份 profile；不是只检查外部启动器权限",
                "euid": os.geteuid(),
                "residual_gap": "联盟号覆盖作业内全部后代；若进程被移到别的作业，才不在本边界内（本版未验证跨作业搬移）",
            }
            self.note("attribution", mode=attribution,
                      boundary="launchd job coalition",
                      note="作业边界可整体归属；外部启动器与受测进程权限分开")
            return
        if attribution != "multi_signal":
            raise Reject(2, "attribution", "未知的进程归属方式", {"attribution": attribution})
        if not residual.get("accepted_gap", False):
            raise Reject(2, "attribution",
                         "多信号归属存在看不见的进程形态，配置未显式接受该缺口",
                         {"gap": residual_gap_text(),
                          "requirement": attribution_requirement_text(),
                          "how_to": "在配置 residual.accepted_gap 写明已接受该缺口；"
                                    "本程序不接受命令行开关。"})
        self.note("attribution", mode=attribution, accepted_gap=True,
                  note="多信号只能支撑 limited 状态，而 limited 不放行下一场")

    def build_profile(self):
        """生成外层 Seatbelt 策略：默认允许，显式拒绝受保护目录的读与写。"""
        self.stage = "confinement"
        cfg = self.config
        conf = cfg["confinement"]
        profile_path = os.path.join(self.run_dir, "readdeny.sb")
        self.profile_sha256 = build_readdeny_profile(
            cfg["protected_roots"], cfg["records_root"], profile_path,
            control_root=self.control_root)
        # 验收专用：只用于验证“外部探针可读时必须拒绝”。不是生产开关，也不改变其他检查。
        if os.environ.get("GATE_TEST_HOOK") == "allow_protected_probe_read":
            with open(profile_path, "a", encoding="utf-8") as handle:
                handle.write('(allow file-read* (literal %s))\n' % sbpl(cfg["protected_probe"]))
            self.profile_sha256 = sha256_file(profile_path)
            self.record["profile_test_hook"] = "allow_protected_probe_read"
        self.profile_path = profile_path
        self.record["confinement"] = {
            "kind": conf.get("kind"),
            "profile_path": profile_path,
            "profile_sha256": self.profile_sha256,
            "sandbox_exec": conf.get("sandbox_exec"),
            "protected_roots": cfg["protected_roots"],
            "records_root": cfg["records_root"],
            "control_root": self.control_root,
            "note": "外层策略只约束文件读写；产品的写入档位仍由 DSH 自己的沙箱决定。"
                    "运行登记目录也在拒绝读写的范围内。",
        }
        self.note("confinement", profile=self.profile_path, sha256=self.profile_sha256)

    def confined_argv(self, argv):
        conf = self.config["confinement"]
        if conf.get("kind") != "seatbelt":
            raise Reject(2, "confinement", "不支持的受限方式", {"kind": conf.get("kind")})
        sandbox_exec = conf.get("sandbox_exec", "/usr/bin/sandbox-exec")
        if not os.access(sandbox_exec, os.X_OK):
            raise Reject(2, "confinement", "找不到 sandbox-exec，无法建立读取限制",
                         {"path": sandbox_exec})
        return [sandbox_exec, "-f", self.profile_path] + list(argv)

    # ------------------------------------------------------------------ 权限检查
    def run_probe(self):
        self.stage = "permission-probe"
        cfg = self.config
        protected_probe = cfg["protected_probe"]
        # 外部探针必须真实存在且评测者能读；否则“读不到”可能只是路径不存在。
        if not os.path.isfile(protected_probe):
            raise Reject(2, "permission-probe", "受保护探针文件不存在，无法证明隔离",
                         {"path": protected_probe})
        try:
            with open(protected_probe, "rb") as handle:
                probe_bytes = handle.read()
        except OSError as exc:
            raise Reject(2, "permission-probe", "评测者自己也读不到受保护探针",
                         {"path": protected_probe, "error": str(exc)})
        protected_sha = sha256_bytes(probe_bytes)

        # 受保护探针必须位于某个受保护目录内，否则策略根本不会拒绝它。
        if not any(is_within(protected_probe, root) for root in cfg["protected_roots"]):
            raise Reject(2, "permission-probe", "受保护探针不在任何受保护目录内",
                         {"path": protected_probe, "protected_roots": cfg["protected_roots"]})

        # 探针脚本必须放在受测身份读得到的位置：它若落在受保护目录里，
        # 沙箱会连解释器读脚本这一步都拒掉，检查根本没跑起来（这会伪装成“拒绝”，但原因是错的）。
        probe_source = os.path.join(os.path.dirname(os.path.abspath(__file__)), "probe", "probe_read.py")
        probe_script = os.path.join(self.tool_dir, "probe_read.py")
        shutil.copyfile(probe_source, probe_script)
        os.chmod(probe_script, 0o644)
        probe_script_sha256 = sha256_file(probe_script)
        self.record["probe_script"] = {"source": probe_source,
                                       "copied_to": probe_script,
                                       "sha256": probe_script_sha256,
                                       "source_sha256": sha256_file(probe_source)}
        argv = [sys.executable, probe_script,
                "--workspace", self.workspace,
                "--workspace-probe", cfg["workspace_probe_name"],
                "--protected-probe", protected_probe,
                "--protected-root", os.path.dirname(protected_probe),
                "--config-sha256", self.config_sha256,
                "--profile-sha256", self.profile_sha256]
        wrapped = self.confined_argv(argv)
        started = time.monotonic()
        try:
            proc = subprocess.run(wrapped, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  timeout=cfg["timeouts"]["probe_seconds"],
                                  env=self.build_env(), cwd=self.workspace)
        except subprocess.TimeoutExpired:
            raise Reject(2, "permission-probe", "权限检查超时，结果未知",
                         {"seconds": cfg["timeouts"]["probe_seconds"]})
        elapsed = round(time.monotonic() - started, 2)
        stdout = proc.stdout.decode("utf-8", "replace").strip()
        stderr = proc.stderr.decode("utf-8", "replace").strip()

        payload = None
        for line in reversed(stdout.splitlines()):
            try:
                candidate = json.loads(line)
            except ValueError:
                continue
            if isinstance(candidate, dict) and candidate.get("kind") == PROBE_KIND:
                payload = candidate
                break
        if payload is None:
            raise Reject(2, "permission-probe", "权限检查没有产出可解析的结果",
                         {"exit_code": proc.returncode,
                          "stdout_head": stdout[:400], "stderr_head": stderr[:400]})

        verdict = evaluate_probe_result(payload, self.profile_sha256, self.ws_probe_sha256)
        self.record["permission_probe"] = {
            "protected_probe": protected_probe,
            "protected_probe_sha256": protected_sha,
            "protected_probe_bytes": len(probe_bytes),
            "elapsed_seconds": elapsed,
            "profile_sha256": self.profile_sha256,
            "exit_code": proc.returncode,
            "verdict": verdict,
            "raw": payload,
            "stderr_head": stderr[:400],
        }
        if not verdict["passed"]:
            raise Reject(2, "permission-probe", "读取权限检查未通过", verdict)
        self.note("permission-probe", passed=True, elapsed=elapsed,
                  entries=len(payload.get("results", [])))

    # ------------------------------------------------------------------ 提交
    def build_env(self):
        cfg = self.config
        env = {
            "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
            "HOME": self.product_home,
            "DSH_HOME": self.dsh_home,
            "TMPDIR": self.tmp_dir,
            "LANG": "en_US.UTF-8",
            "LC_ALL": "en_US.UTF-8",
            # 运行关联标记：模拟任务与真实产品都能读到，便于事后把进程、日志、记录对上号。
            "DSH_GATE_RUN_ID": self.run_id,
        }
        for key, value in cfg["product"].get("env", {}).items():
            env[key] = value
        return env

    def recheck_config_unchanged(self, at):
        """检查通过后，策略或配置被改动就不能继续提交。"""
        self.stage = "config-recheck"
        # 测试钩子：只允许把 profile 改坏，用来验证“旧检查失效后必须拒绝”。不能放宽任何检查。
        if os.environ.get("GATE_TEST_HOOK") == "mutate_profile_after_probe":
            with open(self.profile_path, "a", encoding="utf-8") as handle:
                handle.write(";; mutated by acceptance test hook\n")
        current_profile = sha256_file(self.profile_path)
        current_config = sha256_bytes(
            json.dumps(self.load_config_fresh(), ensure_ascii=False, sort_keys=True).encode("utf-8"))
        if current_profile != self.profile_sha256:
            raise Reject(2, "config-recheck", "受限策略在检查后发生变化，旧检查不再有效",
                         {"at": at, "expected_sha256": self.profile_sha256,
                          "actual_sha256": current_profile})
        if current_config != self.config_sha256:
            raise Reject(2, "config-recheck", "配置文件在检查后发生变化，旧检查不再有效",
                         {"at": at, "expected_sha256": self.config_sha256,
                          "actual_sha256": current_config})
        self.note("config-recheck", ok=True, at=at)

    def load_config_fresh(self):
        cfg = read_json(self.config_path)
        cfg["run_root"] = os.path.realpath(os.path.expanduser(cfg["run_root"]))
        cfg["records_root"] = os.path.realpath(os.path.expanduser(cfg["records_root"]))
        cfg["protected_roots"] = [os.path.realpath(os.path.expanduser(p)) for p in cfg["protected_roots"]]
        cfg["protected_probe"] = os.path.realpath(os.path.expanduser(cfg["protected_probe"]))
        cfg["inputs"]["source_dir"] = os.path.realpath(os.path.expanduser(cfg["inputs"]["source_dir"]))
        cfg["inputs"]["manifest"] = os.path.realpath(os.path.expanduser(cfg["inputs"]["manifest"]))
        return cfg

    def submit(self):
        self.stage = "submit"
        cfg = self.config
        if (cfg.get("residual") or {}).get("attribution") == JOB_ATTRIBUTION:
            return self.submit_job()
        product = cfg["product"]
        if self.product_kind == "real":
            argv = list(product["command"]) + list(product["args"]) + ["-"]
        else:
            argv = (list(cfg["mock"]["command"]) + list(cfg["mock"].get("args", []))
                    + list(self.mock_extra) + ["-"])
        wrapped = self.confined_argv(argv)

        prompt_bytes = b""
        if self.prompt_path:
            with open(self.prompt_path, "rb") as handle:
                prompt_bytes = handle.read()
        self.prompt_sha256 = sha256_bytes(prompt_bytes) if prompt_bytes else None

        # 提交前最后一刻再确认一次策略没变。
        if sha256_file(self.profile_path) != self.profile_sha256:
            raise Reject(2, "submit", "提交前发现策略文件已变化", {})

        self.record["product"] = {
            "kind": self.product_kind,
            "argv": argv,
            "wrapped_argv": wrapped,
            "prompt_path": self.prompt_path,
            "prompt_sha256": self.prompt_sha256,
            "prompt_bytes": len(prompt_bytes),
            "env_keys": sorted(self.build_env().keys()),
        }
        self.record["status"] = ST_SUBMITTING
        self.record["product_pid"] = None
        self.write_run_record()

        # 输出文件先落在产品可写的位置，结束后再复制进运行记录目录：
        # 直接把 fds 指向受保护目录时，沙箱可能连 stderr 都写不进去，失败原因会丢失。
        stdout_path = os.path.join(self.tmp_dir, "product.stdout.jsonl")
        stderr_path = os.path.join(self.tmp_dir, "product.stderr.log")
        out = open(stdout_path, "wb")
        err = open(stderr_path, "wb")
        started = time.monotonic()
        try:
            self.child = subprocess.Popen(
                wrapped,
                stdin=subprocess.PIPE if prompt_bytes else subprocess.DEVNULL,
                stdout=out,
                stderr=err,
                cwd=self.workspace,
                env=self.build_env(),
                start_new_session=True,  # 独立进程组，便于判断残留
            )
        except OSError as exc:
            out.close()
            err.close()
            raise Reject(5, "submit", "产品进程启动失败", {"error": str(exc)})

        self.child_pgid = os.getpgid(self.child.pid)
        # 采样必须在产品一启动就开始：脱离进程组的动作可能发生在毫秒级。
        self.monitor = ProcessMonitor(self.child.pid)
        self.monitor.start()
        self.record["status"] = ST_RUNNING
        self.record["product_pid"] = self.child.pid
        self.record["product_pgid"] = self.child_pgid
        self.record["submitted_at"] = now_iso()
        self.record["submissions"] = self.record.get("submissions", 0) + 1
        self.write_run_record()
        self.note("submit", pid=self.child.pid, pgid=self.child_pgid, submissions=self.record["submissions"])

        if prompt_bytes:
            try:
                self.child.stdin.write(prompt_bytes)
                self.child.stdin.close()
            except OSError:
                pass

        timeout_s = cfg["timeouts"]["submit_seconds"]
        timed_out = False
        try:
            exit_code = self.child.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            timed_out = True
            exit_code = None
            self.stop_process_group()
        elapsed = round(time.monotonic() - started, 2)
        out.close()
        err.close()
        monitor = self.monitor.stop() if self.monitor else None
        self.record["process_monitor"] = monitor

        self.record["exit_code"] = exit_code
        self.record["timed_out"] = timed_out
        self.record["duration_seconds"] = elapsed
        self.record["ended_at"] = now_iso()
        self.record["stdout_path"] = stdout_path
        self.record["stderr_path"] = stderr_path
        for path in (stdout_path, stderr_path):
            try:
                shutil.copyfile(path, os.path.join(self.run_dir, os.path.basename(path)))
            except OSError:
                pass
        self.note("submit-finished", exit_code=exit_code, seconds=elapsed, timed_out=timed_out)
        return exit_code, timed_out

    def submit_job(self):
        """launchd 作业模式：外部启动程序建作业，作业内产品仍套 sandbox-exec。

        作业交换区放在 run_root（launchd 可读写），脚本/plist/profile/ready/exit 都在那里；
        记录目录（records_root）仍由评测侧持有，只用于归档。这样 launchd 不会被
        ~/Documents 的 TCC 拦住读 job_entry.py，同时产品的读取限制不变。
        """
        cfg = self.config
        product = cfg["product"]
        if self.product_kind == "real":
            argv = list(product["command"]) + list(product["args"]) + ["-"]
        else:
            argv = (list(cfg["mock"]["command"]) + list(cfg["mock"].get("args", []))
                    + list(self.mock_extra) + ["-"])

        prompt_bytes = b""
        if self.prompt_path:
            with open(self.prompt_path, "rb") as handle:
                prompt_bytes = handle.read()
        self.prompt_sha256 = sha256_bytes(prompt_bytes) if prompt_bytes else None

        if sha256_file(self.profile_path) != self.profile_sha256:
            raise Reject(2, "submit", "提交前发现策略文件已变化", {})

        label = JR.label_for(self.run_id)
        state = JR.label_state(label)
        if state["state"] != JR.LABEL_ABSENT:
            raise Reject(2, "submit", "作业标签已存在或状态未知，拒绝复用",
                         {"label": label, "state": state["state"], "rc": state["rc"]})

        job_dir = os.path.join(self.home_root, "job")
        os.makedirs(job_dir, exist_ok=True)
        job_entry_copy = os.path.join(job_dir, "job_entry.py")
        probe_proc_copy = os.path.join(job_dir, "probe_proc.py")
        shutil.copyfile(JOB_ENTRY, job_entry_copy)
        shutil.copyfile(os.path.join(HERE, "probe_proc.py"), probe_proc_copy)
        job_profile = os.path.join(job_dir, "readdeny.sb")
        shutil.copyfile(self.profile_path, job_profile)
        profile_job_sha = sha256_file(job_profile)
        if profile_job_sha != self.profile_sha256:
            raise Reject(2, "submit", "作业区 profile 副本与检查时不一致", {})
        sandbox_exec = cfg["confinement"].get("sandbox_exec", "/usr/bin/sandbox-exec")
        wrapped = [sandbox_exec, "-f", job_profile] + argv

        prompt_path = os.path.join(job_dir, "prompt.bin")
        if prompt_bytes:
            with open(prompt_path, "wb") as handle:
                handle.write(prompt_bytes)
        stdout_path = os.path.join(job_dir, "product.stdout.jsonl")
        stderr_path = os.path.join(job_dir, "product.stderr.log")
        job_stdout = os.path.join(job_dir, "job.stdout.log")
        job_stderr = os.path.join(job_dir, "job.stderr.log")
        plist_path = os.path.join(job_dir, "job.plist")
        job_py = "/usr/bin/python3" if os.path.exists("/usr/bin/python3") else sys.executable
        program = [job_py, job_entry_copy,
                   "--run-dir", job_dir,
                   "--stdout", stdout_path,
                   "--stderr", stderr_path,
                   "--prompt", prompt_path if prompt_bytes else "",
                   "--cwd", self.workspace,
                   "--"] + wrapped
        env = self.build_env()
        env["DSH_GATE_RUN_ID"] = self.run_id
        plist_info = JR.write_plist(plist_path, label, program, job_stdout, job_stderr, env)

        self.record["product"] = {
            "kind": self.product_kind, "argv": argv, "wrapped_argv": wrapped,
            "prompt_path": self.prompt_path, "prompt_sha256": self.prompt_sha256,
            "prompt_bytes": len(prompt_bytes), "env_keys": sorted(env.keys()),
            "process_structure": "dsh_gate.py (external launcher) -> launchd job -> job_entry.py -> sandbox-exec -> product",
        }
        self.record["job"] = {"label": label, "job_dir": job_dir, "plist_path": plist_path,
                              "plist": plist_info, "program_arguments": program,
                              "job_entry_copy": job_entry_copy,
                              "probe_proc_copy": probe_proc_copy,
                              "profile_job_path": job_profile,
                              "profile_job_sha256": profile_job_sha,
                              "job_python": job_py,
                              "stdout_path": stdout_path, "stderr_path": stderr_path,
                              "job_stdout": job_stdout, "job_stderr": job_stderr,
                              "bootstrap": None, "ready": None, "coalition": None}
        self.record["status"] = ST_SUBMITTING
        self.record["product_pid"] = None
        self.record["product_pgid"] = None
        self.write_run_record()

        boot = JR.bootstrap(plist_path)
        self.record["job"]["bootstrap"] = boot
        self.write_run_record()
        if boot["rc"] != 0:
            raise Reject(5, "submit", "launchd bootstrap 失败，产品未提交",
                         {"label": label, "bootstrap": boot})

        ready_path = os.path.join(job_dir, "job.ready.json")
        ok, waited = JR.wait_file(ready_path, 30)
        if not ok:
            JR.bootout(label)
            raise Reject(5, "submit", "作业启动后 30s 内没有写 job.ready.json，作业边界未知",
                         {"label": label, "waited_s": waited,
                          "job_stderr": self._read_head(job_stderr)})
        ready = JR.jread(ready_path, {}) or {}
        coalition = (ready.get("coalition") or {}).get("key")
        self.record["job"]["ready"] = ready
        self.record["job"]["coalition"] = coalition
        self.record["job"]["ready_waited_s"] = waited
        self.job_label = label
        self.job_coalition = coalition
        self.record["status"] = ST_RUNNING
        self.record["product_pid"] = (ready.get("ident") or {}).get("pid")
        self.record["submitted_at"] = now_iso()
        self.record["submissions"] = self.record.get("submissions", 0) + 1
        self.write_run_record()
        self.note("submit", mode="launchd_coalition", label=label,
                  job_pid=self.record["product_pid"], coalition=coalition,
                  submissions=self.record["submissions"])

        timeout_s = cfg["timeouts"]["submit_seconds"]
        exit_path = os.path.join(job_dir, "job.exit.json")
        started = time.monotonic()
        ok_exit, waited_exit = JR.wait_file(exit_path, timeout_s, interval=0.2)
        elapsed = round(time.monotonic() - started, 2)
        timed_out = not ok_exit
        exit_doc = JR.jread(exit_path, {}) or {}
        exit_code = exit_doc.get("rc") if ok_exit else None
        self.record["job"]["exit"] = exit_doc
        self.record["job"]["exit_waited_s"] = waited_exit
        self.record["job"]["exit_exists"] = ok_exit
        if timed_out:
            cleanup = JR.kill_members(coalition)
            self.record["job"]["timeout_cleanup"] = cleanup
        bootout = JR.bootout(label)
        self.record["job"]["bootout"] = bootout
        self.record["job"]["label_state_after"] = JR.label_state(label)["state"]

        for src, name in ((stdout_path, "product.stdout.jsonl"), (stderr_path, "product.stderr.log"),
                          (job_stdout, "job.stdout.log"), (job_stderr, "job.stderr.log"),
                          (ready_path, "job.ready.json"),
                          (os.path.join(job_dir, "job.product.json"), "job.product.json"),
                          (exit_path, "job.exit.json"), (plist_path, "job.plist"),
                          (job_profile, "readdeny.job.sb")):
            try:
                shutil.copyfile(src, os.path.join(self.run_dir, name))
            except OSError:
                pass
        product_doc = JR.jread(os.path.join(job_dir, "job.product.json"), {}) or {}
        self.record["job"]["product"] = product_doc
        self.record["product_pid"] = product_doc.get("product_pid") or self.record.get("product_pid")
        self.record["exit_code"] = exit_code
        self.record["timed_out"] = timed_out
        self.record["duration_seconds"] = elapsed
        self.record["ended_at"] = now_iso()
        self.write_run_record()
        self.note("submit-finished", mode="launchd_coalition", exit_code=exit_code,
                  seconds=elapsed, timed_out=timed_out)
        return exit_code, timed_out

    @staticmethod
    def _read_head(path, limit=2000):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                return handle.read()[-limit:]
        except OSError:
            return ""

    def stop_process_group(self):
        """超时后尽力停住产品及其子进程；停不住就留给结束校验按“未确认”处理。

        killpg 在受限环境里可能返回 EPERM（信号本身被拦），所以不能只依赖它：
        失败时退回到逐个进程发信号，并把失败原因写进记录，避免“以为杀了其实没杀”。
        """
        if not self.child_pgid:
            return
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(self.child_pgid, sig)
            except ProcessLookupError:
                return
            except OSError as exc:
                self.record.setdefault("stop_errors", []).append(
                    {"stage": "killpg", "pgid": self.child_pgid,
                     "signal": int(sig), "error": str(exc)})
            survivors = self.find_survivors()
            if survivors is None:
                return  # 无法枚举就无法确认，交给结束校验
            if not survivors:
                return
            for item in survivors:
                try:
                    os.kill(item["pid"], sig)
                except OSError:
                    pass
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if not self.group_alive():
                    return
                time.sleep(0.2)
        # 走到这里说明没有停下来，交给结束校验按“未确认”处理。

    def group_alive(self):
        survivors = self.find_survivors()
        if survivors is None:
            return True  # 查不出来就按“还活着”处理，宁可停住
        return bool(survivors)

    def find_survivors(self, pgid=None, run_id=None, pid=None):
        """查找属于指定运行、且此刻仍在运行的进程。

        单个信号都不够：
          - 只按进程组，子进程 setsid 就脱离；
          - 只按命令行，命令行里可以不含路径；
          - 只按采样，采不到的瞬间它就跑了。
        所以这里同时用五个信号，任意一个命中就算残留：
          pgid 相同 / 会话 id 相同 / 命令行含运行目录或运行 ID /
          在运行目录下持有工作目录或打开的文件（lsof） / 采样期间见过且此刻仍活着。
        仍然看不全的形态写在 residual_gap_text() 里，并且不许把结论写成“已确认”。

        返回 None 表示无法判断（ps 不可用），调用方必须按“未确认”处理。
        """
        pgid = self.child_pgid if pgid is None else pgid
        run_id = self.run_id if run_id is None else run_id
        root_pid = self.child.pid if (pid is None and self.child is not None) else pid
        rows = self.ps_table()
        if rows is None:
            return None

        markers = [m for m in (run_id,
                               self.record.get("workspace", {}).get("path"),
                               self.config["run_root"] if getattr(self, "config", None) else None,
                               getattr(self, "dsh_home", None)) if m]
        ancestors = self.ancestors()
        interested = set()
        if self.monitor is not None:
            interested = set(self.monitor.seen.keys())

        by_pid = {row["pid"]: row for row in rows}
        mode = rows[0].get("source", "ps") if rows else "ps"
        self.last_scan_mode = mode
        if hasattr(self, "_holders_cache"):
            del self._holders_cache          # 每次扫描重新取，别用上一次的结果
        holders = self.run_root_holders()
        survivors = []
        for row in rows:
            pid_i = row["pid"]
            if pid_i == os.getpid() or pid_i in ancestors:
                continue
            why = None
            if pgid is not None and row["pgid"] == pgid:
                why = "same_process_group"
            elif (self.monitor is not None and self.monitor.session_id
                  and row.get("sess") == self.monitor.session_id):
                why = "same_session"
            elif pid_i == root_pid:
                why = "product_pid"
            elif mode == "ps" and any(marker and marker in row["command"] for marker in markers):
                why = "run_marker_in_command"
            elif pid_i in interested:
                why = "seen_as_descendant"
            elif holders and pid_i in holders:
                why = "holds_run_root"
            if why:
                survivors.append({"pid": pid_i, "why": why, "pgid": row["pgid"],
                                  "command": row["command"][:300], "scan": mode})
        return survivors

    def ancestors(self):
        """本进程的祖先进程，避免把“启动程序的调用者”误判成产品残留。"""
        result = set()
        table = {row["pid"]: row for row in (self.ps_table() or [])}
        pid = os.getpid()
        while pid and pid in table:
            pid = table[pid]["ppid"]
            if not pid or pid <= 0:
                break
            result.add(pid)
        return result

    def holds_run_root(self, pid):
        """兼容单 pid 查询。批量场景请用 run_root_holders()，不要逐个 pid 调。"""
        holders = self.run_root_holders()
        if holders is None:
            return False
        return pid in holders

    def run_root_holders(self):
        """一次列出所有在运行根目录下持有 cwd 或打开文件的进程。

        逐个 pid 调 `lsof +D` 会把运行目录遍历 N 遍（N = 系统进程数），
        实测会拖到几十秒；这里改成一次遍历，再按 pid 归属。
        """
        if hasattr(self, "_holders_cache"):
            return self._holders_cache
        run_root = self.config.get("run_root") if getattr(self, "config", None) else None
        if not run_root or not os.path.isdir(run_root):
            self._holders_cache = None
            return None
        lsof = "/usr/sbin/lsof" if os.path.exists("/usr/sbin/lsof") else shutil.which("lsof")
        if not lsof:
            self.lsof_available = False
            self._holders_cache = None
            return None
        try:
            proc = subprocess.run([lsof, "-n", "-P", "-w", "+D", run_root],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  timeout=60)
        except (OSError, subprocess.SubprocessError):
            self.lsof_available = False
            self._holders_cache = None
            return None
        self.lsof_available = True
        holders = set()
        for line in proc.stdout.decode("utf-8", "replace").splitlines()[1:]:
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                holders.add(int(parts[1]))
            except ValueError:
                continue
        self._holders_cache = holders
        return holders

    @staticmethod
    def ps_table():
        """进程表。优先用 /bin/ps；执行被拒时退回 libproc，而不是直接认输。

        为什么要退回：有些受限环境（例如已经套了一层沙箱的终端）不允许执行 `ps`，
        这时如果直接返回 None，结束校验只能一律判“无法确认”，检查就退化成永久阻塞。
        libproc（proc_listpids / proc_pidinfo）是系统调用，不经过 exec，能拿到
        pid/ppid/pgid 与 16 字符的进程名；但拿不到完整命令行和会话 id，
        所以退回模式下这两路信号会被跳过，并在结果里标明 scan_mode=libproc。
        """
        rows = Gate._ps_via_binary()
        if rows is not None:
            return rows
        return Gate._ps_via_libproc()

    @staticmethod
    def _ps_via_binary():
        try:
            proc = subprocess.run(["/bin/ps", "-axo", "pid=,ppid=,pgid=,sess=,command="],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30)
        except (OSError, subprocess.SubprocessError):
            return None
        if proc.returncode != 0:
            return None
        rows = []
        for line in proc.stdout.decode("utf-8", "replace").splitlines():
            parts = line.split(None, 4)
            if len(parts) < 5:
                continue
            try:
                pid, ppid, pgid, sess = (int(parts[0]), int(parts[1]),
                                         int(parts[2]), int(parts[3]))
            except ValueError:
                continue
            rows.append({"pid": pid, "ppid": ppid, "pgid": pgid, "sess": sess,
                         "command": parts[4], "source": "ps"})
        return rows or None

    @staticmethod
    def _ps_via_libproc():
        try:
            import ctypes
            lib = ctypes.CDLL("/usr/lib/libproc.dylib")
            lib.proc_listpids.restype = ctypes.c_int
            size = lib.proc_listpids(1, 0, None, 0)   # PROC_ALL_PIDS
            if size <= 0:
                return None
            buffer = (ctypes.c_int * (size // 4))()
            size = lib.proc_listpids(1, 0, buffer, size)
            if size <= 0:
                return None

            class BsdInfo(ctypes.Structure):
                _fields_ = [
                    ("pbi_flags", ctypes.c_uint32), ("pbi_status", ctypes.c_uint32),
                    ("pbi_xstatus", ctypes.c_uint32), ("pbi_pid", ctypes.c_uint32),
                    ("pbi_ppid", ctypes.c_uint32), ("pbi_uid", ctypes.c_uint32),
                    ("pbi_gid", ctypes.c_uint32), ("pbi_ruid", ctypes.c_uint32),
                    ("pbi_rgid", ctypes.c_uint32), ("pbi_svuid", ctypes.c_uint32),
                    ("pbi_svgid", ctypes.c_uint32), ("rfu_1", ctypes.c_uint32),
                    ("pbi_comm", ctypes.c_char * 16), ("pbi_name", ctypes.c_char * 32),
                    ("pbi_nfiles", ctypes.c_uint32), ("pbi_pgid", ctypes.c_uint32),
                    ("pbi_pjobc", ctypes.c_uint32), ("e_tdev", ctypes.c_uint32),
                    ("e_tpgid", ctypes.c_uint32), ("pbi_nice", ctypes.c_int32),
                    ("pbi_start_tvsec", ctypes.c_uint64),
                    ("pbi_start_tvusec", ctypes.c_uint64),
                ]

            rows = []
            for index in range(size // 4):
                pid = buffer[index]
                if pid <= 0:
                    continue
                info = BsdInfo()
                got = lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info),
                                       ctypes.sizeof(info))   # PROC_PIDTBSDINFO
                if not got:
                    continue
                rows.append({"pid": int(info.pbi_pid), "ppid": int(info.pbi_ppid),
                             "pgid": int(info.pbi_pgid), "sess": None,
                             "command": info.pbi_comm.decode("utf-8", "replace"),
                             "source": "libproc"})
            return rows or None
        except Exception:  # noqa: BLE001  没有 libproc 就是真的查不了
            return None

    # ------------------------------------------------------------------ 结束校验
    def verify_end(self, exit_code, timed_out):
        self.stage = "verify-end"
        if (self.config.get("residual") or {}).get("attribution") == JOB_ATTRIBUTION:
            return self.verify_end_job(exit_code, timed_out)
        first = self.find_survivors()
        # 退场后立刻再扫一次：有的子进程要过几十毫秒才被重新挂到 launchd 下。
        grace = float(self.config.get("timeouts", {}).get("residual_grace_seconds", 2.0))
        time.sleep(grace)
        survivors = self.find_survivors()
        session = self.read_session_record()
        audit = self.audit_tool_calls(session)
        residual = self.config.get("residual") or {}
        attribution = residual.get("attribution", "multi_signal")
        scan_mode = getattr(self, "last_scan_mode", None)
        lsof_ok = bool(getattr(self, "lsof_available", False))
        capabilities = {
            "ps_command_line": scan_mode == "ps",
            "ps_session_id": scan_mode == "ps",
            "lsof_run_root": lsof_ok,
            "descendant_sampling": self.record.get("process_monitor") is not None,
            "scan_mode": scan_mode,
            "adequate": (scan_mode == "ps") or lsof_ok,
        }
        checks = {
            "exit_code": exit_code,
            "timed_out": timed_out,
            "survivors_first_scan": first,
            "survivors": survivors,
            "survivor_check_available": survivors is not None,
            "scan_capabilities": capabilities,
            "grace_seconds": grace,
            "session": session,
            "tool_audit": audit,
            "attribution": attribution,
            "residual_gap": residual_gap_text(),
        }
        self.record["end_verification"] = checks

        if survivors is None:
            raise Reject(6, "verify-end", "无法枚举进程，无法确认任务及相关后台操作已停止", checks)
        if not capabilities["adequate"]:
            # 只有进程组信号可用时，脱离进程组就等于消失。这种扫描不足以支撑结论。
            raise Reject(6, "verify-end",
                         "进程扫描能力不足（既没有完整 ps，也不能用 lsof 查运行目录），"
                         "无法确认相关后台操作已停止", {"scan_capabilities": capabilities})
        if survivors:
            raise Reject(6, "verify-end", "提交已返回但仍有进程存活，任务未真正结束",
                         {"survivors": survivors})
        if session.get("state") != "found":
            raise Reject(6, "verify-end", "找不到本次会话日志，无法确认轮次结束",
                         {"session": session})
        if not session.get("turn_end"):
            raise Reject(6, "verify-end", "会话日志没有 turn/end 记录", {"session": session})
        if session.get("cwd_realpath") != os.path.realpath(self.workspace):
            raise Reject(6, "verify-end", "会话记录的工作目录与本次工作区不一致",
                         {"session_cwd": session.get("cwd"), "workspace": self.workspace})
        expected_mode = self.config.get("expected", {}).get("sandbox_mode")
        if expected_mode and session.get("sandbox_mode") != expected_mode:
            raise Reject(6, "verify-end", "实际沙箱档位与预期不一致",
                         {"expected": expected_mode, "actual": session.get("sandbox_mode")})
        if audit["unbalanced"]:
            # 有调用没有结果，说明产品被打断在工具执行中：工具可能还在跑，
            # 它可能已经 setsid 走了，靠进程扫描证明不了“没了”。
            raise Reject(6, "verify-end",
                         "会话日志里存在没有结果的工具调用，无法确认相关操作已停止",
                         {"unbalanced": audit["unbalanced"], "tool_audit": audit})

        if timed_out:
            self.record["status"] = ST_ENDED_FORCED
            self.note("verify-end", status=ST_ENDED_FORCED, reason="超时后已强制停止并确认无残留")
        else:
            # 只有多信号扫描可用，就不能声称“所有后代都在边界内已停止”。
            # 于是本版所有跑完的运行都记 limited；而 limited 会挡住下一场。
            # 这一版**没有**解除途径：人工旁证不放行（见 evaluate_previous_run），
            # 因为旁证用的还是这套扫描。这是已知阻塞，出路是方案 A，不是加字段。
            self.record["status"] = ST_ENDED_LIMITED
            self.note("verify-end", status=ST_ENDED_LIMITED,
                      reason="进程归属为多信号扫描，没有可整体归属的边界",
                      spawning_tools=audit["spawning_tools"],
                      blocks_next_run=True)

        # 这里原本有一段「链上限」：本场若是被人工恢复凭据放行进来的，就压到 limited。
        # 凭据本身已经被判定不构成放行依据（见 evaluate_previous_run），这一段随之作废：
        # 现在任何一场的上一场只要没确认结束，本场根本开不起来，不存在「带着未知起跑」。
        self.note("verify-end", status=self.record["status"])

    def verify_end_job(self, exit_code, timed_out):
        """作业模式的结束校验：退出证据 + 联盟号无活进程 + 会话 turn/end 三者一致。"""
        job = self.record.get("job") or {}
        coalition = job.get("coalition")
        first = JR.members(coalition)
        grace = float(self.config.get("timeouts", {}).get("residual_grace_seconds", 2.0))
        time.sleep(grace)
        survivors = JR.members(coalition)
        session = self.read_session_record()
        audit = self.audit_tool_calls(session)
        checks = {
            "exit_code": exit_code,
            "timed_out": timed_out,
            "job_exit_exists": bool(job.get("exit_exists")),
            "job_exit": job.get("exit"),
            "coalition": coalition,
            "survivors_first_scan": first,
            "survivors": survivors,
            "session": session,
            "tool_audit": audit,
            "attribution": JOB_ATTRIBUTION,
            "grace_seconds": grace,
        }
        self.record["end_verification"] = checks
        if survivors is None:
            raise Reject(6, "verify-end", "无法枚举作业联盟号，无法确认任务及后台操作已停止", checks)
        if survivors:
            raise Reject(6, "verify-end", "提交已返回但作业联盟号里仍有进程存活，任务未真正结束",
                         {"survivors": survivors, "coalition": coalition})
        if not job.get("exit_exists"):
            raise Reject(6, "verify-end", "没有 job.exit.json，无法确认作业主进程结束", checks)
        if session.get("state") != "found":
            raise Reject(6, "verify-end", "找不到本次会话日志，无法确认轮次结束", {"session": session})
        if not session.get("turn_end"):
            raise Reject(6, "verify-end", "会话日志没有 turn/end 记录", {"session": session})
        if session.get("cwd_realpath") != os.path.realpath(self.workspace):
            raise Reject(6, "verify-end", "会话记录的工作目录与本次工作区不一致",
                         {"session_cwd": session.get("cwd"), "workspace": self.workspace})
        expected_mode = self.config.get("expected", {}).get("sandbox_mode")
        if expected_mode and session.get("sandbox_mode") != expected_mode:
            raise Reject(6, "verify-end", "实际沙箱档位与预期不一致",
                         {"expected": expected_mode, "actual": session.get("sandbox_mode")})
        if audit["unbalanced"]:
            raise Reject(6, "verify-end", "会话日志里存在没有结果的工具调用，无法确认相关操作已停止",
                         {"unbalanced": audit["unbalanced"], "tool_audit": audit})

        kind = "forced_stop" if timed_out else "normal_exit"
        end_doc = JR.write_end_evidence(
            os.path.join(self.control_run_dir, "end.json"), kind, coalition, survivors,
            {"job": job, "session": session, "tool_audit": audit})
        JR.jwrite(os.path.join(self.run_dir, "end.json"), end_doc)
        self.record["job_end_evidence"] = end_doc
        self.record["status"] = ST_ENDED_FORCED if timed_out else ST_ENDED_VERIFIED
        self.write_run_record()
        self.note("verify-end", status=self.record["status"], coalition=coalition,
                  survivors=0, kind=kind)

    @staticmethod
    def audit_tool_calls(session):
        """核对工具调用与结果是否配平，并列出会派生进程的工具。"""
        audit = {"calls": 0, "results": 0, "unbalanced": [], "spawning_tools": [],
                 "names": []}
        if not session or session.get("state") != "found":
            return audit
        calls = session.get("tool_calls") or []
        results = session.get("tool_results") or []
        audit["calls"] = len(calls)
        audit["results"] = len(results)
        result_ids = {item.get("callId") for item in results}
        for item in calls:
            if item.get("callId") not in result_ids:
                audit["unbalanced"].append(item)
        names = []
        for item in calls:
            name = str(item.get("name") or "")
            if name:
                names.append(name)
                lowered = name.lower()
                if any(token in lowered for token in PROCESS_SPAWNING_TOOLS):
                    audit["spawning_tools"].append(name)
        audit["names"] = names
        return audit


    def read_session_record(self):
        """从本次专用 DSH_HOME 里按会话 ID 找日志，读 turn/end 与实际权限档位。"""
        sessions_root = os.path.join(self.dsh_home, "sessions")
        if not os.path.isdir(sessions_root):
            return {"state": "missing_sessions_root", "root": sessions_root}
        session_id = self.parse_session_id()
        candidates = []
        for dirpath, _dirnames, filenames in os.walk(sessions_root):
            if os.path.basename(dirpath).startswith("session-"):
                candidates.append(dirpath)
        target = None
        if session_id:
            for path in candidates:
                if os.path.basename(path) == session_id or session_id in os.path.basename(path):
                    target = path
                    break
        if target is None and len(candidates) == 1:
            target = candidates[0]
        if target is None:
            return {"state": "not_found", "session_id": session_id,
                    "candidates": [os.path.basename(p) for p in candidates]}
        log_path = os.path.join(target, "session.v4.jsonl.zstd")
        if not os.path.isfile(log_path):
            return {"state": "log_missing", "session_dir": target}
        text = self.decompress(log_path)
        if text is None:
            return {"state": "decompress_failed", "log": log_path}
        info = {"state": "found", "session_dir": target, "log": log_path,
                "turn_end": None, "cwd": None, "sandbox_mode": None,
                "approval_policy": None, "agent_preset": None,
                "turn_start_count": 0, "event_count": 0,
                "tool_calls": [], "tool_results": [], "used_tools": []}
        for line in text.splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            info["event_count"] += 1
            kind = event.get("type")
            if kind == "session":
                info["cwd"] = event.get("cwd")
                info["agent_preset"] = event.get("agentPreset")
                info["session_id"] = event.get("id")
            elif kind == "turn/start":
                info["turn_start_count"] += 1
            elif kind == "turn/end":
                info["turn_end"] = event.get("data", {}).get("reason")
            elif kind == "sandbox/mode":
                info["sandbox_mode"] = event.get("data", {}).get("mode")
            elif kind == "approval/policy":
                info["approval_policy"] = event.get("data", {}).get("policy")
            elif kind == "tool/call":
                data = event.get("data") or {}
                info["tool_calls"].append({"callId": data.get("callId"),
                                           "name": data.get("name")})
                info["used_tools"].append(data.get("name"))
            elif kind == "tool/result":
                data = event.get("data") or {}
                message = data.get("message") or {}
                info["tool_results"].append({"callId": data.get("callId") or message.get("toolCallId")})
        if info["cwd"]:
            info["cwd_realpath"] = os.path.realpath(info["cwd"])
        return info

    def parse_session_id(self):
        path = os.path.join(self.run_dir, "product.stdout.jsonl")
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if event.get("type") == "session" and event.get("id"):
                    return event["id"]
        return None

    def decompress(self, path):
        zstd = self.config["confinement"].get("zstd") or shutil.which("zstd")
        if not zstd or not os.access(zstd, os.X_OK):
            return None
        try:
            proc = subprocess.run([zstd, "-dc", path], stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL, timeout=120)
        except (OSError, subprocess.SubprocessError):
            return None
        if proc.returncode != 0:
            return None
        return proc.stdout.decode("utf-8", "replace")

    # ------------------------------------------------------------------ 收集与清理
    def collect_and_cleanup(self):
        self.stage = "collect"
        run_dir = self.run_dir
        archive = {
            "workspace_from": self.workspace,
        }
        try:
            ws_dst = os.path.join(run_dir, "workspace-archive")
            shutil.move(self.workspace, ws_dst)
            archive["workspace_to"] = ws_dst
            archive["workspace_tree"] = tree_manifest(ws_dst)
        except OSError as exc:
            archive["workspace_error"] = str(exc)

        try:
            home_dst = os.path.join(run_dir, "runtime-home-archive")
            shutil.move(self.home_root, home_dst)
            archive["dsh_home_from"] = os.path.join(home_dst, "dsh")
            archive["dsh_home_to"] = archive["dsh_home_from"]
            archive["dsh_home_tree"] = tree_manifest(archive["dsh_home_from"])
        except OSError as exc:
            archive["dsh_home_error"] = str(exc)

        self.record["archive"] = archive
        self.note("collect", workspace_archived="workspace_to" in archive,
                  dsh_home_archived="dsh_home_to" in archive)

    def write_run_record(self):
        self.record["updated_at"] = now_iso()
        self.record["stage"] = self.stage
        if getattr(self, "run_dir", None):
            path = os.path.join(self.run_dir, "run.json")
            write_json(path, self.record)
        self.write_control_status()
        return getattr(self, "run_dir", None)

    def write_ten_fields(self, verdict):
        """项目要求的十项运行信息。不能核实的字段如实写未知，并说明影响与停止条件。"""
        cfg = self.config
        meta = cfg.get("meta", {})
        session = self.record.get("end_verification", {}).get("session") or {}
        fields = {
            "唯一ID": self.run_id,
            "题目版本": meta.get("task_version", "未知"),
            "产品版本": product_version(cfg),
            "模型": meta.get("model", "未知"),
            "工具": meta.get("tools", "未知"),
            "权限": {
                "读取限制": "外层 Seatbelt 拒绝受保护目录、运行记录与运行登记目录的读写",
                "写入档位": session.get("sandbox_mode") or "未知",
                "审批策略": session.get("approval_policy") or "未知",
                "执行身份": "uid=%d" % os.getuid(),
                "检查范围": "进程内探针（普通 Python／shell／grep 入口），"
                            "不是 DSH 自己的 fs／bash 工具入口",
                "进程归属": (cfg.get("residual") or {}).get("attribution", "multi_signal"),
            },
            "技能状态": meta.get("skills", "未知"),
            "运行时间": {
                "started_at": self.record.get("started_at"),
                "submitted_at": self.record.get("submitted_at"),
                "ended_at": self.record.get("ended_at"),
                "duration_seconds": self.record.get("duration_seconds"),
            },
            "证据等级": meta.get("evidence_level", "E2"),
            "最终裁定": verdict,
        }
        unknowns = meta.get("unknowns", [])
        limits = self.known_limits()
        self.record["ten_fields"] = {"fields": fields, "unknowns": unknowns,
                                     "known_limits": limits}
        write_json(os.path.join(self.run_dir, "run-ten-fields.json"),
                   {"fields": fields, "unknowns": unknowns, "known_limits": limits})

    def known_limits(self):
        """本场结论的能力边界，逐条写清楚，避免“通过”被读成“什么都验证过了”。"""
        residual = self.config.get("residual") or {}
        attribution = residual.get("attribution", "multi_signal")
        limits = []
        if attribution == JOB_ATTRIBUTION:
            limits.append({"item": "进程归属",
                           "boundary": "每场一个用户级 launchd 作业；按作业资源联盟号判定",
                           "external_launcher": "dsh_gate.py 在作业之外；它被杀不等于作业内产品被杀",
                           "limit": "联盟号覆盖作业内全部后代；未验证进程被移到别的作业的形态",
                           "state": "已实现并有模拟验证（s3 外部启动器被杀后作业内 worker 仍活）"})
            limits.append({"item": "权限边界",
                           "external_launcher_permission": "管理用户级作业、bootstrap/bootout",
                           "tested_process_permission": "产品由 sandbox-exec 套用与探针相同的 readdeny profile；"
                                                        "外部启动器的权限不传递给产品",
                           "probe": "读取权限探针使用同一 sandbox-exec 与同一 profile，不是只检查外部启动器",
                           "state": "已声明；DSH 自身 fs/bash 工具入口仍未验证"})
        elif attribution != "uid_isolation":
            limits.append({"item": "进程归属",
                           "requirement": attribution_requirement_text(),
                           "limit": residual_gap_text(),
                           "state": "缺口已接受，但结论只能是 limited；limited 不放行下一场"})
        limits.append({"item": "放行依据",
                       "limit": "本场状态为 %s。除 ended_verified 之外的任何状态都不构成下一场的"
                                "放行依据。人工恢复凭据不在放行依据之列：它依赖同一套有漏检的"
                                "扫描，多写一个文件不改变未知。本版没有「确认已清理后恢复」的"
                                "技术通道，这是已知阻塞（见 方案-正常结束可放行.md）。"
                                % self.record.get("status"),
                       "state": "已声明"})
        limits.append({"item": "读取权限检查",
                       "limit": "探针以与产品相同的执行身份和权限环境运行，但它走的是普通 "
                                "Python／shell／grep 调用，不是 DSH 的 fs／bash 工具入口；"
                                "DSH 工具入口与两层沙箱叠加未在本场验证。",
                       "state": "已声明"})
        limits.append({"item": "DSH 内部沙箱",
                       "limit": "本程序只生成并验证外层 Seatbelt 策略；产品内部的写入档位由 "
                                "DSH 自己决定，本场只读取会话日志里记录的 sandbox/mode，"
                                "没有验证它是否真的生效。",
                       "state": "已声明"})
        limits.append({"item": "真实入口",
                       "limit": "headless 入口每次提交都会发送一次模型请求，本版没有在不调用"
                                "模型的情况下触发真实工具执行的通道（详见验收报告）。",
                       "state": "已声明"})
        return limits

    # ------------------------------------------------------------------ 主流程
    def run(self):
        # 一进来就把版本与指纹打出来：终端里看到的和记录里写下的必须是同一个东西。
        ident = self.record.get("code") or {}
        print("[gate] 版本 %s 指纹 %s（gate %s）"
              % (GATE_VERSION, ident.get("bundle_short"),
                 ((ident.get("files") or {}).get("gate") or {}).get("sha256", "")[:12]),
              file=sys.stderr)
        try:
            self.load_config()
        except Reject as exc:
            print("[gate] 拒绝启动：%s（阶段 %s，未提交任何任务）" % (exc.reason, exc.stage),
                  file=sys.stderr)
            # 配置阶段就拒绝也要留痕：否则“报过拒绝”只在终端一闪而过，
            # 事后无法核对是哪个检查挡住的。此时可能连配置都没读出来，所以先确认有地方可写。
            if getattr(self, "config", None):
                self.handle_reject(exc)
            raise
        cfg = self.config

        # 先取得独占资格，再做任何检查：两个请求同时到达时，只有一个能往下走。
        # 目录也在锁之后才创建，否则等待中的那个会在运行根目录里留下空目录，
        # 让持有锁的那个误判为“上一场没清理干净”。
        self.acquire_lock()
        try:
            self.run_dir = os.path.join(cfg["records_root"], "runs", self.run_id)
            if os.path.exists(self.run_dir):
                raise Reject(2, "run-id", "该运行 ID 已有记录，拒绝复用",
                             {"run_dir": self.run_dir})
            os.makedirs(self.run_dir)

            # 运行期目录必须放在产品可读写的位置：records 目录本身就是受保护区域，
            # 产品连自己的会话日志都写不进去，会把“隔离”变成“什么都干不了”。
            self.home_root = os.path.join(cfg["run_root"], "home", self.run_id)
            if os.path.exists(self.home_root):
                raise Reject(2, "run-id", "该运行 ID 的运行期目录已存在，拒绝复用",
                             {"home_root": self.home_root})
            self.dsh_home = os.path.join(self.home_root, "dsh")
            self.product_home = os.path.join(self.home_root, "product")
            self.tmp_dir = os.path.join(self.home_root, "tmp")
            self.tool_dir = os.path.join(self.home_root, "tools")
            for path in (self.dsh_home, self.product_home, self.tmp_dir, self.tool_dir):
                os.makedirs(path)
            self.scan_previous_runs()
            self.register_run()
            # 验收钩子：登记之后、提交之前硬崩溃。这条记录只能靠人工核实收拾。
            self.test_hook_crash("crash_after_register", "register")
            self.prepare_workspace()
            self.check_path_distinctness()
            self.check_run_root_clean()
            self.check_no_stale_context()
            self.check_attribution()
            self.build_profile()
            self.run_probe()
            self.recheck_config_unchanged("after-probe")
            exit_code, timed_out = self.submit()
            self.verify_end(exit_code, timed_out)
            self.collect_and_cleanup()
            self.write_ten_fields(self.verdict_text())
            self.record["status"] = self.record.get("status", ST_ENDED_VERIFIED)
        except Reject as exc:
            self.handle_reject(exc)
            raise
        finally:
            self.write_run_record()
            self.release_lock()

    def cleanup_unsubmitted_scratch(self):
        """提交前的拒绝：把本次准备的临时目录清掉，避免污染下一次运行。

        只在“一次都没提交”时清理。已经提交过的现场一律保留，等人工核实。
        """
        cleaned = {}
        for key, path in (("workspace", getattr(self, "workspace", None)),
                          ("runtime_home", getattr(self, "home_root", None))):
            if not path or not os.path.isdir(path):
                continue
            if os.path.basename(path) != self.run_id:
                continue  # 只删本次运行的目录，绝不碰别的
            try:
                cleaned[key] = {"path": path, "tree": tree_manifest(path)}
                shutil.rmtree(path)
                cleaned[key]["removed"] = True
            except OSError as err:
                cleaned[key] = {"path": path, "removed": False, "error": str(err)}
        self.record["reject_cleanup"] = cleaned

    def verdict_text(self):
        status = self.record.get("status")
        if status == ST_ENDED_VERIFIED:
            return "完成：结束已确认（进程退出、会话 turn/end、无残留进程三者一致，且有归属边界）"
        if status == ST_ENDED_LIMITED:
            return ("完成：三项证据一致，但没有可整体归属的进程边界，"
                    "结论只到「看不出还有东西在跑」；本场不构成下一场的放行依据，"
                    "且本版没有解除途径（人工旁证不放行）")
        if status == ST_ENDED_FORCED:
            return ("完成：超时后强制停止，扫描不到残留；但强制停止不能代替“证明都停了”，"
                    "本场同样不放行下一场")
        return "完成：状态 %s" % status

    def handle_reject(self, exc):
        if not getattr(self, "run_dir", None):
            # 还没建记录目录就拒绝了（例如运行 ID 或配置有问题）：仍留一条尝试记录，
            # 保证“拒绝”这件事有据可查，不是只在终端里一闪而过。
            try:
                attempts = os.path.join(self.config["records_root"], "attempts")
                os.makedirs(attempts, exist_ok=True)
                stamp = time.strftime("%Y%m%dT%H%M%S", time.localtime())
                write_json(os.path.join(attempts, "%s-%s.json" % (stamp, self.run_id)), {
                    "run_id": self.run_id, "at": now_iso(), "stage": exc.stage,
                    "code": exc.code, "reason": exc.reason, "detail": exc.detail,
                    "submissions": 0,
                })
            except (OSError, KeyError):
                pass
            return
        self.record["reject"] = {"code": exc.code, "stage": exc.stage,
                                 "reason": exc.reason, "detail": exc.detail}
        if self.record.get("submissions", 0) == 0:
            self.record["status"] = ST_REJECTED
            self.cleanup_unsubmitted_scratch()
        elif exc.code == 6:
            self.record["status"] = ST_UNVERIFIED
        self.write_ten_fields("拒绝：%s（实际提交次数 %d）" % (exc.reason, self.record.get("submissions", 0)))
        # 拒绝记录另存一份到 attempts/，便于事后核对“报了拒绝但任务已发出”这类问题。
        attempts = os.path.join(self.config["records_root"], "attempts")
        os.makedirs(attempts, exist_ok=True)
        stamp = time.strftime("%Y%m%dT%H%M%S", time.localtime())
        write_json(os.path.join(attempts, "%s-%s.json" % (stamp, self.run_id)), {
            "run_id": self.run_id,
            "at": now_iso(),
            "stage": exc.stage,
            "code": exc.code,
            "reason": exc.reason,
            "detail": exc.detail,
            "submissions": self.record.get("submissions", 0),
        })
        print("[gate] 拒绝启动：%s（阶段 %s，提交次数 %d）"
              % (exc.reason, exc.stage, self.record.get("submissions", 0)), file=sys.stderr)


def build_readdeny_profile(protected_roots, records_root, path, control_root=None):
    """写外层 Seatbelt 策略文件，返回内容指纹。

    策略是“默认允许 + 显式拒绝”：只针对评测侧材料、历史运行目录与运行记录目录，
    拒绝读和写。产品自己的写入档位由 DSH 内部沙箱决定，两层叠加后取交集。
    """
    lines = [
        ";; %s 由 dsh_gate.py 生成，勿手改" % PROFILE_KIND,
        "(version 1)",
        "(allow default)",
    ]
    for root in protected_roots:
        lines.append('(deny file-read* (subpath %s))' % sbpl(root))
        lines.append('(deny file-write* (subpath %s))' % sbpl(root))
    for root in (records_root, control_root):
        if not root:
            continue
        lines.append('(deny file-read* (subpath %s))' % sbpl(root))
        lines.append('(deny file-write* (subpath %s))' % sbpl(root))
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return sha256_file(path)


def sbpl(path):
    """把路径写成 SBPL 字符串字面量。"""
    return '"%s"' % path.replace("\\", "\\\\").replace('"', '\\"')


def tree_manifest(root):
    items = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in sorted(filenames):
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root)
            entry = {"path": rel}
            if os.path.islink(full):
                entry["symlink"] = os.readlink(full)
            else:
                entry["sha256"] = sha256_file(full)
                entry["bytes"] = os.path.getsize(full)
            items.append(entry)
    return items


def product_version(cfg):
    plist = cfg["product"].get("version_plist")
    if not plist or not os.path.isfile(plist):
        return "未知（未提供 Info.plist 路径或文件不存在）"
    import plistlib
    try:
        with open(plist, "rb") as handle:
            data = plistlib.load(handle)
    except Exception:  # noqa: BLE001
        return "未知（Info.plist 无法解析）"
    return "%s (%s)" % (data.get("CFBundleShortVersionString", "未知"),
                        data.get("CFBundleVersion", "未知"))


def evaluate_probe_result(payload, profile_sha256, ws_probe_sha256):
    """把探针的原始观察结果换算成通过／不通过。

    规则是“全部满足才算通过”：
      - 结果来自本次策略（指纹一致）；
      - 必需的入口一个不缺；
      - 工作区探针能读，且读到的就是这一次放进去的那份；
      - 其余每个入口都是“被拒绝”，且 errno 是 EACCES/EPERM；
      - 出现“不存在”“报错”“能读”任何一项都不通过。
    """
    problems = []
    if not isinstance(payload, dict) or payload.get("kind") != PROBE_KIND:
        return {"passed": False, "problems": ["探针输出格式不符"] }
    if payload.get("profile_sha256") != profile_sha256:
        problems.append("探针运行时的策略指纹与当前不一致")
    results = payload.get("results") or []
    by_entry = {}
    for item in results:
        by_entry[item.get("entry")] = item

    missing = [name for name in REQUIRED_PROBE_ENTRIES if name not in by_entry]
    if missing:
        problems.append("缺少入口结果：%s" % ", ".join(missing))

    ws = by_entry.get("workspace_read")
    if ws:
        if ws.get("observed") != "readable":
            problems.append("工作区探针读不到（%s）" % ws.get("observed"))
        elif not ws.get("marker_present") or ws.get("sha256") != ws_probe_sha256:
            problems.append("工作区探针读到的内容与本次放入的不一致")

    for name in REQUIRED_PROBE_ENTRIES:
        if name == "workspace_read":
            continue
        item = by_entry.get(name)
        if not item:
            continue
        observed = item.get("observed")
        if observed == "readable":
            problems.append("%s 仍能读到受保护内容" % name)
        elif observed == "missing":
            problems.append("%s 报“路径不存在”，不能算隔离成功" % name)
        elif observed == "error":
            problems.append("%s 结果不明（%s）" % (name, item.get("error")))
        elif observed == "denied":
            err = item.get("errno")
            if err is not None and err not in (errno.EACCES, errno.EPERM):
                problems.append("%s 的拒绝原因不是权限拒绝（errno=%s）" % (name, err))
    return {"passed": not problems, "problems": problems,
            "entries": len(results), "uid": payload.get("uid")}


def cleanup_run(config_path, run_id, product_kind):
    """正式入口的清理/恢复模式：只清理指定 run 的作业与联盟号，复查无残留后写 cleanup_verified。

    不放宽任何判定：联盟号查不到、仍有活进程、标签状态未知，都不写结束证据、不返回 0。
    """
    gate = Gate(config_path, run_id, None, product_kind, [])
    try:
        gate.load_config()
    except Reject as exc:
        print("[cleanup] 拒绝：%s（阶段 %s）" % (exc.reason, exc.stage), file=sys.stderr)
        return 2
    gate.acquire_lock()
    try:
        status_file = os.path.join(gate.control_root, "runs", run_id, "status.json")
        if not os.path.isfile(status_file):
            print("[cleanup] 拒绝：运行登记不存在 %s" % status_file, file=sys.stderr)
            return 2
        rec = read_json(status_file)
        if rec.get("status") == ST_REJECTED and rec.get("submissions", 0) == 0:
            print("[cleanup] 该场是提交前拒绝，没有需要清理的作业", file=sys.stderr)
            return 0
        job = rec.get("job") or {}
        attribution = rec.get("attribution") if isinstance(rec.get("attribution"), dict) else {}
        if not job and attribution.get("mode") != JOB_ATTRIBUTION:
            print("[cleanup] 拒绝：该记录不是作业模式，本模式不处理旧多信号记录", file=sys.stderr)
            return 2
        label = job.get("label") or JR.label_for(run_id)
        coalition = job.get("coalition")
        boot = JR.bootout(label)
        kill = JR.kill_members(coalition) if coalition else {"ok": False, "log": [],
                                                             "remaining": None}
        live = JR.members(coalition) if coalition else None
        label_after = JR.label_state(label)["state"]
        ok = (coalition is not None and live == [] and kill.get("ok")
              and label_after == JR.LABEL_ABSENT)
        records_run_dir = os.path.join(gate.config["records_root"], "runs", run_id)
        archive = {}
        run_root = gate.config["run_root"]
        for kind in ("ws", "home"):
            src = os.path.join(run_root, kind, run_id)
            if not os.path.isdir(src):
                continue
            dst = os.path.join(records_run_dir, kind + "-archive-cleanup")
            if os.path.exists(dst):
                archive[kind] = {"error": "archive destination already exists", "dest": dst}
                ok = False
                continue
            try:
                shutil.move(src, dst)
                archive[kind] = {"from": src, "to": dst}
            except OSError as exc:
                archive[kind] = {"error": str(exc), "from": src}
                ok = False
        cleanup_record = {"at": now_iso(), "label": label, "coalition": coalition,
                          "bootout": boot, "kill": kill, "live_after": live,
                          "label_state_after": label_after, "archive": archive, "ok": ok}
        if not ok:
            rec["cleanup"] = cleanup_record
            rec["updated_at"] = now_iso()
            write_json(status_file, rec)
            print("[cleanup] 失败：仍有活进程或标签状态未知，未写结束证据",
                  file=sys.stderr)
            return 1
        end_doc = JR.write_end_evidence(
            os.path.join(gate.control_root, "runs", run_id, "end.json"),
            "cleanup_verified", coalition, live,
            {"cleanup": cleanup_record, "run_id": run_id})
        if os.path.isdir(records_run_dir):
            JR.jwrite(os.path.join(records_run_dir, "end.json"), end_doc)
        rec["status"] = ST_ENDED_VERIFIED
        rec["job_end_evidence"] = end_doc
        rec["cleanup"] = cleanup_record
        rec["updated_at"] = now_iso()
        write_json(status_file, rec)
        print(json.dumps({"cleanup": "ok", "run_id": run_id, "label": label,
                          "coalition": coalition, "live_after": live,
                          "label_state_after": label_after}, ensure_ascii=False, indent=2))
        return 0
    finally:
        gate.release_lock()


def main(argv=None):
    parser = argparse.ArgumentParser(description="DSH 受控实验统一启动入口")
    parser.add_argument("--config", required=True, help="配置文件路径")
    parser.add_argument("--run-id", required=False, help="本次运行唯一 ID")
    parser.add_argument("--prompt-file", help="题面文件（按字节提交）")
    parser.add_argument("--product", choices=("real", "mock"), default="real",
                        help="real=真实 DSH 入口；mock=验收用的模拟任务（检查一字不减）")
    parser.add_argument("--mock-arg", action="append", default=[],
                        help="传给模拟任务的参数，仅 --product mock 时使用")
    parser.add_argument("--cleanup-run", help="清理指定 run 的作业/联盟号，复查后写 cleanup_verified，不放宽判定")
    args = parser.parse_args(argv)

    if args.cleanup_run:
        return cleanup_run(args.config, args.cleanup_run, args.product)
    if not args.run_id:
        parser.error("--run-id is required unless --cleanup-run is used")
    gate = Gate(args.config, args.run_id, args.prompt_file, args.product, args.mock_arg)
    try:
        gate.run()
    except Reject as exc:
        return exc.code
    except KeyboardInterrupt:
        print("[gate] 被中断；本场状态留在运行记录里，下一场会拒绝启动直到人工核实。",
              file=sys.stderr)
        return 6
    return 0


if __name__ == "__main__":
    sys.exit(main())
