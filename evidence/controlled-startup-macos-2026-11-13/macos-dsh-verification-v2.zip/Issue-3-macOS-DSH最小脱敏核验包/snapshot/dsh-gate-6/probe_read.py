#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读取权限探针：在“实际受测环境”里检查能读什么。

用途
----
本脚本不判断“是否通过”，只如实记录每条读取入口的实际观察结果（能读／被拒／不存在／报错），
再由 gate/dsh_gate.py 按固定规则判定。这样探针本身被替换或被改写时，也不能把自己报成通过。

它必须由 dsh_gate.py 用与产品完全相同的受限环境启动
（macOS：同一条 sandbox-exec + 同一份 profile 文件），
否则观察结果不能代表产品实际工具的权限。

输出：stdout 单行 JSON（UTF-8）。不输出任何被保护文件的内容。
"""

import argparse
import errno
import hashlib
import json
import os
import subprocess
import sys
import tempfile

# 探针标记：用于确认“读到的确实是我们放的那份文件”，而不是空文件或别的文件。
WS_MARKER = "DSH-GATE-PROBE-WORKSPACE-v1"
EXT_MARKER = "DSH-GATE-PROBE-PROTECTED-v1"

DENIAL_TEXT = ("permission denied", "operation not permitted", "read-only file system")


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def classify_exception(exc):
    """把 Python 异常翻译成观察项。errno 必须保留，用来区分“被拒绝”和“路径不存在”。"""
    if isinstance(exc, FileNotFoundError):
        return {"observed": "missing", "errno": errno.ENOENT, "error": "FileNotFoundError"}
    if isinstance(exc, PermissionError):
        return {"observed": "denied", "errno": exc.errno, "error": "PermissionError"}
    if isinstance(exc, OSError):
        if exc.errno in (errno.EACCES, errno.EPERM):
            return {"observed": "denied", "errno": exc.errno, "error": "OSError"}
        return {"observed": "error", "errno": exc.errno, "error": "OSError"}
    return {"observed": "error", "errno": None, "error": type(exc).__name__}


def check_python_read(path):
    """入口一：进程内直接读文件（对应产品自己的 read 工具，不经过子进程）。"""
    try:
        with open(path, "rb") as handle:
            data = handle.read()
    except Exception as exc:  # noqa: BLE001 - 需要记录所有异常类型
        return classify_exception(exc)
    text = data.decode("utf-8", "replace")
    return {
        "observed": "readable",
        "errno": 0,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "marker_present": (WS_MARKER in text) or (EXT_MARKER in text),
    }


def run_shell(command):
    """执行一条 shell 命令，返回 (returncode, stdout, stderr)。"""
    try:
        proc = subprocess.run(
            ["/bin/sh", "-c", command],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return None, b"", b"timeout"
    return proc.returncode, proc.stdout, proc.stderr


def classify_subprocess(result, marker):
    """子进程读数：必须同时满足“非零退出 + 输出不含标记 + 错误文本是拒绝签名”，才算被拒绝。

    只看到非零退出是不够的：路径不存在同样非零，但它证明不了隔离。
    """
    code, out, err = result
    if code is None:
        return {"observed": "error", "errno": None, "error": "timeout"}
    text = (out + err).decode("utf-8", "replace")
    if marker and marker in text:
        return {"observed": "readable", "errno": 0, "returncode": code}
    lowered = text.lower()
    if code != 0 and any(sig in lowered for sig in DENIAL_TEXT):
        return {"observed": "denied", "errno": None, "returncode": code,
                "signature": next(sig for sig in DENIAL_TEXT if sig in lowered)}
    if code == 0:
        # 命令成功但没打印标记：可能是空文件或被别的路径覆盖，记为未知而不是通过。
        return {"observed": "error", "errno": None, "returncode": 0, "error": "zero exit without marker"}
    return {"observed": "error", "errno": None, "returncode": code,
            "error": (err.decode("utf-8", "replace").strip().splitlines() or [""])[0][:200]}


def main():
    parser = argparse.ArgumentParser(description="读取权限探针（只观察，不判定）")
    parser.add_argument("--workspace", required=True, help="本次运行工作区的真实路径")
    parser.add_argument("--workspace-probe", required=True, help="工作区内探针文件的相对路径")
    parser.add_argument("--protected-probe", required=True, help="评测者侧受保护探针的绝对路径")
    parser.add_argument("--protected-root", required=True, help="评测者侧受保护目录的绝对路径")
    parser.add_argument("--config-sha256", default="", help="本次配置指纹，仅用于回填记录")
    parser.add_argument("--profile-sha256", default="", help="受限环境 profile 指纹，仅用于回填记录")
    args = parser.parse_args()

    ws = os.path.realpath(args.workspace)
    ws_probe = os.path.join(ws, args.workspace_probe)
    ext_probe = os.path.realpath(args.protected_probe)
    prot_root = os.path.realpath(args.protected_root)

    results = []

    # 入口 1：进程内直接读工作区文件 —— 期望能读；读不到说明环境把工作区也挡了，本场无法进行。
    results.append(dict(entry="workspace_read", target=ws_probe,
                        expect="readable", **check_python_read(ws_probe)))

    # 入口 2：进程内直接读受保护文件（绝对路径）。
    results.append(dict(entry="protected_open_absolute", target=ext_probe,
                        expect="denied", **check_python_read(ext_probe)))

    # 入口 3：用 ../ 从工作区往上走，最后落到受保护文件（绕过路径前缀检查的老办法）。
    rel = os.path.relpath(ext_probe, ws)
    traversal = os.path.join(ws, rel)
    results.append(dict(entry="protected_open_traversal", target=traversal,
                        expect="denied", **check_python_read(traversal)))

    # 入口 4：工作区内的符号链接指向受保护文件。
    link_dir = tempfile.mkdtemp(prefix=".gate-probe-", dir=ws)
    link_path = os.path.join(link_dir, "link-to-protected.txt")
    link_error = None
    try:
        os.symlink(ext_probe, link_path)
    except OSError as exc:
        link_error = f"{type(exc).__name__}:{exc.errno}"
    if link_error is None:
        results.append(dict(entry="protected_open_symlink", target=link_path,
                            expect="denied", **check_python_read(link_path)))
    else:
        results.append(dict(entry="protected_open_symlink", target=link_path,
                            expect="denied", observed="error", errno=None,
                            error=f"symlink_create_failed:{link_error}"))

    # 入口 5：终端工具等价的 shell 读取（cat）。
    results.append(dict(entry="shell_cat", target=ext_probe, expect="denied",
                        **classify_subprocess(run_shell("/bin/cat %s" % shquote(ext_probe)), EXT_MARKER)))

    # 入口 6：搜索工具等价的全目录检索（grep -r），检查是否通过搜索结果泄出内容。
    results.append(dict(entry="search_grep_recursive", target=prot_root, expect="denied",
                        **classify_subprocess(
                            run_shell("/usr/bin/grep -rl %s %s" % (shquote(EXT_MARKER), shquote(prot_root))),
                            EXT_MARKER)))

    # 入口 7：代码执行路径（另一个解释器读文件）。
    py = "/usr/bin/python3" if os.path.exists("/usr/bin/python3") else sys.executable
    code = "print(open(%r).read())" % ext_probe
    results.append(dict(entry="code_exec_open", target=ext_probe, expect="denied",
                        **classify_subprocess(
                            run_shell("%s -c %s" % (shquote(py), shquote(code))), EXT_MARKER)))

    # 清理探针自己创建的东西，避免污染工作区。
    try:
        if os.path.islink(link_path):
            os.unlink(link_path)
        os.rmdir(link_dir)
    except OSError:
        pass

    payload = {
        "kind": "dsh-gate-probe-v1",
        "workspace": ws,
        "workspace_probe_sha256": sha256_text(WS_MARKER),
        "protected_probe": ext_probe,
        "protected_root": prot_root,
        "config_sha256": args.config_sha256,
        "profile_sha256": args.profile_sha256,
        "uid": os.getuid(),
        "effective_uid": os.geteuid(),
        "python": sys.executable,
        "results": results,
    }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    return 0


def shquote(text):
    return "'" + text.replace("'", "'\\''") + "'"


if __name__ == "__main__":
    sys.exit(main())
