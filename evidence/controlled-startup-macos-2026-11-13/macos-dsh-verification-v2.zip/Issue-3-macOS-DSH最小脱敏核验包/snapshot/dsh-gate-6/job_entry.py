#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""launchd 作业入口：正式启动程序的“作业内主进程”。

结构（集成后）：
    外部启动程序 dsh_gate.py（不在 launchd 作业里）
      → 建 plist / bootstrap
      → 本文件（launchd 作业主进程，未受限）
      → sandbox-exec -f <readdeny.sb> <产品/模拟产品>   ← 实际提交的子进程仍受读取限制

本文件只做三件事：
  1. 写下自己的身份与联盟号（job.ready.json），让外部启动程序能记录作业边界；
  2. 启动“已经套好 sandbox-exec 的产品 argv”，把 prompt 喂给 stdin，stdout/stderr 落盘；
  3. 等产品退出，写下产品身份、退出码和作业联盟号（job.product.json / job.exit.json）。

它**不判断**是否结束、不决定放行、不写结束证据——这些由外部启动程序按同一份记录判定。
被外部 SIGKILL 时它什么都不做；作业与产品仍由 launchd 管理，下一场由外部启动程序重新扫描联盟号。
"""
import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import probe_proc as P  # noqa: E402


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + ".%03d" % (int(time.time() * 1000) % 1000)


def jwrite(path, obj):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def main():
    argv = sys.argv[1:]
    if "--" not in argv:
        raise SystemExit("job_entry: 缺少 -- 与产品 argv")
    cut = argv.index("--")
    opts = argv[:cut]
    product_argv = argv[cut + 1:]
    if not product_argv:
        raise SystemExit("job_entry: 产品 argv 为空")

    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--stdout", required=True)
    ap.add_argument("--stderr", required=True)
    ap.add_argument("--prompt", default="")
    ap.add_argument("--cwd", required=True)
    a = ap.parse_args(opts)

    me = P.ident(os.getpid())
    job_coalition = P.coalition(os.getpid())
    jwrite(os.path.join(a.run_dir, "job.ready.json"), {
        "at": now(), "role": "launchd_job_main",
        "ident": me, "coalition": job_coalition,
        "argv": sys.argv, "cwd": a.cwd,
        "role_boundary": "作业主进程；产品由 sandbox-exec 套用与探针相同的 profile",
    })

    env = os.environ.copy()
    stdin = open(a.prompt, "rb") if a.prompt and os.path.isfile(a.prompt) else subprocess.DEVNULL
    out = open(a.stdout, "wb")
    err = open(a.stderr, "wb")
    try:
        child = subprocess.Popen(product_argv, stdin=stdin, stdout=out, stderr=err,
                                 cwd=a.cwd, env=env)
    except OSError as exc:
        out.close()
        err.close()
        jwrite(os.path.join(a.run_dir, "job.exit.json"), {
            "at": now(), "rc": 127, "spawn_error": str(exc),
            "job_ident": me, "job_coalition": job_coalition,
            "product_pid": None, "product_ident": None,
        })
        return 127
    finally:
        try:
            if stdin is not subprocess.DEVNULL:
                stdin.close()
        except Exception:  # noqa: BLE001
            pass

    product_ident = P.ident(child.pid)
    jwrite(os.path.join(a.run_dir, "job.product.json"), {
        "at": now(), "product_pid": child.pid, "product_ident": product_ident,
        "product_coalition": P.coalition(child.pid),
        "job_ident": me, "job_coalition": job_coalition,
        "product_argv": product_argv,
    })
    rc = child.wait()
    out.close()
    err.close()
    jwrite(os.path.join(a.run_dir, "job.exit.json"), {
        "at": now(), "rc": rc, "job_ident": me, "job_coalition": job_coalition,
        "product_pid": child.pid, "product_ident": product_ident,
        "coalition_at_exit": P.coalition(os.getpid()),
    })
    return rc


if __name__ == "__main__":
    sys.exit(main())
