#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""launchd 作业运行层（正式启动程序集成用）。

复用验证过的两块：
  * `probe_proc.py` 的 (pid, 启动时刻) 身份与 coalition 联盟号；
  * a2 的“每场一个 launchd 作业、按联盟号归属”的作业结构。

只提供最小操作：写 plist、bootstrap、bootout、等文件、读联盟号成员、按联盟号清理、
写 normal_exit/cleanup_verified 结束证据。判定由 dsh_gate.py 做，本模块不自行放行。
"""
import json
import os
import plistlib
import subprocess
import time

import probe_proc as P

UID = os.getuid()
DOMAIN = "gui/%d" % UID
LAUNCHCTL = "/bin/launchctl"
LABEL_PREFIX = "cn.redacted.dshgate."

LABEL_PRESENT = "present"
LABEL_ABSENT = "absent"
LABEL_UNKNOWN = "unknown"


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + ".%03d" % (int(time.time() * 1000) % 1000)


def label_for(run_id):
    return LABEL_PREFIX + run_id


def jwrite(path, obj):
    parent = os.path.dirname(str(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def jread(path, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return default


def lc(*args, timeout=30):
    try:
        cp = subprocess.run([LAUNCHCTL, *args], capture_output=True, text=True, timeout=timeout)
        return {"argv": [LAUNCHCTL, *args], "rc": cp.returncode,
                "out": (cp.stdout or "")[-4000:], "err": (cp.stderr or "")[-4000:]}
    except Exception as exc:  # noqa: BLE001
        return {"argv": [LAUNCHCTL, *args], "rc": None, "out": "", "err": "%s: %s" % (type(exc).__name__, exc)}


def label_state(label):
    r = lc("print", "%s/%s" % (DOMAIN, label))
    if r["rc"] == 0:
        state = LABEL_PRESENT
    elif r["rc"] == 113 or "Could not find service" in (r["err"] or ""):
        state = LABEL_ABSENT
    else:
        state = LABEL_UNKNOWN
    return {"label": label, "state": state, "rc": r["rc"], "err": r["err"], "raw": r}


def wait_file(path, timeout, interval=0.05):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if os.path.exists(path):
            return True, round(time.time() - t0, 3)
        time.sleep(interval)
    return False, round(time.time() - t0, 3)


def wait_label(label, want_state, timeout, interval=0.1):
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = label_state(label)
        if st["state"] == want_state:
            return True, round(time.time() - t0, 3), st
        time.sleep(interval)
    return False, round(time.time() - t0, 3), label_state(label)


def write_plist(path, label, program_args, stdout_path, stderr_path, env):
    doc = {
        "Label": label,
        "ProgramArguments": list(program_args),
        "RunAtLoad": True,
        "KeepAlive": False,
        "ProcessType": "Background",
        "StandardOutPath": stdout_path,
        "StandardErrorPath": stderr_path,
        "EnvironmentVariables": {str(k): str(v) for k, v in env.items()},
    }
    with open(path, "wb") as fh:
        plistlib.dump(doc, fh)
    return {"path": path, "label": label, "program_arguments": list(program_args),
            "bytes": os.path.getsize(path)}


def bootstrap(plist_path):
    return lc("bootstrap", DOMAIN, plist_path)


def bootout(label, timeout=20):
    before = label_state(label)
    result = None
    if before["state"] == LABEL_PRESENT:
        result = lc("bootout", "%s/%s" % (DOMAIN, label))
    ok, waited, after = wait_label(label, LABEL_ABSENT, timeout)
    return {"label": label, "state_before": before["state"], "bootout": result,
            "state_after": after["state"], "absent": after["state"] == LABEL_ABSENT,
            "waited_s": waited}


def members(coalition_key):
    if not coalition_key:
        return None
    return P.members(coalition_key)


def kill_members(coalition_key, grace=3.0, rounds=3):
    """按联盟号终止成员；只动这个作业边界里的进程。返回每轮记录与最终剩余。"""
    log = []
    for _ in range(rounds):
        live = members(coalition_key)
        if live is None:
            log.append({"round": len(log) + 1, "live_scan": None, "note": "无法枚举进程"})
            return {"ok": False, "log": log, "remaining": None}
        if not live:
            return {"ok": True, "log": log, "remaining": []}
        sent = []
        for row in live:
            ident = {"pid": row["pid"], "start_sec": row["start_sec"], "start_usec": row["start_usec"]}
            if not P.alive(ident):
                continue
            try:
                os.kill(row["pid"], 15)
                sent.append({"ident": ident, "signal": 15, "sent": True})
            except ProcessLookupError:
                sent.append({"ident": ident, "signal": 15, "sent": False, "why": "gone"})
            except PermissionError as exc:
                sent.append({"ident": ident, "signal": 15, "sent": False, "why": str(exc)})
        deadline = time.time() + grace
        while time.time() < deadline and members(coalition_key):
            time.sleep(0.1)
        still = members(coalition_key) or []
        for row in still:
            ident = {"pid": row["pid"], "start_sec": row["start_sec"], "start_usec": row["start_usec"]}
            if P.alive(ident):
                try:
                    os.kill(row["pid"], 9)
                except OSError:
                    pass
        log.append({"round": len(log) + 1, "live_before": len(live), "signals": sent})
        time.sleep(0.2)
    remaining = members(coalition_key)
    return {"ok": remaining == [], "log": log, "remaining": remaining}


def write_end_evidence(path, kind, coalition_key, live_scan, extra=None):
    doc = {
        "kind": kind,
        "at": now(),
        "coalition": coalition_key,
        "verified_no_live_procs": live_scan == [],
        "live_scan": live_scan,
        "written_by": "dsh_gate_job_runtime",
        "observations": extra or {},
        "note": "这是外部启动程序写下的结束事实；下一场是否放行由 dsh_gate.py 重新扫描联盟号后决定",
    }
    jwrite(path, doc)
    return doc


def print_job_pid(label):
    """从 launchctl print 里取作业主 pid；找不到返回 None（不猜）。"""
    r = lc("print", "%s/%s" % (DOMAIN, label))
    if r["rc"] != 0:
        return None
    for line in (r["out"] or "").splitlines():
        text = line.strip()
        if text.startswith("pid ="):
            try:
                return int(text.split("=", 1)[1].strip())
            except ValueError:
                return None
    return None
